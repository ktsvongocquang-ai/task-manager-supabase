import { useState } from 'react'
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom'
import { useAuthStore } from '../../store/authStore'
import {
    Home,
    GanttChart,
    FolderKanban,
    ListChecks,
    Users,
    LogOut,
    Menu,
    X,
    RefreshCw,
    Plus,
    KeyRound,
    MessageCircle
} from 'lucide-react'

const viewTitles: Record<string, string> = {
    '/dashboard': 'Tổng Quan',
    '/gantt': 'Sơ đồ Gantt',
    '/projects': 'Quản lý Dự án',
    '/tasks': 'Quản lý Nhiệm vụ',
    '/users': 'Quản lý Nhân viên',
}

export const Layout = () => {
    const { profile, signOut } = useAuthStore()
    const navigate = useNavigate()
    const location = useLocation()
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
    const [isRefreshing, setIsRefreshing] = useState(false)

    const handleSignOut = async () => {
        await signOut()
        navigate('/login')
    }

    const handleRefresh = () => {
        setIsRefreshing(true)
        window.location.reload()
    }

    const currentTitle = viewTitles[location.pathname] || 'Quản Lý Dự Án'

    const navItems = [
        { name: 'Tổng quan', path: '/dashboard', icon: Home },
        { name: 'Sơ đồ Gantt', path: '/gantt', icon: GanttChart },
        { name: 'Dự án', path: '/projects', icon: FolderKanban },
        { name: 'Nhiệm vụ', path: '/tasks', icon: ListChecks },
    ]

    if (profile?.role === 'Admin' || profile?.role === 'Quản lý') {
        navItems.push({ name: 'Người dùng', path: '/users', icon: Users })
    }

    const getInitials = (name?: string) => {
        if (!name) return 'U'
        return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
    }

    const getRoleColor = () => {
        if (profile?.role === 'Admin') return 'bg-orange-500'
        if (profile?.role === 'Quản lý') return 'bg-blue-500'
        return 'bg-emerald-500'
    }

    const getNavIcon = (path: string, isActive: boolean) => {
        const base = 'w-7 h-7 rounded-lg flex items-center justify-center mr-3 flex-shrink-0'
        if (isActive) return `${base} bg-indigo-100`
        switch (path) {
            case '/dashboard': return `${base} bg-blue-50`
            case '/gantt': return `${base} bg-indigo-50`
            case '/projects': return `${base} bg-violet-50`
            case '/tasks': return `${base} bg-emerald-50`
            case '/users': return `${base} bg-orange-50`
            default: return `${base} bg-slate-50`
        }
    }

    const getIconColor = (path: string, isActive: boolean) => {
        if (isActive) return 'text-indigo-600'
        switch (path) {
            case '/dashboard': return 'text-blue-500'
            case '/gantt': return 'text-indigo-500'
            case '/projects': return 'text-violet-500'
            case '/tasks': return 'text-emerald-500'
            case '/users': return 'text-orange-500'
            default: return 'text-slate-400'
        }
    }

    return (
        <div className="min-h-screen bg-slate-50 flex">
            {/* Sidebar - Light theme matching screenshot */}
            <aside className="hidden md:flex w-[200px] bg-white flex-col fixed inset-y-0 z-10 border-r border-slate-100 shadow-sm">
                {/* Logo */}
                <div className="h-[60px] flex items-center px-5 border-b border-slate-100">
                    <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-xl flex items-center justify-center mr-2.5 shadow-md shadow-indigo-200">
                        <FolderKanban size={15} className="text-white" />
                    </div>
                    <div>
                        <span className="font-bold text-[13px] text-slate-800 block leading-tight">Quản Lý Dự Án</span>
                        <span className="text-[10px] text-slate-400 leading-none">Quản lý thông minh</span>
                    </div>
                </div>

                {/* User Info */}
                <div className="px-4 py-3 border-b border-slate-100">
                    <div className="flex items-center gap-2.5 bg-slate-50 rounded-xl px-3 py-2.5">
                        <div className={`w-8 h-8 rounded-full ${getRoleColor()} text-white flex items-center justify-center font-bold text-[11px] shadow-sm flex-shrink-0`}>
                            {getInitials(profile?.full_name)}
                        </div>
                        <div className="overflow-hidden flex-1 min-w-0">
                            <p className="text-[12px] font-bold text-slate-700 truncate">{profile?.full_name || 'Người dùng'}</p>
                            <p className="text-[10px] text-slate-400 truncate">{profile?.role || 'Nhân viên'}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-1.5 mt-2">
                        <button className="flex-1 flex items-center justify-center gap-1 px-2 py-1.5 text-[10px] font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors">
                            <KeyRound size={10} /> Đổi mật khẩu
                        </button>
                        <button onClick={handleSignOut} className="flex-1 flex items-center justify-center gap-1 px-2 py-1.5 text-[10px] font-semibold text-red-500 bg-red-50 hover:bg-red-100 rounded-lg transition-colors">
                            <LogOut size={10} /> Đăng xuất
                        </button>
                    </div>
                </div>

                {/* Navigation */}
                <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
                    {navItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) =>
                                `flex items-center px-3 py-2.5 rounded-xl transition-all text-[13px] ${isActive
                                    ? 'bg-indigo-50 text-indigo-700 font-semibold'
                                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700 font-medium'
                                }`
                            }
                        >
                            {({ isActive }) => (
                                <>
                                    <div className={getNavIcon(item.path, isActive)}>
                                        <item.icon size={15} className={getIconColor(item.path, isActive)} />
                                    </div>
                                    {item.name}
                                </>
                            )}
                        </NavLink>
                    ))}
                </nav>

                {/* Footer */}
                <div className="px-4 py-3 border-t border-slate-100">
                    <div className="flex items-center gap-1 text-[10px] text-slate-400">
                        <span>Hỗ trợ kỹ thuật</span>
                        <span className="text-indigo-500 font-semibold">(Version: 4.1)</span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-1.5">
                        <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity">
                            <MessageCircle size={10} className="text-white" />
                        </div>
                        <div className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center cursor-pointer hover:opacity-80 transition-opacity">
                            <span className="text-white text-[8px] font-bold">▶</span>
                        </div>
                    </div>
                    <p className="text-[9px] text-slate-400 mt-1.5">© 2025 sheetkhoinghiep.com</p>
                </div>
            </aside>

            {/* Main Content */}
            <div className="flex-1 flex flex-col md:pl-[200px] min-w-0">
                {/* Mobile Header */}
                <header className="md:hidden h-14 bg-white border-b border-slate-100 flex items-center justify-between px-4 sticky top-0 z-20 shadow-sm">
                    <div className="flex items-center">
                        <div className="w-7 h-7 bg-gradient-to-br from-indigo-500 to-blue-500 rounded-lg flex items-center justify-center mr-2.5">
                            <FolderKanban size={14} className="text-white" />
                        </div>
                        <span className="text-sm font-bold text-slate-800">Quản Lý Dự Án</span>
                    </div>
                    <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 text-slate-400 hover:text-slate-600 rounded-lg">
                        {isMobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
                    </button>
                </header>

                {/* Mobile Menu */}
                {isMobileMenuOpen && (
                    <div className="md:hidden fixed inset-0 z-30 bg-white flex flex-col pt-14">
                        <div className="flex-1 overflow-y-auto py-4 px-4 space-y-2">
                            {navItems.map((item) => (
                                <NavLink key={item.path} to={item.path} onClick={() => setIsMobileMenuOpen(false)}
                                    className={({ isActive }) => `flex items-center px-4 py-4 rounded-xl transition-colors font-medium text-base ${isActive ? 'bg-indigo-50 text-indigo-700' : 'text-slate-500 active:bg-slate-50'}`}>
                                    <item.icon size={22} className="mr-4" />
                                    {item.name}
                                </NavLink>
                            ))}
                        </div>
                        <div className="p-4 border-t border-slate-100">
                            <button onClick={handleSignOut} className="w-full flex items-center justify-center px-4 py-3 text-base font-medium text-white bg-red-500 rounded-xl">
                                <LogOut size={18} className="mr-3" /> Đăng xuất
                            </button>
                        </div>
                    </div>
                )}

                {/* Topbar */}
                <div className="bg-white border-b border-slate-100 px-6 h-[52px] hidden md:flex justify-between items-center shadow-sm z-10">
                    <h2 className="text-[14px] font-bold text-slate-700">{currentTitle}</h2>
                    <div className="flex items-center gap-2.5">
                        <button onClick={handleRefresh} className="text-slate-400 hover:text-slate-600 transition-colors p-2 rounded-lg hover:bg-slate-50" title="Làm mới">
                            <RefreshCw size={15} className={isRefreshing ? 'animate-spin' : ''} />
                        </button>
                        <button onClick={() => navigate('/projects')} className="inline-flex items-center px-3.5 py-1.5 text-[12px] font-semibold rounded-lg text-white bg-emerald-500 hover:bg-emerald-600 transition-colors shadow-sm shadow-emerald-100">
                            <Plus size={14} className="mr-1" /> Tạo mới
                        </button>
                        <div className={`w-8 h-8 rounded-full ${getRoleColor()} text-white flex items-center justify-center text-[10px] font-bold shadow-sm cursor-pointer`}>
                            {getInitials(profile?.full_name)}
                        </div>
                    </div>
                </div>

                {/* Page Content */}
                <main className="flex-1 p-4 sm:p-5 overflow-x-hidden">
                    <Outlet />
                </main>

                {/* Bottom footer */}
                <div className="hidden md:flex bg-white border-t border-slate-100 px-6 py-2.5 items-center justify-between text-[10px] text-slate-400">
                    <div className="flex items-center gap-1.5">
                        <span>Hỗ trợ kỹ thuật</span>
                        <span className="text-indigo-500 font-semibold">(Version: 4.1)</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                        <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                        <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                    </div>
                    <span>© 2025 sheetkhoinghiep.com</span>
                </div>
            </div>
        </div>
    )
}
