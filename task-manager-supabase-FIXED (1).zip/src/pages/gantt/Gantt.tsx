import { useEffect, useState, useMemo } from 'react'
import { supabase } from '../../services/supabase'
import { type Task, type Project } from '../../types'
import { ChevronLeft, ChevronRight, Search, Calendar, PackageOpen } from 'lucide-react'

const MONTHS_VI = ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6',
    'Tháng 7', 'Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12']

const DAY_NAMES_SHORT = ['CN', 'Th 2', 'Th 3', 'Th 4', 'Th 5', 'Th 6', 'Th 7']

const BAR_COLORS = [
    'bg-indigo-400', 'bg-emerald-400', 'bg-amber-400', 'bg-rose-400',
    'bg-cyan-400', 'bg-purple-400', 'bg-orange-400', 'bg-teal-400'
]

export const Gantt = () => {
    const [tasks, setTasks] = useState<Task[]>([])
    const [projects, setProjects] = useState<Project[]>([])
    const [loading, setLoading] = useState(true)
    const [currentDate, setCurrentDate] = useState(new Date())
    const [search, setSearch] = useState('')

    const year = currentDate.getFullYear()
    const month = currentDate.getMonth()

    useEffect(() => { fetchData() }, [])

    const fetchData = async () => {
        try {
            setLoading(true)
            const [{ data: t }, { data: p }] = await Promise.all([
                supabase.from('tasks').select('*'),
                supabase.from('projects').select('*')
            ])
            setTasks((t || []) as Task[])
            setProjects((p || []) as Project[])
        } catch (err) { console.error(err) } finally { setLoading(false) }
    }

    const daysInMonth = new Date(year, month + 1, 0).getDate()
    const days = Array.from({ length: daysInMonth }, (_, i) => i + 1)

    const isToday = (day: number) => {
        const now = new Date()
        return day === now.getDate() && month === now.getMonth() && year === now.getFullYear()
    }

    const isWeekend = (day: number) => {
        const d = new Date(year, month, day)
        return d.getDay() === 0 || d.getDay() === 6
    }

    const getDayName = (day: number) => {
        const d = new Date(year, month, day)
        return DAY_NAMES_SHORT[d.getDay()]
    }

    const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1))
    const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1))

    const ganttItems = useMemo(() => {
        const items: { id: string; name: string; startDay: number; endDay: number; color: string; type: 'project' | 'task'; completion?: number }[] = []
        const monthStart = new Date(year, month, 1)
        const monthEnd = new Date(year, month + 1, 0)

        projects.forEach((p, idx) => {
            if (search && !p.name.toLowerCase().includes(search.toLowerCase()) && !p.project_code.toLowerCase().includes(search.toLowerCase())) return

            const start = p.start_date ? new Date(p.start_date) : null
            const end = p.end_date ? new Date(p.end_date) : null
            if (!start && !end) return
            if (end && end < monthStart) return
            if (start && start > monthEnd) return

            const effectiveStart = start && start >= monthStart ? start : monthStart
            const effectiveEnd = end && end <= monthEnd ? end : monthEnd

            items.push({
                id: p.id,
                name: `${p.project_code}: ${p.name}`,
                startDay: effectiveStart.getDate(),
                endDay: effectiveEnd.getDate(),
                color: BAR_COLORS[idx % BAR_COLORS.length],
                type: 'project'
            })

            // Add tasks under this project
            const projTasks = tasks.filter(t => t.project_id === p.id)
            projTasks.forEach(t => {
                const tStart = t.start_date ? new Date(t.start_date) : null
                const tEnd = t.due_date ? new Date(t.due_date) : null
                if (!tStart && !tEnd) return
                if (tEnd && tEnd < monthStart) return
                if (tStart && tStart > monthEnd) return

                const tEffStart = tStart && tStart >= monthStart ? tStart : monthStart
                const tEffEnd = tEnd && tEnd <= monthEnd ? tEnd : monthEnd

                items.push({
                    id: t.id,
                    name: `  └ ${t.task_code}: ${t.name}`,
                    startDay: tEffStart.getDate(),
                    endDay: tEffEnd.getDate(),
                    color: BAR_COLORS[idx % BAR_COLORS.length],
                    type: 'task',
                    completion: t.completion_pct
                })
            })
        })
        return items
    }, [projects, tasks, year, month, search])

    const CELL_W = 44

    if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div></div>

    return (
        <div className="space-y-5 max-w-[1400px] mx-auto">
            {/* Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h1 className="text-xl font-bold text-slate-800">Sơ đồ Gantt</h1>
                <div className="relative">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm kiếm..."
                        className="bg-white border border-slate-200 pl-9 pr-4 py-2 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 w-48" />
                </div>
            </div>

            {/* Month Navigation - matching screenshot */}
            <div className="flex items-center justify-center gap-6">
                <button onClick={prevMonth} className="w-10 h-10 bg-indigo-500 hover:bg-indigo-600 text-white rounded-full shadow-md flex items-center justify-center transition-all active:scale-90">
                    <ChevronLeft size={20} />
                </button>
                <h2 className="text-lg font-bold text-slate-800 min-w-[180px] text-center">
                    {MONTHS_VI[month]} {year}
                </h2>
                <button onClick={nextMonth} className="w-10 h-10 bg-indigo-500 hover:bg-indigo-600 text-white rounded-full shadow-md flex items-center justify-center transition-all active:scale-90">
                    <ChevronRight size={20} />
                </button>
            </div>

            {/* Gantt Chart */}
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                    <div className="min-w-max">
                        {/* Day Headers */}
                        <div className="flex border-b border-slate-200">
                            <div className="w-56 min-w-[14rem] px-4 py-3 text-[11px] font-bold text-slate-500 uppercase tracking-wider bg-slate-50 border-r border-slate-200 sticky left-0 z-10 flex items-center">
                                Tên
                            </div>
                            {days.map(day => {
                                const today = isToday(day)
                                const weekend = isWeekend(day)
                                return (
                                    <div key={day} style={{ width: `${CELL_W}px`, minWidth: `${CELL_W}px` }}
                                        className={`text-center flex flex-col items-center justify-center py-2 border-r border-slate-100 ${
                                            today ? 'bg-orange-500' : weekend ? 'bg-red-50' : 'bg-blue-50/40'
                                        }`}>
                                        <div className={`text-[12px] font-bold ${today ? 'text-white' : 'text-slate-700'}`}>{day}</div>
                                        <div className={`text-[9px] font-medium ${
                                            today ? 'text-white/80' : weekend ? 'text-red-400' : 'text-blue-400'
                                        }`}>{getDayName(day)}</div>
                                    </div>
                                )
                            })}
                        </div>

                        {/* Gantt Rows */}
                        <div className="max-h-[550px] overflow-y-auto">
                            {ganttItems.length === 0 ? (
                                <div className="py-20 text-center">
                                    <PackageOpen size={48} className="mx-auto text-slate-300 mb-3" />
                                    <p className="text-sm text-slate-400">
                                        Không có dự án hoặc nhiệm vụ nào trong {MONTHS_VI[month]} {year}
                                    </p>
                                </div>
                            ) : (
                                ganttItems.map((item, idx) => (
                                    <div key={item.id + idx} className="flex border-b border-slate-50 hover:bg-slate-50/60 transition-colors group">
                                        {/* Name column */}
                                        <div className={`w-56 min-w-[14rem] px-4 py-3 text-[11px] border-r border-slate-100 sticky left-0 bg-white z-10 truncate group-hover:bg-slate-50 transition-colors ${
                                            item.type === 'project' ? 'font-bold text-slate-700' : 'text-slate-500 pl-6 font-medium'
                                        }`} title={item.name}>
                                            {item.name}
                                        </div>
                                        {/* Grid cells + bar */}
                                        <div className="flex-1 flex relative" style={{ minHeight: '40px' }}>
                                            {days.map(day => (
                                                <div key={day} style={{ width: `${CELL_W}px`, minWidth: `${CELL_W}px` }}
                                                    className={`border-r border-slate-50/50 ${isToday(day) ? 'bg-orange-50/50' : ''}`}>
                                                </div>
                                            ))}
                                            {/* Bar */}
                                            <div
                                                className={`absolute top-1/2 -translate-y-1/2 rounded-full shadow-sm ${item.color} ${
                                                    item.type === 'project' ? 'h-5 opacity-90' : 'h-3.5 opacity-70'
                                                }`}
                                                style={{
                                                    left: `${(item.startDay - 1) * CELL_W + 4}px`,
                                                    width: `${Math.max((item.endDay - item.startDay + 1) * CELL_W - 8, CELL_W - 8)}px`
                                                }}
                                            >
                                                {item.type === 'task' && item.completion !== undefined && (item.endDay - item.startDay) * CELL_W > 40 && (
                                                    <div className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white/90">
                                                        {item.completion}%
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
