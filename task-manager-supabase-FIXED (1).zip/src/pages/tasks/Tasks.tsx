import { useEffect, useState } from 'react'
import { supabase } from '../../services/supabase'
import { useAuthStore } from '../../store/authStore'
import { type Task, type Project } from '../../types'
import { Plus, Search, Edit3, Trash2, Copy, X, ExternalLink } from 'lucide-react'
import { format, parseISO } from 'date-fns'

export const Tasks = () => {
    const { profile } = useAuthStore()
    const [tasks, setTasks] = useState<Task[]>([])
    const [projects, setProjects] = useState<Project[]>([])
    const [profiles, setProfiles] = useState<any[]>([])
    const [loading, setLoading] = useState(true)
    const [search, setSearch] = useState('')
    const [statusFilter, setStatusFilter] = useState('')
    const [showModal, setShowModal] = useState(false)
    const [editingTask, setEditingTask] = useState<Task | null>(null)
    const [form, setForm] = useState({ task_code: '', project_id: '', name: '', description: '', assignee_id: '', status: 'Chưa bắt đầu', priority: 'Trung bình', start_date: '', due_date: '', completion_pct: 0, target: '', result_links: '', output: '', notes: '' })

    useEffect(() => { fetchAll() }, [profile])

    const fetchAll = async () => {
        try {
            setLoading(true)
            const [{ data: t }, { data: p }, { data: pr }] = await Promise.all([
                supabase.from('tasks').select('*').order('created_at', { ascending: true }),
                supabase.from('projects').select('*'),
                supabase.from('profiles').select('id, full_name, role')
            ])
            setTasks((t || []) as Task[])
            setProjects((p || []) as Project[])
            setProfiles(pr || [])
        } catch (err) { console.error(err) } finally { setLoading(false) }
    }

    const getName = (id: string | null) => !id ? 'Chưa gán' : (profiles.find(x => x.id === id)?.full_name || 'N/A')
    const getProjCode = (id: string) => projects.find(x => x.id === id)?.project_code || ''

    const statusCounts = [
        { label: 'Chưa bắt đầu', count: tasks.filter(t => t.status === 'Chưa bắt đầu').length, icon: '⏸', color: 'text-slate-600' },
        { label: 'Đang thực hiện', count: tasks.filter(t => t.status?.includes('Đang')).length, icon: '🔵', color: 'text-blue-600' },
        { label: 'Hoàn thành', count: tasks.filter(t => t.status?.includes('Hoàn thành')).length, icon: '🟢', color: 'text-emerald-600' },
        { label: 'Tạm dừng', count: tasks.filter(t => t.status === 'Tạm dừng').length, icon: '🟡', color: 'text-amber-600' },
    ]

    const filtered = tasks.filter(t => {
        const ms = t.name.toLowerCase().includes(search.toLowerCase()) || t.task_code.toLowerCase().includes(search.toLowerCase())
        const mf = statusFilter ? (statusFilter === 'Đang thực hiện' ? t.status?.includes('Đang') : t.status === statusFilter) : true
        return ms && mf
    })

    const grouped: Record<string, Task[]> = {}
    filtered.forEach(t => { if (!grouped[t.project_id]) grouped[t.project_id] = []; grouped[t.project_id].push(t) })

    const statusBadge = (s: string) => {
        if (s?.includes('Hoàn thành')) return 'bg-emerald-500 text-white'
        if (s?.includes('Đang')) return 'bg-blue-500 text-white'
        if (s?.includes('Tạm')) return 'bg-amber-500 text-white'
        if (s?.includes('Hủy')) return 'bg-red-500 text-white'
        return 'bg-slate-300 text-white'
    }

    const priorityBadge = (p: string) => {
        if (p === 'Cao' || p === 'Khẩn cấp') return 'bg-red-50 text-red-600 border-red-200'
        if (p === 'Trung bình') return 'bg-amber-50 text-amber-600 border-amber-200'
        return 'bg-emerald-50 text-emerald-600 border-emerald-200'
    }

    const isOverdue = (t: Task) => !t.status?.includes('Hoàn thành') && t.due_date && new Date(t.due_date) < new Date()

    const openAdd = (pid?: string) => {
        setEditingTask(null)
        const cnt = tasks.filter(t => t.project_id === pid).length
        const pc = pid ? getProjCode(pid) : ''
        setForm({ task_code: pc ? `${pc}-${String(cnt + 1).padStart(2, '0')}` : '', project_id: pid || '', name: '', description: '', assignee_id: '', status: 'Chưa bắt đầu', priority: 'Trung bình', start_date: '', due_date: '', completion_pct: 0, target: '', result_links: '', output: '', notes: '' })
        setShowModal(true)
    }

    const openEdit = (t: Task) => {
        setEditingTask(t)
        setForm({ task_code: t.task_code, project_id: t.project_id, name: t.name, description: t.description || '', assignee_id: t.assignee_id || '', status: t.status, priority: t.priority, start_date: t.start_date || '', due_date: t.due_date || '', completion_pct: t.completion_pct, target: t.target || '', result_links: t.result_links || '', output: t.output || '', notes: t.notes || '' })
        setShowModal(true)
    }

    const handleSave = async () => {
        const payload = { name: form.name, description: form.description || null, assignee_id: form.assignee_id || null, status: form.status, priority: form.priority, start_date: form.start_date || null, due_date: form.due_date || null, completion_pct: Number(form.completion_pct), target: form.target || null, result_links: form.result_links || null, output: form.output || null, notes: form.notes || null }
        if (editingTask) await supabase.from('tasks').update(payload).eq('id', editingTask.id)
        else await supabase.from('tasks').insert({ ...payload, task_code: form.task_code, project_id: form.project_id })
        setShowModal(false); fetchAll()
    }

    const handleDel = async (id: string) => { if (confirm('Xóa nhiệm vụ này?')) { await supabase.from('tasks').delete().eq('id', id); fetchAll() } }

    const handleCopy = async (t: Task) => {
        const cnt = tasks.filter(x => x.project_id === t.project_id).length
        const pc = getProjCode(t.project_id)
        await supabase.from('tasks').insert({ task_code: `${pc}-${String(cnt + 1).padStart(2, '0')}`, project_id: t.project_id, name: `${t.name} (Bản sao)`, description: t.description, assignee_id: t.assignee_id, status: 'Chưa bắt đầu', priority: t.priority, start_date: t.start_date, due_date: t.due_date, completion_pct: 0, target: t.target })
        fetchAll()
    }

    if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div></div>

    return (
        <div className="space-y-5 max-w-[1400px] mx-auto">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h1 className="text-xl font-bold text-slate-800">Quản lý nhiệm vụ</h1>
                <div className="flex items-center gap-3 w-full sm:w-auto">
                    <div className="relative flex-1 sm:w-56">
                        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm kiếm nhiệm vụ..." className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
                    </div>
                    <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="border border-slate-200 rounded-xl px-3 py-2 text-sm bg-white">
                        <option value="">Tất cả</option>
                        <option>Chưa bắt đầu</option><option>Đang thực hiện</option><option>Hoàn thành</option><option>Tạm dừng</option>
                    </select>
                    <button onClick={() => openAdd()} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-1.5 whitespace-nowrap shadow-sm">
                        <Plus size={16} /> Tạo nhiệm vụ mới
                    </button>
                </div>
            </div>

            {/* Status circles */}
            <div className="grid grid-cols-4 gap-4">
                {statusCounts.map(s => (
                    <button key={s.label} onClick={() => setStatusFilter(statusFilter === s.label ? '' : s.label)}
                        className={`bg-white border rounded-2xl p-4 flex items-center justify-center gap-3 transition-all shadow-sm ${statusFilter === s.label ? 'ring-2 ring-indigo-500 border-indigo-300' : 'border-slate-100 hover:border-slate-200'}`}>
                        <span className={`${s.color} font-bold text-lg`}>{s.icon} {s.count}</span>
                        <span className="text-xs font-semibold text-slate-500">{s.label}</span>
                    </button>
                ))}
            </div>

            {/* Grouped tables */}
            <div className="space-y-5">
                {Object.entries(grouped).map(([pid, ptasks]) => {
                    const proj = projects.find(p => p.id === pid)
                    if (!proj) return null
                    return (
                        <div key={pid} className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                            <div className="px-5 py-3.5 bg-slate-50/50 border-b border-slate-100 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <h3 className="text-[13px] font-bold text-slate-800">{proj.name} ({proj.project_code})</h3>
                                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${statusBadge(proj.status)}`}>{proj.status}</span>
                                </div>
                                <div className="flex items-center gap-3 text-[11px] text-slate-500">
                                    <span>{getName(proj.manager_id)} • {proj.start_date ? format(parseISO(proj.start_date), 'dd/MM/yyyy') : ''} - {proj.end_date ? format(parseISO(proj.end_date), 'dd/MM/yyyy') : ''}</span>
                                    <span className="font-semibold">{ptasks.length} nhiệm vụ</span>
                                    <button onClick={() => openAdd(pid)} className="text-indigo-600 font-bold hover:underline">+ Thêm</button>
                                </div>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-[11px]">
                                    <thead>
                                        <tr className="bg-slate-50/30 border-b border-slate-100 text-slate-500 uppercase font-bold tracking-wider">
                                            <th className="px-4 py-3 text-left w-8"><input type="checkbox" className="rounded border-slate-300" /></th>
                                            <th className="px-3 py-3 text-left min-w-[180px]">NHIỆM VỤ</th>
                                            <th className="px-3 py-3 text-left">NGƯỜI THỰC HIỆN</th>
                                            <th className="px-3 py-3 text-left">TRẠNG THÁI</th>
                                            <th className="px-3 py-3 text-left">ƯU TIÊN</th>
                                            <th className="px-3 py-3 text-left">TIẾN ĐỘ</th>
                                            <th className="px-3 py-3 text-left">LINK KẾT QUẢ</th>
                                            <th className="px-3 py-3 text-left">NGÀY BẮT ĐẦU</th>
                                            <th className="px-3 py-3 text-left">HẠN CHÓT</th>
                                            <th className="px-3 py-3 text-center">THAO TÁC</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-50">
                                        {ptasks.map(task => (
                                            <tr key={task.id} className="hover:bg-slate-50/50 transition-colors">
                                                <td className="px-4 py-3"><input type="checkbox" checked={!!task.status?.includes('Hoàn thành')} readOnly className="rounded border-slate-300 text-indigo-600" /></td>
                                                <td className="px-3 py-3"><p className="font-bold text-slate-800">{task.name}</p><p className="text-[10px] text-slate-400">{task.task_code}</p></td>
                                                <td className="px-3 py-3 text-slate-600 font-medium">{getName(task.assignee_id)}</td>
                                                <td className="px-3 py-3">
                                                    <div className="flex items-center gap-1 flex-wrap">
                                                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${statusBadge(task.status)}`}>{task.status}</span>
                                                        {isOverdue(task) && <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-red-500 text-white">Quá hạn</span>}
                                                    </div>
                                                </td>
                                                <td className="px-3 py-3"><span className={`px-2 py-0.5 rounded text-[9px] font-bold border ${priorityBadge(task.priority)}`}>{task.priority}</span></td>
                                                <td className="px-3 py-3">
                                                    <div className="flex items-center gap-2">
                                                        <div className="w-16 bg-slate-100 rounded-full h-1.5"><div className={`h-1.5 rounded-full ${task.completion_pct >= 100 ? 'bg-emerald-500' : 'bg-blue-500'}`} style={{ width: `${task.completion_pct}%` }}></div></div>
                                                        <span className="font-bold text-slate-500">{task.completion_pct}%</span>
                                                    </div>
                                                </td>
                                                <td className="px-3 py-3">{task.result_links ? <a href={task.result_links} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline flex items-center gap-1 font-semibold"><ExternalLink size={11} /> Xem</a> : <span className="text-slate-400">Chưa có</span>}</td>
                                                <td className="px-3 py-3 text-slate-500">{task.start_date ? format(parseISO(task.start_date), 'dd/MM/yyyy') : '---'}</td>
                                                <td className="px-3 py-3 text-slate-500">{task.due_date ? format(parseISO(task.due_date), 'dd/MM/yyyy') : '---'}</td>
                                                <td className="px-3 py-3">
                                                    <div className="flex items-center justify-center gap-1">
                                                        <button onClick={() => handleCopy(task)} className="w-6 h-6 bg-blue-50 text-blue-500 rounded flex items-center justify-center hover:bg-blue-100"><Copy size={11} /></button>
                                                        <button onClick={() => openEdit(task)} className="w-6 h-6 bg-amber-50 text-amber-500 rounded flex items-center justify-center hover:bg-amber-100"><Edit3 size={11} /></button>
                                                        <button onClick={() => handleDel(task.id)} className="w-6 h-6 bg-red-50 text-red-500 rounded flex items-center justify-center hover:bg-red-100"><Trash2 size={11} /></button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )
                })}
            </div>

            {/* Modal */}
            {showModal && (
                <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden">
                        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                            <h3 className="text-base font-bold text-slate-800">{editingTask ? 'Sửa nhiệm vụ' : 'Thêm nhiệm vụ mới'}</h3>
                            <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg"><X size={18} /></button>
                        </div>
                        <div className="p-6 overflow-y-auto max-h-[65vh] space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Dự án</label>
                                    <select value={form.project_id} onChange={e => setForm({ ...form, project_id: e.target.value })} disabled={!!editingTask} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm">
                                        <option value="">Chọn dự án</option>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                                    </select></div>
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Mã nhiệm vụ</label>
                                    <input value={form.task_code} onChange={e => setForm({ ...form, task_code: e.target.value })} disabled={!!editingTask} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" /></div>
                            </div>
                            <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tên nhiệm vụ</label>
                                <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" placeholder="Nhập tên..." /></div>
                            <div className="grid grid-cols-3 gap-4">
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Người thực hiện</label>
                                    <select value={form.assignee_id} onChange={e => setForm({ ...form, assignee_id: e.target.value })} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm">
                                        <option value="">Chọn</option>{profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                                    </select></div>
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Trạng thái</label>
                                    <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm">
                                        <option>Chưa bắt đầu</option><option>Đang thực hiện</option><option>Hoàn thành</option><option>Tạm dừng</option><option>Hủy bỏ</option>
                                    </select></div>
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Ưu tiên</label>
                                    <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm">
                                        <option>Thấp</option><option>Trung bình</option><option>Cao</option><option>Khẩn cấp</option>
                                    </select></div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Ngày bắt đầu</label>
                                    <input type="date" value={form.start_date} onChange={e => setForm({ ...form, start_date: e.target.value })} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" /></div>
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Hạn chót</label>
                                    <input type="date" value={form.due_date} onChange={e => setForm({ ...form, due_date: e.target.value })} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" /></div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tiến độ (%)</label>
                                    <input type="number" min="0" max="100" value={form.completion_pct} onChange={e => setForm({ ...form, completion_pct: parseInt(e.target.value) || 0 })} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" /></div>
                                <div><label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Link kết quả</label>
                                    <input value={form.result_links} onChange={e => setForm({ ...form, result_links: e.target.value })} className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm" placeholder="https://..." /></div>
                            </div>
                        </div>
                        <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
                            <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-500">Hủy</button>
                            <button onClick={handleSave} className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-sm">{editingTask ? 'Cập nhật' : 'Tạo nhiệm vụ'}</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}
