import { useEffect, useState } from 'react'
import { supabase } from '../../services/supabase'
import { useAuthStore } from '../../store/authStore'
import { type Task, type Project, type ActivityLog } from '../../types'
import {
    Eye, Edit3, Copy, Trash2, Calendar
} from 'lucide-react'
import { format, parseISO, subDays, isSameDay } from 'date-fns'
import {
    PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, LineChart, Line, ComposedChart
} from 'recharts'

const COLORS_STATUS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6']
const COLORS_PRIORITY = ['#10b981', '#f59e0b', '#ef4444']

export const Dashboard = () => {
    const { profile } = useAuthStore()
    const [projects, setProjects] = useState<Project[]>([])
    const [tasks, setTasks] = useState<Task[]>([])
    const [profiles, setProfiles] = useState<any[]>([])
    const [recentActivities, setRecentActivities] = useState<ActivityLog[]>([])
    const [taskStatusData, setTaskStatusData] = useState<any[]>([])
    const [projectProgressData, setProjectProgressData] = useState<any[]>([])
    const [taskPriorityData, setTaskPriorityData] = useState<any[]>([])
    const [employeeData, setEmployeeData] = useState<any[]>([])
    const [trendData, setTrendData] = useState<any[]>([])
    const [projectCompareData, setProjectCompareData] = useState<any[]>([])
    const [loading, setLoading] = useState(true)

    useEffect(() => { fetchDashboardData() }, [profile])

    const fetchDashboardData = async () => {
        try {
            setLoading(true)
            const [{ data: proj }, { data: t }, { data: pr }] = await Promise.all([
                supabase.from('projects').select('*'),
                supabase.from('tasks').select('*'),
                supabase.from('profiles').select('*')
            ])

            const allTasks = (t || []) as Task[]
            const allProjects = (proj || []) as Project[]
            const allProfiles = pr || []

            setProjects(allProjects)
            setTasks(allTasks)
            setProfiles(allProfiles)

            // Task status data
            const statusMap: Record<string, number> = {}
            const priorityMap: Record<string, number> = {}
            allTasks.forEach((task: Task) => {
                const s = task.status || 'Chưa bắt đầu'
                statusMap[s] = (statusMap[s] || 0) + 1
                if (task.priority) priorityMap[task.priority] = (priorityMap[task.priority] || 0) + 1
            })
            setTaskStatusData(Object.entries(statusMap).map(([name, value]) => ({ name, value })))
            setTaskPriorityData(Object.entries(priorityMap).map(([name, value]) => ({ name, value })))

            // Project progress distribution
            const ranges = [
                { label: '0-25%', min: 0, max: 25, color: '#6366f1' },
                { label: '26-50%', min: 26, max: 50, color: '#f59e0b' },
                { label: '51-75%', min: 51, max: 75, color: '#3b82f6' },
                { label: '76-99%', min: 76, max: 99, color: '#10b981' },
                { label: '100%', min: 100, max: 100, color: '#10b981' },
            ]
            const progressDist = ranges.map(r => {
                const count = allProjects.filter(p => {
                    const pTasks = allTasks.filter(x => x.project_id === p.id)
                    const total = pTasks.length
                    const done = pTasks.filter(x => x.status?.includes('Hoàn thành')).length
                    const pct = total > 0 ? Math.round((done / total) * 100) : 0
                    return pct >= r.min && pct <= r.max
                }).length
                return { name: r.label, 'Số lượng dự án': count, fill: r.color }
            })
            setProjectProgressData(progressDist)

            // Employee efficiency
            const empMap: Record<string, { total: number, done: number }> = {}
            allTasks.forEach((task: any) => {
                if (!task.assignee_id) return
                if (!empMap[task.assignee_id]) empMap[task.assignee_id] = { total: 0, done: 0 }
                empMap[task.assignee_id].total++
                if (task.status?.includes('Hoàn thành')) empMap[task.assignee_id].done++
            })
            setEmployeeData(Object.entries(empMap).map(([id, data]) => {
                const prof = allProfiles.find((p: any) => p.id === id)
                return {
                    name: prof?.full_name || id.substring(0, 6),
                    'Tổng số nhiệm vụ': data.total,
                    'Tỷ lệ hoàn thành (%)': data.total > 0 ? Math.round((data.done / data.total) * 100) : 0
                }
            }).slice(0, 6))

            // Completion trend (last 30 days)
            const last30 = Array.from({ length: 30 }, (_, i) => {
                const d = subDays(new Date(), 29 - i)
                const dateStr = format(d, 'yyyy-MM-dd')
                const shortLabel = format(d, 'd/M')
                const count = allTasks.filter(x =>
                    x.status?.includes('Hoàn thành') && x.report_date && isSameDay(parseISO(x.report_date), d)
                ).length
                return { name: shortLabel, date: dateStr, 'Hoàn thành': count }
            }).filter((_, i) => i % 3 === 0) // show every 3 days
            setTrendData(last30)

            // Project comparison
            setProjectCompareData(allProjects.slice(0, 6).map((p: any) => {
                const projTasks = allTasks.filter(x => x.project_id === p.id)
                const total = projTasks.length
                const done = projTasks.filter(x => x.status?.includes('Hoàn thành')).length
                return {
                    name: p.name?.length > 12 ? p.name.substring(0, 12) + '...' : p.name,
                    'Tổng nhiệm vụ': total,
                    'Tỷ lệ hoàn thành (%)': total > 0 ? Math.round((done / total) * 100) : 0
                }
            }))

            // Activity logs
            const { data: logs } = await supabase.from('activity_logs').select('*').order('created_at', { ascending: false }).limit(5)
            if (logs) setRecentActivities(logs as ActivityLog[])

        } catch (error) { console.error('Error:', error) } finally { setLoading(false) }
    }

    const getManagerName = (id: string) => profiles.find(p => p.id === id)?.full_name || 'N/A'

    const getProjectProgress = (projectId: string) => {
        const projTasks = tasks.filter(t => t.project_id === projectId)
        if (projTasks.length === 0) return 0
        const done = projTasks.filter(t => t.status?.includes('Hoàn thành')).length
        return Math.round((done / projTasks.length) * 100)
    }

    const getProjectTaskCount = (projectId: string) => tasks.filter(t => t.project_id === projectId).length

    const getStatusBadge = (status: string) => {
        if (status?.includes('Hoàn thành')) return 'bg-emerald-100 text-emerald-700'
        if (status?.includes('Đang')) return 'bg-blue-100 text-blue-700'
        if (status?.includes('Tạm dừng')) return 'bg-amber-100 text-amber-700'
        if (status?.includes('Hủy')) return 'bg-red-100 text-red-700'
        return 'bg-slate-100 text-slate-600'
    }

    const getProgressColor = (pct: number) => {
        if (pct >= 80) return 'bg-red-500'
        if (pct >= 50) return 'bg-emerald-500'
        if (pct > 0) return 'bg-blue-500'
        return 'bg-slate-300'
    }

    if (loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div></div>

    return (
        <div className="space-y-5 max-w-[1400px] mx-auto">
            {/* Row 1: Activity Feed + Project Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
                {/* Activity Feed - Left column */}
                <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl shadow-sm">
                    <div className="px-5 py-4 border-b border-slate-100">
                        <h3 className="text-sm font-bold text-slate-800">Hoạt động gần đây</h3>
                    </div>
                    <div className="p-5 max-h-[380px] overflow-y-auto">
                        {recentActivities.length === 0 ? (
                            <div className="text-center py-10 text-slate-400 text-sm">Chưa có hoạt động nào</div>
                        ) : (
                            <div className="space-y-5">
                                {recentActivities.map((a, idx) => (
                                    <div key={a.id} className="flex gap-3">
                                        <div className="flex flex-col items-center">
                                            <div className={`w-3 h-3 rounded-full z-10 ring-4 ring-white flex-shrink-0 ${
                                                a.action?.includes('Thêm dự án') ? 'bg-blue-500' :
                                                a.action?.includes('nhiệm vụ') ? 'bg-indigo-500' : 'bg-emerald-500'
                                            }`}></div>
                                            {idx < recentActivities.length - 1 && <div className="w-px flex-1 bg-slate-200 mt-1"></div>}
                                        </div>
                                        <div className="flex-1 pb-1 min-w-0">
                                            <p className="text-[13px] font-semibold text-slate-800">{a.action}</p>
                                            <p className="text-[11px] text-slate-500 mt-1 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100 line-clamp-2">{a.details}</p>
                                            <p className="text-[10px] text-slate-400 mt-1">{a.created_at ? format(parseISO(a.created_at), 'dd/MM/yyyy HH:mm') : ''}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Project Cards Grid - Right columns */}
                <div className="lg:col-span-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {projects.slice(0, 4).map((project) => {
                            const progress = getProjectProgress(project.id)
                            const taskCount = getProjectTaskCount(project.id)
                            return (
                                <div key={project.id} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow">
                                    {/* Header */}
                                    <div className="flex items-start justify-between mb-3">
                                        <h4 className="text-[13px] font-bold text-slate-800 flex-1 leading-tight pr-2">{project.name}</h4>
                                        <div className="flex items-center gap-1 flex-shrink-0">
                                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${getStatusBadge(project.status)}`}>
                                                {project.status === 'Đang thực hiện' && new Date(project.end_date || '') < new Date() ? 'Quá hạn' : project.status}
                                            </span>
                                            <button className="w-5 h-5 bg-emerald-50 text-emerald-500 rounded flex items-center justify-center hover:bg-emerald-100"><Eye size={10} /></button>
                                            <button className="w-5 h-5 bg-blue-50 text-blue-500 rounded flex items-center justify-center hover:bg-blue-100"><Edit3 size={10} /></button>
                                            <button className="w-5 h-5 bg-amber-50 text-amber-500 rounded flex items-center justify-center hover:bg-amber-100"><Copy size={10} /></button>
                                            <button className="w-5 h-5 bg-red-50 text-red-500 rounded flex items-center justify-center hover:bg-red-100"><Trash2 size={10} /></button>
                                        </div>
                                    </div>

                                    {/* Info */}
                                    <div className="space-y-1.5 mb-3">
                                        <div className="flex items-center gap-2 text-[11px] text-slate-500">
                                            <span className="w-2 h-2 rounded-full bg-violet-400"></span>
                                            <span className="truncate">{project.description || 'Ứng dụng quản lý côn...'}</span>
                                        </div>
                                        <div className="flex items-center justify-between text-[11px] text-slate-500">
                                            <div className="flex items-center gap-1">
                                                <span className="text-slate-400">👤</span>
                                                <span>{getManagerName(project.manager_id || '')}</span>
                                            </div>
                                            <div className="flex items-center gap-1">
                                                <Calendar size={10} className="text-orange-400" />
                                                <span>{project.end_date ? format(parseISO(project.end_date), 'dd/MM/yyyy') : 'N/A'}</span>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Progress */}
                                    <div className="flex items-center gap-2">
                                        <span className="text-[11px] font-bold text-slate-600">{progress}%</span>
                                        <div className="flex-1 bg-slate-100 rounded-full h-2">
                                            <div
                                                className={`h-2 rounded-full transition-all duration-500 ${getProgressColor(progress)}`}
                                                style={{ width: `${progress}%` }}
                                            ></div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </div>

            {/* Charts Row 1 */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                {/* Task Status Donut */}
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                    <h3 className="text-sm font-bold text-slate-800 mb-4">Trạng thái nhiệm vụ</h3>
                    <ResponsiveContainer width="100%" height={220}>
                        <PieChart>
                            <Pie data={taskStatusData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                                {taskStatusData.map((_, i) => <Cell key={i} fill={COLORS_STATUS[i % COLORS_STATUS.length]} />)}
                            </Pie>
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: '11px' }} />
                        </PieChart>
                    </ResponsiveContainer>
                </div>

                {/* Project Progress Distribution Bar */}
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                    <h3 className="text-sm font-bold text-slate-800 mb-4">Phân bổ tiến độ dự án</h3>
                    <ResponsiveContainer width="100%" height={220}>
                        <BarChart data={projectProgressData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                            <XAxis dataKey="name" tick={{ fontSize: 10 }} label={{ value: 'Khoảng tiến độ', position: 'insideBottom', offset: -5, style: { fontSize: 10, fill: '#94a3b8' } }} />
                            <YAxis tick={{ fontSize: 10 }} label={{ value: 'Số lượng dự án', angle: -90, position: 'insideLeft', offset: 10, style: { fontSize: 10, fill: '#94a3b8' } }} />
                            <Tooltip />
                            <Bar dataKey="Số lượng dự án" radius={[4, 4, 0, 0]}>
                                {projectProgressData.map((entry, i) => (
                                    <Cell key={i} fill={['#6366f1', '#f59e0b', '#3b82f6', '#10b981', '#10b981'][i]} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>

                {/* Priority Distribution Donut */}
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                    <h3 className="text-sm font-bold text-slate-800 mb-4">Phân bổ ưu tiên nhiệm vụ</h3>
                    <ResponsiveContainer width="100%" height={220}>
                        <PieChart>
                            <Pie data={taskPriorityData} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                                {taskPriorityData.map((_, i) => <Cell key={i} fill={COLORS_PRIORITY[i % COLORS_PRIORITY.length]} />)}
                            </Pie>
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: '11px' }} />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Charts Row 2 */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                {/* Employee Efficiency - Combined Bar + Line */}
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                    <h3 className="text-sm font-bold text-slate-800 mb-4">Hiệu quả nhân viên</h3>
                    <ResponsiveContainer width="100%" height={220}>
                        <ComposedChart data={employeeData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                            <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                            <YAxis yAxisId="left" tick={{ fontSize: 10 }} label={{ value: 'Số lượng nhiệm vụ', angle: -90, position: 'insideLeft', offset: 10, style: { fontSize: 9, fill: '#94a3b8' } }} />
                            <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10 }} domain={[0, 100]} label={{ value: '(%)', angle: 90, position: 'insideRight', offset: 10, style: { fontSize: 9, fill: '#94a3b8' } }} />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: '10px' }} />
                            <Bar yAxisId="left" dataKey="Tổng số nhiệm vụ" fill="#6366f1" radius={[4, 4, 0, 0]} />
                            <Line yAxisId="right" type="monotone" dataKey="Tỷ lệ hoàn thành (%)" stroke="#ef4444" strokeWidth={2} dot={{ fill: '#ef4444', r: 3 }} />
                        </ComposedChart>
                    </ResponsiveContainer>
                </div>

                {/* Completion Trend */}
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                    <h3 className="text-sm font-bold text-slate-800 mb-4">Xu hướng hoàn thành</h3>
                    <ResponsiveContainer width="100%" height={220}>
                        <LineChart data={trendData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                            <XAxis dataKey="name" tick={{ fontSize: 9 }} label={{ value: '30 ngày gần đây', position: 'insideBottom', offset: -5, style: { fontSize: 9, fill: '#94a3b8' } }} />
                            <YAxis tick={{ fontSize: 10 }} label={{ value: 'Số lượng nhiệm vụ', angle: -90, position: 'insideLeft', offset: 10, style: { fontSize: 9, fill: '#94a3b8' } }} />
                            <Tooltip />
                            <Line type="monotone" dataKey="Hoàn thành" stroke="#3b82f6" strokeWidth={2} dot={{ fill: '#3b82f6', r: 3 }} activeDot={{ r: 5 }} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>

                {/* Project Comparison - Combined Bar + Line */}
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                    <h3 className="text-sm font-bold text-slate-800 mb-4">So sánh dự án</h3>
                    <ResponsiveContainer width="100%" height={220}>
                        <ComposedChart data={projectCompareData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                            <XAxis dataKey="name" tick={{ fontSize: 8 }} interval={0} angle={-15} />
                            <YAxis yAxisId="left" tick={{ fontSize: 10 }} label={{ value: 'Số lượng nhiệm vụ', angle: -90, position: 'insideLeft', offset: 10, style: { fontSize: 9, fill: '#94a3b8' } }} />
                            <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10 }} domain={[0, 100]} label={{ value: '(%)', angle: 90, position: 'insideRight', offset: 10, style: { fontSize: 9, fill: '#94a3b8' } }} />
                            <Tooltip />
                            <Legend wrapperStyle={{ fontSize: '10px' }} />
                            <Bar yAxisId="left" dataKey="Tổng nhiệm vụ" fill="#6366f1" radius={[4, 4, 0, 0]} />
                            <Line yAxisId="right" type="monotone" dataKey="Tỷ lệ hoàn thành (%)" stroke="#ef4444" strokeWidth={2} dot={{ fill: '#ef4444', r: 3 }} />
                        </ComposedChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    )
}
