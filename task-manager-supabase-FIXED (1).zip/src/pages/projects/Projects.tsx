import { useEffect, useState } from 'react'
import { supabase } from '../../services/supabase'
import { useAuthStore } from '../../store/authStore'
import { type Project, type Task } from '../../types'
import { Plus, Search, Edit3, Trash2, Copy, Eye, X, Calendar, Users, ListChecks } from 'lucide-react'
import { format, parseISO } from 'date-fns'

export const Projects = () => {
    const { profile } = useAuthStore()
    const [projects, setProjects] = useState<Project[]>([])
    const [tasks, setTasks] = useState<Task[]>([])
    const [loading, setLoading] = useState(true)
    const [search, setSearch] = useState('')
    const [statusFilter, setStatusFilter] = useState('')
    const [showModal, setShowModal] = useState(false)
    const [editingProject, setEditingProject] = useState<Project | null>(null)
    const [profiles, setProfiles] = useState<any[]>([])
    const [form, setForm] = useState({
        name: '', project_code: '', description: '', status: 'Chưa bắt đầu',
        start_date: '', end_date: '', manager_id: '', budget: 0
    })

    useEffect(() => { fetchData() }, [])

    const fetchData = async () => {
        try {
            setLoading(true)
            const [{ data: p }, { data: t }, { data: pr }] = await Promise.all([
                supabase.from('projects').select('*').order('created_at', { ascending: false }),
                supabase.from('tasks').select('*'),
                supabase.from('profiles').select('id, full_name')
            ])
            if (p) setProjects(p as Project[])
            if (t) setTasks(t as Task[])
            if (pr) setProfiles(pr)
        } catch (err) { console.error(err) } finally { setLoading(false) }
    }

    const getProjectProgress = (projectId: string) => {
        const projTasks = tasks.filter(t => t.project_id === projectId)
        if (projTasks.length === 0) return 0
        const done = projTasks.filter(t => t.status?.includes('Hoàn thành')).length
        return Math.round((done / projTasks.length) * 100)
    }

    const getProjectTaskCount = (projectId: string) => tasks.filter(t => t.project_id === projectId).length

    const filteredProjects = projects.filter(p => {
        const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.project_code.toLowerCase().includes(search.toLowerCase())
        const matchStatus = statusFilter ? (statusFilter === 'Chưa bắt đầu' ? (p.status === 'Chưa bắt đầu' || p.status === 'Mới') : p.status === statusFilter) : true
        return matchSearch && matchStatus
    })

    const statusCounts = [
        { label: 'Chưa bắt đầu', count: projects.filter(p => p.status === 'Chưa bắt đầu' || p.status === 'Mới').length, icon: '⏸', color: 'text-slate-600', bg: 'bg-slate-50', border: 'border-slate-200' },
        { label: 'Đang thực hiện', count: projects.filter(p => p.status === 'Đang thực hiện').length, icon: '🔵', color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' },
        { label: 'Hoàn thành', count: projects.filter(p => p.status === 'Hoàn thành').length, icon: '🟢', color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200' },
        { label: 'Tạm dừng', count: projects.filter(p => p.status === 'Tạm dừng').length, icon: '🟡', color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200' },
        { label: 'Hủy bỏ', count: projects.filter(p => p.status === 'Hủy bỏ').length, icon: '🔴', color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' },
    ]

    const getStatusBadge = (status: string) => {
        if (status === 'Hoàn thành') return 'bg-emerald-500 text-white'
        if (status === 'Đang thực hiện') return 'bg-blue-500 text-white'
        if (status === 'Tạm dừng') return 'bg-amber-500 text-white'
        if (status === 'Hủy bỏ') return 'bg-red-500 text-white'
        return 'bg-slate-400 text-white'
    }

    const getManagerName = (id: string) => profiles.find(p => p.id === id)?.full_name || 'N/A'

    const getProgressColor = (pct: number) => {
        if (pct >= 100) return { bar: 'bg-emerald-500', text: 'text-emerald-600' }
        if (pct >= 60) return { bar: 'bg-gradient-to-r from-blue-500 to-purple-500', text: 'text-purple-600' }
        if (pct > 0) return { bar: 'bg-blue-500', text: 'text-blue-600' }
        return { bar: 'bg-red-400', text: 'text-red-500' }
    }

    const openAddModal = () => {
        setEditingProject(null)
        const count = projects.length + 1
        setForm({ name: '', project_code: `DA${String(count).padStart(3, '0')}`, description: '', status: 'Chưa bắt đầu', start_date: '', end_date: '', manager_id: profile?.id || '', budget: 0 })
        setShowModal(true)
    }

    const openEditModal = (p: Project) => {
        setEditingProject(p)
        setForm({ name: p.name, project_code: p.project_code, description: p.description || '', status: p.status, start_date: p.start_date || '', end_date: p.end_date || '', manager_id: p.manager_id || '', budget: p.budget || 0 })
        setShowModal(true)
    }

    const handleSave = async () => {
        try {
            const payload = { ...form, updated_at: new Date().toISOString() }
            if (editingProject) {
                await supabase.from('projects').update(payload).eq('id', editingProject.id)
            } else {
                await supabase.from('projects').insert(payload)
            }
            setShowModal(false)
            fetchData()
        } catch (err) { console.error(err) }
    }

    const handleDelete = async (id: string) => {
        if (!confirm('Xóa dự án này?')) return
        await supabase.from('projects').delete().eq('id', id)
        fetchData()
    }

    const handleCopy = async (p: Project) => {
        const count = projects.length + 1
        const payload = { ...p, id: undefined, project_code: `DA${String(count).padStart(3, '0')}`, name: `${p.name} (Bản sao)`, created_at: undefined, updated_at: undefined }
        delete (payload as any).id
        delete (payload as any).created_at
        delete (payload as any).updated_at
        await supabase.from('projects').insert(payload)
        fetchData()
    }

    if (loading) return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div></div>

    return (
        <div className="space-y-5 max-w-[1400px] mx-auto">
            {/* Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h1 className="text-xl font-bold text-slate-800">Quản lý dự án</h1>
                <div className="flex items-center gap-3 w-full sm:w-auto">
                    <div className="relative flex-1 sm:w-56">
                        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm kiếm dự án..."
                            className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
                    </div>
                    <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}
                        className="border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 bg-white">
                        <option value="">Tất cả</option>
                        <option>Chưa bắt đầu</option><option>Đang thực hiện</option><option>Hoàn thành</option><option>Tạm dừng</option><option>Hủy bỏ</option>
                    </select>
                    <button onClick={openAddModal} className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-sm">
                        <Plus size={16} /> Tạo dự án mới
                    </button>
                </div>
            </div>

            {/* Status Circles - matching screenshot */}
            <div className="grid grid-cols-5 gap-4">
                {statusCounts.map((s) => (
                    <button key={s.label} onClick={() => setStatusFilter(statusFilter === s.label ? '' : s.label)}
                        className={`bg-white border rounded-2xl p-4 flex items-center justify-center gap-3 transition-all shadow-sm ${statusFilter === s.label ? 'ring-2 ring-indigo-500 border-indigo-300' : 'border-slate-100 hover:border-slate-200'}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-lg font-bold ${s.bg}`}>
                            <span className={`${s.color} font-bold text-sm`}>{s.icon} {s.count}</span>
                        </div>
                        <span className="text-xs font-semibold text-slate-500">{s.label}</span>
                    </button>
                ))}
            </div>

            {/* Project Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredProjects.map((project) => {
                    const progress = getProjectProgress(project.id)
                    const taskCount = getProjectTaskCount(project.id)
                    const colors = getProgressColor(progress)

                    return (
                        <div key={project.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow">
                            {/* Top: status + action buttons */}
                            <div className="flex items-start justify-between mb-3">
                                <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase ${getStatusBadge(project.status)}`}>
                                    {project.status}
                                </span>
                                <div className="flex gap-1">
                                    <button onClick={() => handleCopy(project)} className="w-6 h-6 bg-blue-50 text-blue-500 rounded-lg flex items-center justify-center hover:bg-blue-100 border border-blue-100"><Plus size={11} /></button>
                                    <button className="w-6 h-6 bg-emerald-50 text-emerald-500 rounded-lg flex items-center justify-center hover:bg-emerald-100 border border-emerald-100"><Eye size={11} /></button>
                                    <button className="w-6 h-6 bg-orange-50 text-orange-500 rounded-lg flex items-center justify-center hover:bg-orange-100 border border-orange-100"><Copy size={11} /></button>
                                    <button onClick={() => openEditModal(project)} className="w-6 h-6 bg-amber-50 text-amber-500 rounded-lg flex items-center justify-center hover:bg-amber-100 border border-amber-100"><Edit3 size={11} /></button>
                                    <button onClick={() => handleDelete(project.id)} className="w-6 h-6 bg-red-50 text-red-500 rounded-lg flex items-center justify-center hover:bg-red-100 border border-red-100"><Trash2 size={11} /></button>
                                </div>
                            </div>

                            {/* Title & description */}
                            <h3 className="text-[14px] font-bold text-slate-800 mb-1">{project.name} ({project.project_code})</h3>
                            <p className="text-[11px] text-slate-500 line-clamp-1 mb-3">{project.description || 'Không có mô tả'}</p>

                            {/* Info rows */}
                            <div className="space-y-2 mb-4">
                                <div className="flex items-center gap-2 text-[11px] text-slate-600">
                                    <Calendar size={12} className="text-emerald-500 flex-shrink-0" />
                                    <span>Bắt đầu: {project.start_date ? format(parseISO(project.start_date), 'dd/MM/yyyy') : 'N/A'}</span>
                                    <span className="mx-1 text-slate-300">•</span>
                                    <Calendar size={12} className="text-rose-500 flex-shrink-0" />
                                    <span>Kết thúc: {project.end_date ? format(parseISO(project.end_date), 'dd/MM/yyyy') : 'N/A'}</span>
                                </div>
                                <div className="flex items-center justify-between text-[11px] text-slate-600">
                                    <div className="flex items-center gap-1.5">
                                        <Users size={12} className="text-indigo-500" />
                                        <span>Quản lý: {getManagerName(project.manager_id || '')}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <ListChecks size={12} className="text-slate-400" />
                                        <span>{taskCount} nhiệm vụ</span>
                                    </div>
                                </div>
                            </div>

                            {/* Progress bar */}
                            <div className="pt-3 border-t border-slate-100">
                                <div className="flex items-center justify-between mb-1.5">
                                    <span className="text-[11px] font-semibold text-slate-500">Tiến độ</span>
                                    <span className={`text-[12px] font-bold ${colors.text}`}>{progress}%</span>
                                </div>
                                <div className="bg-slate-100 rounded-full h-2">
                                    <div className={`h-2 rounded-full transition-all duration-500 ${colors.bar}`} style={{ width: `${progress}%` }}></div>
                                </div>
                            </div>
                        </div>
                    )
                })}
            </div>

            {/* Modal */}
            {showModal && (
                <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-fade-in">
                        <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                            <h3 className="text-base font-bold text-slate-800">{editingProject ? 'Sửa dự án' : 'Tạo dự án mới'}</h3>
                            <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-white rounded-lg"><X size={18} /></button>
                        </div>
                        <div className="p-6 space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Mã dự án</label>
                                    <input type="text" value={form.project_code} onChange={(e) => setForm({ ...form, project_code: e.target.value })}
                                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20" disabled={!!editingProject} />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Trạng thái</label>
                                    <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}
                                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
                                        <option>Chưa bắt đầu</option><option>Đang thực hiện</option><option>Hoàn thành</option><option>Tạm dừng</option><option>Hủy bỏ</option>
                                    </select>
                                </div>
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tên dự án</label>
                                <input type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20" placeholder="Nhập tên dự án..." />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Ngày bắt đầu</label>
                                    <input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })}
                                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
                                </div>
                                <div>
                                    <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Ngày kết thúc</label>
                                    <input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })}
                                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
                                </div>
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Quản lý</label>
                                <select value={form.manager_id} onChange={(e) => setForm({ ...form, manager_id: e.target.value })}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
                                    <option value="">Chọn quản lý</option>
                                    {profiles.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Mô tả</label>
                                <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2}
                                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20" placeholder="Mô tả..." />
                            </div>
                        </div>
                        <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
                            <button onClick={() => setShowModal(false)} className="px-4 py-2 text-sm font-medium text-slate-500 hover:text-slate-700">Hủy</button>
                            <button onClick={handleSave} className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-semibold shadow-sm transition-all">
                                {editingProject ? 'Cập nhật' : 'Tạo dự án'}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}
