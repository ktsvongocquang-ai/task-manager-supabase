import { useRef, useState, useEffect, ChangeEvent, MouseEvent as ReactMouseEvent, DragEvent, Fragment } from 'react';
import { FloorPlan, MarkerNote, WhiteboardAnnotation, UserRoleProfile, Project } from '../types';
import { 
  Map, Plus, Upload, Maximize2, Minimize2, MousePointer, 
  Square, Circle, ArrowUpRight, Paintbrush, StickyNote, Type, 
  Trash2, Undo2, Redo2, MessageSquare, Check, GripHorizontal, 
  ZoomIn, ZoomOut, Sparkles, RefreshCw, Layers, Pin,
  Triangle, Diamond, Boxes, ChevronRight, Lock, Unlock, Sliders,
  Frame, Send, X, User, Camera, Volume2, Lightbulb, Play, Pause, AlertCircle, Calendar, Edit3
} from 'lucide-react';

interface FloorPlanViewerProps {
  floorPlan: FloorPlan | null; // Currently selected floor plan (focused drawing)
  floorPlans: FloorPlan[]; // All floor plans to display together on the shared workspace
  activeFloorPlanId: string | null;
  setActiveFloorPlanId: (id: string | null) => void;
  onUpdateFloorPlan: (plan: FloorPlan) => void; // Moves floor plan cards around in the workspace
  
  markers: MarkerNote[];
  id?: string;
  selectedMarkerId: string | null;
  onSelectMarker: (id: string | null) => void;
  onAddMarker: (x: number, y: number) => void;
  onUploadFloorPlan: (name: string, imageData: string, canvasX?: number, canvasY?: number, width?: number, height?: number) => void;
  
  // Whiteboard Annotations props
  annotations: WhiteboardAnnotation[];
  onAddAnnotation: (annot: WhiteboardAnnotation) => void;
  onUpdateAnnotation: (annot: WhiteboardAnnotation) => void;
  onDeleteAnnotation: (id: string) => void;
  selectedAnnotationId: string | null;
  onSelectAnnotation: (id: string | null) => void;
  
  activeWhiteboardTool: 'select' | 'marker' | 'sticky' | 'text' | 'rect' | 'ellipse' | 'arrow' | 'pen' | 'line' | 'elbow-arrow' | 'block-arrow' | 'rhombus' | 'triangle' | 'diagram' | 'frame';
  setActiveWhiteboardTool: (tool: 'select' | 'marker' | 'sticky' | 'text' | 'rect' | 'ellipse' | 'arrow' | 'pen' | 'line' | 'elbow-arrow' | 'block-arrow' | 'rhombus' | 'triangle' | 'diagram' | 'frame') => void;
  activeUserRole: UserRoleProfile;
  currentColor: string;
  setCurrentColor: (color: string) => void;
  
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  activeProjectId?: string | null;
  onDeleteFloorPlan?: (id: string) => void;
  activeProject?: Project | null;
  onUpdateMarker?: (updated: MarkerNote) => void;
  userRolesList?: UserRoleProfile[];
}

export default function FloorPlanViewer({
  floorPlan,
  floorPlans,
  activeFloorPlanId,
  setActiveFloorPlanId,
  onUpdateFloorPlan,
  markers,
  selectedMarkerId,
  onSelectMarker,
  onAddMarker,
  onUploadFloorPlan,
  
  annotations,
  onAddAnnotation,
  onUpdateAnnotation,
  onDeleteAnnotation,
  selectedAnnotationId,
  onSelectAnnotation,
  
  activeWhiteboardTool,
  setActiveWhiteboardTool,
  activeUserRole,
  currentColor,
  setCurrentColor,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  activeProjectId,
  onDeleteFloorPlan,
  activeProject,
  onUpdateMarker,
  userRolesList = []
}: FloorPlanViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedAnnotation = annotations.find(a => a.id === selectedAnnotationId) || null;
  const [activePropDropdown, setActivePropDropdown] = useState<'none' | 'color' | 'thickness' | 'dash' | 'opacity' | 'linetype'>('none');

  // Drag over states
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);
  const [inPlaceCommentText, setInPlaceCommentText] = useState<string>('');
  const [popoverTab, setPopoverTab] = useState<'info' | 'detail' | 'discuss'>('info');
  const [isPopoverAudioPlaying, setIsPopoverAudioPlaying] = useState<boolean>(false);
  const [hoveredMarkerId, setHoveredMarkerId] = useState<string | null>(null);

  useEffect(() => {
    setPopoverTab('info');
    setIsPopoverAudioPlaying(false);
  }, [selectedMarkerId]);

  // We set a virtual giant Miro whiteboard dimension:
  const canvasWidth = 7000;
  const canvasHeight = 4500;

  // Zoom & Pan states for the camera
  const [zoomLevel, setZoomLevel] = useState<number>(0.4); // Starts somewhat zoomed out to show the grid workspace
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 50, y: 50 });
  const [isZooming, setIsZooming] = useState<boolean>(false);
  const zoomTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Smooth mouse-wheel zooming centered on user's cursor (Miro-like)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleNativeWheel = (e: WheelEvent) => {
      // Prevent default page scroll
      e.preventDefault();

      setIsZooming(true);
      if (zoomTimeoutRef.current) {
        clearTimeout(zoomTimeoutRef.current);
      }
      zoomTimeoutRef.current = setTimeout(() => {
        setIsZooming(false);
      }, 300);

      const rect = container.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      // Board canvas coordinates directly under cursor
      const boardX = (mouseX - dragOffset.x) / zoomLevel;
      const boardY = (mouseY - dragOffset.y) / zoomLevel;

      // Precise scaling ratio mimicking professional graphic boards
      const ratio = 1.08;
      let nextZoomLevel;
      if (e.deltaY < 0) {
        // Scroll Up = Zoom In
        nextZoomLevel = Math.min(zoomLevel * ratio, 3.5);
      } else {
        // Scroll Down = Zoom Out
        nextZoomLevel = Math.max(zoomLevel / ratio, 0.06);
      }

      // New offsets ensuring board coordinates (boardX, boardY) stay stationary under cursor (mouseX, mouseY)
      const nextDragOffsetX = mouseX - boardX * nextZoomLevel;
      const nextDragOffsetY = mouseY - boardY * nextZoomLevel;

      setZoomLevel(nextZoomLevel);
      setDragOffset({ x: nextDragOffsetX, y: nextDragOffsetY });
    };

    container.addEventListener('wheel', handleNativeWheel, { passive: false });
    return () => {
      container.removeEventListener('wheel', handleNativeWheel);
      if (zoomTimeoutRef.current) {
        clearTimeout(zoomTimeoutRef.current);
      }
    };
  }, [zoomLevel, dragOffset]);

  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [showHelperMsg, setShowHelperMsg] = useState<boolean>(true);

  // Presentation Mode design states
  const [isPresentationMode, setIsPresentationMode] = useState<boolean>(false);
  const [currentSlideIndex, setCurrentSlideIndex] = useState<number>(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);
  const [isShapesFlyoutOpen, setIsShapesFlyoutOpen] = useState<boolean>(false);
  const [isFrameFlyoutOpen, setIsFrameFlyoutOpen] = useState<boolean>(false);
  const [editingFrameId, setEditingFrameId] = useState<string | null>(null);

  // Filter markers for present tour
  const activePlanMarkers = markers
    .filter(m => !activeFloorPlanId || m.floorPlanId === activeFloorPlanId)
    .sort((a, b) => a.createdAt - b.createdAt);

  const focusOnMarker = (marker: MarkerNote) => {
    const parentPlanIndex = floorPlans.findIndex(p => p.id === marker.floorPlanId);
    if (parentPlanIndex === -1) return;
    const plan = floorPlans[parentPlanIndex];
    const containerW = containerRef.current?.clientWidth || 1000;
    const containerH = containerRef.current?.clientHeight || 650;
    
    const pos = computePlanPosition(plan, parentPlanIndex);
    const planHeight = (plan.height / plan.width) * frameRenderWidth;
    
    // Tọa độ marker trên canvas khổng lồ:
    const markerX = pos.x + (marker.x / 100) * frameRenderWidth;
    const markerY = pos.y + (marker.y / 100) * planHeight;
    
    const targetZoom = 1.0; 
    setZoomLevel(targetZoom);
    setDragOffset({
      x: containerW / 2 - markerX * targetZoom,
      y: containerH / 2 - markerY * targetZoom
    });
  };

  useEffect(() => {
    if (isPresentationMode && activePlanMarkers.length > 0) {
      const curMarker = activePlanMarkers[currentSlideIndex];
      if (curMarker) {
        focusOnMarker(curMarker);
      }
    }
  }, [isPresentationMode, currentSlideIndex, activeFloorPlanId]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAutoPlaying && isPresentationMode && activePlanMarkers.length > 0) {
      interval = setInterval(() => {
        setCurrentSlideIndex((prevIdx) => {
          if (prevIdx < activePlanMarkers.length - 1) {
            return prevIdx + 1;
          } else {
            setIsAutoPlaying(false);
            return prevIdx;
          }
        });
      }, 10000);
    }
    return () => clearInterval(interval);
  }, [isAutoPlaying, isPresentationMode, activePlanMarkers.length]);

  // Global hotkeys to control Miro tools
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is inside typing elements
      const activeEl = document.activeElement;
      if (activeEl && (
        activeEl.tagName === 'INPUT' || 
        activeEl.tagName === 'TEXTAREA' || 
        activeEl.getAttribute('contenteditable') === 'true'
      )) {
        return;
      }

      // Hotkey Delete/Backspace for active whiteboard annotation
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedAnnotationId && selectedAnnotation && !selectedAnnotation.isLocked) {
          onDeleteAnnotation(selectedAnnotationId);
          onSelectAnnotation(null);
          e.preventDefault();
          return;
        }
      }

      const key = e.key.toLowerCase();
      switch (key) {
        case 'v':
          setActiveWhiteboardTool('select');
          setIsShapesFlyoutOpen(false);
          break;
        case 'c':
          setActiveWhiteboardTool('marker');
          setIsShapesFlyoutOpen(false);
          break;
        case 'n':
          setActiveWhiteboardTool('sticky');
          setIsShapesFlyoutOpen(false);
          break;
        case 't':
          setActiveWhiteboardTool('text');
          setIsShapesFlyoutOpen(false);
          break;
        case 'r':
          setActiveWhiteboardTool('rect');
          setIsShapesFlyoutOpen(false);
          break;
        case 'o':
          setActiveWhiteboardTool('ellipse');
          setIsShapesFlyoutOpen(false);
          break;
        case 'l':
          setActiveWhiteboardTool('line');
          setIsShapesFlyoutOpen(false);
          break;
        case 'a':
          setActiveWhiteboardTool('arrow');
          setIsShapesFlyoutOpen(false);
          break;
        case 'p':
          setActiveWhiteboardTool('pen');
          setIsShapesFlyoutOpen(false);
          break;
        case 's':
          setIsShapesFlyoutOpen(prev => !prev);
          break;
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => {
      window.removeEventListener('keydown', handleGlobalKeyDown);
    };
  }, [setActiveWhiteboardTool, selectedAnnotationId, selectedAnnotation, onDeleteAnnotation, onSelectAnnotation]);

  const [presentationAudioUrl, setPresentationAudioUrl] = useState<string | null>(null);
  const [isPlayingPresentationAudio, setIsPlayingPresentationAudio] = useState<boolean>(false);

  const currentSlideMarker = isPresentationMode ? activePlanMarkers[currentSlideIndex] : null;

  useEffect(() => {
    if (currentSlideMarker && currentSlideMarker.audioData) {
      try {
        const base64Content = currentSlideMarker.audioData.split(',')[1] || currentSlideMarker.audioData;
        const byteCharacters = atob(base64Content);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setPresentationAudioUrl(url);
        setIsPlayingPresentationAudio(false);
        return () => {
          URL.revokeObjectURL(url);
        };
      } catch (err) {
        console.error("Lỗi slideshow player parsing:", err);
        setPresentationAudioUrl(null);
      }
    } else {
      setPresentationAudioUrl(null);
      setIsPlayingPresentationAudio(false);
    }
  }, [currentSlideIndex, isPresentationMode, currentSlideMarker]);

  const togglePresentationAudio = () => {
    const player = document.getElementById('presentation-slideshow-player') as HTMLAudioElement;
    if (!player) return;
    if (isPlayingPresentationAudio) {
      player.pause();
      setIsPlayingPresentationAudio(false);
    } else {
      player.play().catch(e => console.error("Error setting presentation speaker:", e));
      setIsPlayingPresentationAudio(true);
    }
  };

  // Layout calculations for floor plan drawings on the board:
  // Each drawing renders inside an elegant frame with width = 1200px
  const frameRenderWidth = 1200;

  // Compute position on the whiteboard board for each blueprint frame
  const computePlanPosition = (plan: FloorPlan, index: number) => {
    if (plan.canvasX !== undefined && plan.canvasY !== undefined) {
      return { x: plan.canvasX, y: plan.canvasY };
    }
    // Elegant automatic grid placement so they don't overlap
    const column = index % 2;
    const row = Math.floor(index / 2);
    const startX = 300 + column * 1650;
    const startY = 250 + row * 1150;
    return { x: startX, y: startY };
  };

  // Helper properties to map between relative % inside and absolute board pixels
  const getLayoutForPlan = (planId: string) => {
    if (planId === 'global') {
      return { x: 0, y: 0, w: canvasWidth, h: canvasHeight, id: 'global' };
    }
    const idx = floorPlans.findIndex(p => p.id === planId);
    if (idx !== -1) {
      const p = floorPlans[idx];
      const pos = computePlanPosition(p, idx);
      const h = (p.height / p.width) * frameRenderWidth;
      return { x: pos.x, y: pos.y, w: frameRenderWidth, h, id: p.id };
    }
    // Fallback if none matches (safeguard)
    if (floorPlans.length > 0) {
      const p = floorPlans[0];
      const pos = computePlanPosition(p, 0);
      const h = (p.height / p.width) * frameRenderWidth;
      return { x: pos.x, y: pos.y, w: frameRenderWidth, h, id: p.id };
    }
    return { x: 0, y: 0, w: 1000, h: 700, id: 'unknown' };
  };

  // Dragging entire floor plan frames around on the Miro board
  const [draggingPlanId, setDraggingPlanId] = useState<string | null>(null);
  const [planDragOffset, setPlanDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Drawing relative states
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [drawParentId, setDrawParentId] = useState<string>('global');
  const [drawStartPct, setDrawStartPct] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [tempDrawingPoints, setTempDrawingPoints] = useState<string>('');
  const [tempAnnot, setTempAnnot] = useState<Partial<WhiteboardAnnotation> | null>(null);
  
  // Dragging annotations relative states
  const [draggingAnnotId, setDraggingAnnotId] = useState<string | null>(null);
  const [annotDragOffset, setAnnotDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Miro aesthetics Palette
  const colors = [
    { name: 'Red', hex: '#f43f5e' },
    { name: 'Orange', hex: '#f97316' },
    { name: 'Yellow', hex: '#facc15' },
    { name: 'Green', hex: '#10b981' },
    { name: 'Blue', hex: '#3b82f6' },
    { name: 'Purple', hex: '#8b5cf6' },
    { name: 'Black', hex: '#1e293b' }
  ];

  // Transition controls: when are we dragging/panning versus moving camera?
  // We disable CSS transformation transition during actions to avoid "lag" feel
  const isInteracting = isPanning || isDrawing || draggingAnnotId || draggingPlanId || isZooming;

  // Zoom / Pan camera centering when activeFloorPlanId switches from parent lists!
  useEffect(() => {
    if (activeFloorPlanId && floorPlans.length > 0) {
      const idx = floorPlans.findIndex(p => p.id === activeFloorPlanId);
      if (idx !== -1) {
        const selectedPlan = floorPlans[idx];
        focusOnPlan(selectedPlan, idx, 0.5);
      }
    }
  }, [activeFloorPlanId]);

  const focusOnPlan = (plan: FloorPlan, index: number, targetZoom = 0.5) => {
    const containerW = containerRef.current?.clientWidth || 1000;
    const containerH = containerRef.current?.clientHeight || 650;
    const pos = computePlanPosition(plan, index);
    const planHeight = (plan.height / plan.width) * frameRenderWidth;
    
    // Calculate targeted offsets so center of the drawing frame is in middle of viewport
    const cX = pos.x + frameRenderWidth / 2;
    const cY = pos.y + planHeight / 2;
    
    setZoomLevel(targetZoom);
    setDragOffset({
      x: containerW / 2 - cX * targetZoom,
      y: containerH / 2 - cY * targetZoom
    });
  };

  const focusFitAll = () => {
    if (floorPlans.length === 0) return;
    const containerW = containerRef.current?.clientWidth || 1000;
    const containerH = containerRef.current?.clientHeight || 650;
    
    // Find enclosing box around all plan frames
    let minX = canvasWidth;
    let minY = canvasHeight;
    let maxX = 0;
    let maxY = 0;
    
    floorPlans.forEach((plan, idx) => {
      const pos = computePlanPosition(plan, idx);
      const h = (plan.height / plan.width) * frameRenderWidth;
      minX = Math.min(minX, pos.x);
      minY = Math.min(minY, pos.y);
      maxX = Math.max(maxX, pos.x + frameRenderWidth);
      maxY = Math.max(maxY, pos.y + h);
    });
    
    // Add margin space
    minX = Math.max(0, minX - 150);
    minY = Math.max(0, minY - 150);
    maxX = Math.min(canvasWidth, maxX + 150);
    maxY = Math.min(canvasHeight, maxY + 150);
    
    const boundingW = maxX - minX;
    const boundingH = maxY - minY;
    
    // Determine fit zoom
    const zoomW = containerW / boundingW;
    const zoomH = containerH / boundingH;
    const fitZoom = Math.max(0.12, Math.min(zoomW, zoomH, 0.6));
    
    setZoomLevel(fitZoom);
    setDragOffset({
      x: containerW / 2 - (minX + boundingW / 2) * fitZoom,
      y: containerH / 2 - (minY + boundingH / 2) * fitZoom
    });
  };

  // Extracts dimensions from image and triggers onUploadFloorPlan
  function extractImageSizeAndUpload(name: string, dataUrl: string, canvasX?: number, canvasY?: number) {
    const img = new Image();
    img.onload = () => {
      // Once image loads, call with the correct real proportional dimensions!
      const w = img.naturalWidth || 800;
      const h = img.naturalHeight || 600;
      onUploadFloorPlan(name, dataUrl, canvasX, canvasY, w, h);
    };
    img.onerror = () => {
      // Fallback if dimensions can't be fetched
      onUploadFloorPlan(name, dataUrl, canvasX, canvasY, 800, 600);
    };
    img.src = dataUrl;
  }

  function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        extractImageSizeAndUpload(file.name.replace(/\.[^/.]+$/, ""), result);
      };
      reader.readAsDataURL(file);
    }
  }

  // Handle dropping general Pinterest links or PC image files
  function handleImageDrop(e: DragEvent<HTMLDivElement>, coords: { x: number; y: number }) {
    e.preventDefault();
    
    // 1. Dropping PC local explorer image files
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          extractImageSizeAndUpload(file.name.replace(/\.[^/.]+$/, ""), result, coords.x, coords.y);
        };
        reader.readAsDataURL(file);
      } else {
        alert('Vui lòng kéo một tệp có định dạng hình ảnh (.jpg, .png, .webp, .svg...)!');
      }
      return;
    }

    // 2. Dropping images from Pinterest / internet websites
    const urlList = e.dataTransfer.getData('text/uri-list');
    const imageUrl = e.dataTransfer.getData('URL');
    const htmlData = e.dataTransfer.getData('text/html');

    let detectedUrl = imageUrl || urlList;

    if (!detectedUrl && htmlData) {
      // Extract img src using regex
      const match = htmlData.match(/src="([^"]+)"/);
      if (match && match[1]) {
        detectedUrl = match[1];
      }
    }

    if (detectedUrl) {
      const name = "Ảnh Tham Khảo " + new Date().toLocaleTimeString('vi-VN');
      extractImageSizeAndUpload(name, detectedUrl, coords.x, coords.y);
    } else {
      alert('Không phát hiện thấy hình ảnh hợp lệ. Bạn hãy tải ảnh về máy và kéo từ PC thả vào vùng làm việc này!');
    }
  }

  // Map mouse coordinate to Canvas absolute pixel coordinate on the (0-7000, 0-4500) board
  function getCanvasCoords(clientX: number, clientY: number): { x: number; y: number } {
    if (!containerRef.current) return { x: 0, y: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    
    // Standard reverse transformation math aligned with left-top transform origin
    const boardX = (clientX - rect.left - dragOffset.x) / zoomLevel;
    const boardY = (clientY - rect.top - dragOffset.y) / zoomLevel;
    
    return {
      x: Math.max(0, Math.min(canvasWidth, boardX)),
      y: Math.max(0, Math.min(canvasHeight, boardY))
    };
  }

  // Detect which drawing frame is beneath the coordinate
  function detectPlanUnderCoords(x: number, y: number) {
    for (let i = 0; i < floorPlans.length; i++) {
      const plan = floorPlans[i];
      const pos = computePlanPosition(plan, i);
      const h = (plan.height / plan.width) * frameRenderWidth;
      
      if (x >= pos.x && x <= pos.x + frameRenderWidth && y >= pos.y && y <= pos.y + h) {
        return { plan, layout: { x: pos.x, y: pos.y, w: frameRenderWidth, h } };
      }
    }
    return null;
  }

  // Stage Mouse Downs
  function handleStageMouseDown(e: ReactMouseEvent<HTMLDivElement>) {
    const target = e.target as HTMLElement;
    if (target.closest('.marker-pin-button')) {
      return;
    }

    // If Select, or holding middle mouse/Space button, pan around
    if (activeWhiteboardTool === 'select' || e.button === 1) {
      const target = e.target as HTMLElement;
      if (target.closest('.whiteboard-element') || target.closest('.no-pan-trigger')) return;

      setIsPanning(true);
      setPanStart({ x: e.clientX - dragOffset.x, y: e.clientY - dragOffset.y });
      return;
    }

    const { x: boardX, y: boardY } = getCanvasCoords(e.clientX, e.clientY);
    
    // Clear sidebar highlights
    onSelectMarker(null);
    onSelectAnnotation(null);

    // Pinpointing camera photo faults
    if (activeWhiteboardTool === 'marker') {
      const match = detectPlanUnderCoords(boardX, boardY);
      if (match) {
        // Map back to percent coordinates of that floor plan
        const pctX = ((boardX - match.layout.x) / match.layout.w) * 100;
        const pctY = ((boardY - match.layout.y) / match.layout.h) * 100;
        
        // Auto set active drawing inside parent App scope so selected detail panel responds correctly!
        setActiveFloorPlanId(match.plan.id);
        
        // Drop marker
        onAddMarker(pctX, pctY);
      } else {
        // Alert that markers need an architect blueprint to cling to
        alert('Vui lòng ghim lỗi 📷 trực tiếp lên mặt bằng bản vẽ thiết kế!');
      }
      return;
    }

    // Creating post-it / stickies or texts anywhere!
    if (activeWhiteboardTool === 'sticky' || activeWhiteboardTool === 'text') {
      const match = detectPlanUnderCoords(boardX, boardY);
      const parentId = match ? match.plan.id : 'global';
      const layout = getLayoutForPlan(parentId);
      
      // Calculate percentages relative to parent frame
      const pctX = ((boardX - layout.x) / layout.w) * 100;
      const pctY = ((boardY - layout.y) / layout.h) * 100;
      const cleanText = activeWhiteboardTool === 'sticky' ? 'Ghi chú giấy nhớ...' : 'Gõ văn bản tự do...';
      
      const id = `annot-${Date.now()}`;
      onAddAnnotation({
        id,
        floorPlanId: parentId,
        type: activeWhiteboardTool,
        x: pctX,
        y: pctY,
        width: activeWhiteboardTool === 'sticky' ? 12 : 16,
        height: activeWhiteboardTool === 'sticky' ? 10 : 4,
        color: currentColor,
        content: cleanText,
        createdAt: Date.now(),
        userName: activeUserRole.name,
        comments: []
      });
      
      setActiveWhiteboardTool('select');
      onSelectAnnotation(id);
      return;
    }

    // Draw Vector geometries (Rects, Ellipses, Arrows Connecting panels, Freehand Pen)
    const match = detectPlanUnderCoords(boardX, boardY);
    const parentId = match ? match.plan.id : 'global';
    const layout = getLayoutForPlan(parentId);
    
    const pctX = ((boardX - layout.x) / layout.w) * 100;
    const pctY = ((boardY - layout.y) / layout.h) * 100;

    setIsDrawing(true);
    setDrawParentId(parentId);
    setDrawStartPct({ x: pctX, y: pctY });

    const id = `annot-${Date.now()}`;
    if (activeWhiteboardTool === 'pen') {
      // Free pen tracking
      const nextPoints = `${pctX * 10},${pctY * 10}`;
      setTempDrawingPoints(nextPoints);
      setTempAnnot({
        id,
        floorPlanId: parentId,
        type: 'pen',
        x: pctX,
        y: pctY,
        width: 1,
        height: 1,
        color: currentColor,
        content: '',
        points: nextPoints,
        createdAt: Date.now(),
        userName: activeUserRole.name,
        comments: []
      });
    } else {
      // Boxes, Circles, Connecting Connector Lines
      setTempAnnot({
        id,
        floorPlanId: parentId,
        type: activeWhiteboardTool,
        x: pctX,
        y: pctY,
        endX: pctX,
        endY: pctY,
        width: 1,
        height: 1,
        color: currentColor,
        content: '',
        createdAt: Date.now(),
        userName: activeUserRole.name,
        comments: []
      });
    }
  }

  // Mouse move drawing and panning actions
  function handleStageMouseMove(e: ReactMouseEvent<HTMLDivElement>) {
    // 1. Camera Pan
    if (isPanning) {
      setDragOffset({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y
      });
      return;
    }

    // 2. Dragging Floor Plan Drawing Frames
    if (draggingPlanId) {
      const coords = getCanvasCoords(e.clientX, e.clientY);
      const targetPlan = floorPlans.find(p => p.id === draggingPlanId);
      if (targetPlan) {
        onUpdateFloorPlan({
          ...targetPlan,
          canvasX: Math.round(coords.x - planDragOffset.x),
          canvasY: Math.round(coords.y - planDragOffset.y)
        });
      }
      return;
    }

    // 3. Dragging Annotations Shapes / Notes
    if (draggingAnnotId) {
      const coords = getCanvasCoords(e.clientX, e.clientY);
      const target = annotations.find(a => a.id === draggingAnnotId);
      if (target) {
        // Recalculate which plan frame is currently below the cursor!
        // This is extremely modular: if you drag a note with select, it can shift anchors!
        const layout = getLayoutForPlan(target.floorPlanId);
        const nextLocalX = ((coords.x - annotDragOffset.x - layout.x) / layout.w) * 100;
        const nextLocalY = ((coords.y - annotDragOffset.y - layout.y) / layout.h) * 100;
        
        const nextX = Math.max(0, Math.min(100 - target.width, nextLocalX));
        const nextY = Math.max(0, Math.min(100 - target.height, nextLocalY));
        const deltaX = nextX - target.x;
        const deltaY = nextY - target.y;

        if (target.type === 'frame' && (Math.abs(deltaX) > 0.01 || Math.abs(deltaY) > 0.01)) {
          // Identify elements nested within current frame bounds before dragging
          const targetMinX = target.x;
          const targetMaxX = target.x + target.width;
          const targetMinY = target.y;
          const targetMaxY = target.y + target.height;

          annotations.forEach(a => {
            if (a.id === target.id || a.floorPlanId !== target.floorPlanId) return;
            
            let isInside = false;
            if (['line', 'arrow', 'elbow-arrow'].includes(a.type)) {
              const ax1 = a.x;
              const ay1 = a.y;
              const ax2 = a.endX !== undefined ? a.endX : a.x;
              const ay2 = a.endY !== undefined ? a.endY : a.y;
              isInside = ax1 >= targetMinX && ax1 <= targetMaxX &&
                         ay1 >= targetMinY && ay1 <= targetMaxY &&
                         ax2 >= targetMinX && ax2 <= targetMaxX &&
                         ay2 >= targetMinY && ay2 <= targetMaxY;
            } else {
              const ax = a.x;
              const ay = a.y;
              isInside = ax >= targetMinX && ax <= targetMaxX &&
                         ay >= targetMinY && ay <= targetMaxY;
            }

            if (isInside) {
              const movingWidth = a.width || 0;
              const movingHeight = a.height || 0;
              const updatedObj: WhiteboardAnnotation = {
                ...a,
                x: Math.max(0, Math.min(100 - movingWidth, a.x + deltaX)),
                y: Math.max(0, Math.min(100 - movingHeight, a.y + deltaY))
              };
              if (a.endX !== undefined) {
                updatedObj.endX = Math.max(0, Math.min(100, a.endX + deltaX));
              }
              if (a.endY !== undefined) {
                updatedObj.endY = Math.max(0, Math.min(100, a.endY + deltaY));
              }
              onUpdateAnnotation(updatedObj);
            }
          });
        }

        onUpdateAnnotation({
          ...target,
          x: nextX,
          y: nextY
        });
      }
      return;
    }

    // 4. Drawing new shapes
    if (!isDrawing || !tempAnnot) return;
    const { x: boardX, y: boardY } = getCanvasCoords(e.clientX, e.clientY);
    const layout = getLayoutForPlan(drawParentId);
    
    const pctX = ((boardX - layout.x) / layout.w) * 100;
    const pctY = ((boardY - layout.y) / layout.h) * 100;

    if (activeWhiteboardTool === 'pen') {
      const nextPoints = tempDrawingPoints ? `${tempDrawingPoints} ${pctX * 10},${pctY * 10}` : `${pctX * 10},${pctY * 10}`;
      setTempDrawingPoints(nextPoints);
      setTempAnnot(prev => prev ? { ...prev, points: nextPoints } : null);
    } else if (['arrow', 'line', 'elbow-arrow'].includes(activeWhiteboardTool)) {
      setTempAnnot(prev => prev ? {
        ...prev,
        endX: pctX,
        endY: pctY
      } : null);
    } else {
      // Rects, Ellipses, Rhombus, Triangle, Block-arrow, Diagram
      const leftX = Math.min(drawStartPct.x, pctX);
      const topY = Math.min(drawStartPct.y, pctY);
      const w = Math.abs(drawStartPct.x - pctX);
      const h = Math.abs(drawStartPct.y - pctY);
      setTempAnnot(prev => prev ? {
        ...prev,
        x: leftX,
        y: topY,
        width: w,
        height: h
      } : null);
    }
  }

  // Mouse up releases
  function handleStageMouseUp() {
    setIsPanning(false);
    setDraggingPlanId(null);
    setDraggingAnnotId(null);
    
    if (isDrawing && tempAnnot) {
      setIsDrawing(false);
      
      const meritsSave = activeWhiteboardTool === 'pen'
        ? (tempDrawingPoints && tempDrawingPoints.split(' ').length > 2)
        : ['arrow', 'line', 'elbow-arrow'].includes(activeWhiteboardTool)
          ? (Math.abs((tempAnnot.endX || 0) - (tempAnnot.x || 0)) > 1 || Math.abs((tempAnnot.endY || 0) - (tempAnnot.y || 0)) > 1)
          : ((tempAnnot.width || 0) > 1 && (tempAnnot.height || 0) > 1);

      if (meritsSave) {
        onAddAnnotation(tempAnnot as WhiteboardAnnotation);
      }
      setTempAnnot(null);
      setTempDrawingPoints('');
    }
  }

  function handleCreateFrameWithPreset(preset: string) {
    const parentId = activeFloorPlanId || (floorPlans.length > 0 ? floorPlans[0].id : 'global');
    
    let w = 25;
    let h = 20;
    let label = 'Vùng mới';
    
    switch (preset) {
      case 'A4':
        w = 35; h = 25; label = 'Vùng A4'; break;
      case 'Letter':
        w = 32; h = 25; label = 'Vùng Thư (Letter)'; break;
      case '16:9':
        w = 36; h = 20.25; label = 'Vùng Slide 16:9'; break;
      case '4:3':
        w = 32; h = 24; label = 'Vùng Sơ Đồ 4:3'; break;
      case '1:1':
        w = 25; h = 25; label = 'Vùng Vuông 1:1'; break;
      case 'mobile':
        w = 16; h = 28.5; label = 'Vùng Điện thoại (Mobile)'; break;
      case 'tablet':
        w = 24; h = 32; label = 'Vùng Máy tính bảng (Tablet)'; break;
      case 'desktop':
        w = 40; h = 25; label = 'Vùng Màn hình lớn (Desktop)'; break;
      case 'slides':
        w = 40; h = 22.5; label = 'Trang slide thuyết trình'; break;
      case 'diagram':
        w = 35; h = 25; label = 'Khung sơ đồ phân tích'; break;
      default: // custom
        setActiveWhiteboardTool('frame');
        setIsFrameFlyoutOpen(false);
        return;
    }
    
    const id = `annot-${Date.now()}`;
    onAddAnnotation({
      id,
      floorPlanId: parentId,
      type: 'frame',
      x: 35,
      y: 35,
      width: w,
      height: h,
      color: '#3b82f6', // Miro blue color default for frame
      content: label,
      createdAt: Date.now(),
      userName: activeUserRole.name,
      comments: []
    });
    
    setActiveWhiteboardTool('select');
    onSelectAnnotation(id);
    setIsFrameFlyoutOpen(false);
  }

  // Handle Dragging Whiteboard objects on canvas
  function handleAnnotDragStart(e: ReactMouseEvent, annot: WhiteboardAnnotation) {
    if (activeWhiteboardTool !== 'select') return;
    if (annot.isLocked) return; // Miro lock: block any dragging or moving on locked elements
    e.stopPropagation();
    
    setDraggingAnnotId(annot.id);
    const { x: boardX, y: boardY } = getCanvasCoords(e.clientX, e.clientY);
    const layout = getLayoutForPlan(annot.floorPlanId);
    
    // Position of annotation in global pixels
    const animAbsX = layout.x + (annot.x / 100) * layout.w;
    const animAbsY = layout.y + (annot.y / 100) * layout.h;
    
    setAnnotDragOffset({
      x: boardX - animAbsX,
      y: boardY - animAbsY
    });
  }

  // Start dragging a floor plan drawing frame
  function handlePlanDragStart(e: ReactMouseEvent, plan: FloorPlan, index: number) {
    e.stopPropagation();
    setDraggingPlanId(plan.id);
    const coords = getCanvasCoords(e.clientX, e.clientY);
    const pos = computePlanPosition(plan, index);
    setPlanDragOffset({
      x: coords.x - pos.x,
      y: coords.y - pos.y
    });
    // Set focused plan in main views
    setActiveFloorPlanId(plan.id);
  }

  const zoomIn = () => {
    setZoomLevel(prev => Math.min(prev + 0.15, 2.0));
  };
  const zoomOut = () => {
    setZoomLevel(prev => Math.max(prev - 0.15, 0.1));
  };

  function parsePenPointsToAbs(pointsStr: string, layout: { x: number, y: number, w: number, h: number }) {
    if (!pointsStr) return '';
    return pointsStr.split(' ').map(p => {
      const [pctX10, pctY10] = p.split(',');
      const px = parseFloat(pctX10) / 10;
      const py = parseFloat(pctY10) / 10;
      const absX = layout.x + (px / 100) * layout.w;
      const absY = layout.y + (py / 100) * layout.h;
      return `${absX},${absY}`;
    }).join(' ');
  }

  const projectFloorPlans = activeProjectId
    ? floorPlans.filter(p => p.projectId === activeProjectId)
    : floorPlans;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl flex flex-col h-full shadow-2xl overflow-hidden min-h-[580px] relative">
      
      {/* 2D PLAN SHEETS HORIZONTAL TAB SELECTOR (Vùng 2 - Tinh gọn Dàn ngang) */}
      <div className="bg-slate-950/95 border-b border-slate-900 px-4 py-2 flex items-center justify-between shrink-0 select-none z-30 no-pan-trigger">
        {activeProject && (
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-805 rounded-xl px-3.5 py-1 mr-3 text-slate-400 select-none max-w-[280px] shrink-0">
            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-1 min-w-0">
                <span className="text-[8px] uppercase font-black text-indigo-400 tracking-wider shrink-0">Dự án:</span>
                <span className="text-[11px] font-black text-slate-100 truncate block leading-none" title={activeProject.name}>
                  {activeProject.name}
                </span>
              </div>
              <div className="flex items-center gap-3 text-[9px] text-slate-500 mt-1">
                <span className="truncate text-slate-400">KTS: <strong className="text-slate-300">{activeProject.leader}</strong></span>
                <span className="text-amber-400 font-mono font-bold shrink-0">Tiến độ: {activeProject.progress}%</span>
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center gap-2 text-slate-450 shrink-0 select-none">
          <Layers className="w-4 h-4 text-emerald-400" />
          <span className="text-[10px] font-black uppercase tracking-wider hidden sm:inline">Mặt bằng:</span>
        </div>

        <div className="flex-1 flex items-center gap-2 overflow-x-auto px-4 py-1 no-scrollbar scroll-smooth">
          {projectFloorPlans.length === 0 ? (
            <span className="text-[10px] text-slate-500 italic">
              Chưa có bản vẽ nào. Nhấp 'Dán bản vẽ mới' ở góc phải để thêm!
            </span>
          ) : (
            projectFloorPlans.map(plan => {
              const isSelected = activeFloorPlanId === plan.id;
              const typeLabel = plan.planType === 'tiling' 
                ? '📐 Sàn Ốp Lát' 
                : plan.planType === 'existing' 
                  ? '🧱 Hiện Trạng' 
                  : '🛋️ Thiết Kế';

              return (
                <div
                  key={plan.id}
                  className={`group relative flex items-center shrink-0 min-w-[145px] max-w-[200px] h-9 p-1 pl-3 pr-2.5 rounded-xl border transition-all select-none cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-600/10 border-emerald-500/30 text-emerald-300 shadow shadow-emerald-500/5'
                      : 'bg-slate-900 border-slate-900 hover:bg-slate-850 hover:text-slate-200 text-slate-400'
                  }`}
                  onClick={() => {
                    setActiveFloorPlanId(plan.id);
                    onSelectMarker(null);
                    onSelectAnnotation(null);
                  }}
                  title={plan.name}
                >
                  <div className="flex-1 min-w-0 pr-4">
                    <span className="text-[11px] font-extrabold truncate block leading-tight select-none">{plan.name}</span>
                    <span className={`text-[8px] font-bold select-none text-slate-500 block leading-none mt-0.5`}>
                      {typeLabel}
                    </span>
                  </div>
                  
                  {/* Delete tab button (Trash2) */}
                  {plan.id !== 'demo-floor-plan' && onDeleteFloorPlan && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteFloorPlan(plan.id);
                      }}
                      className="absolute right-1.5 text-slate-550 hover:text-rose-500 hover:bg-rose-500/15 p-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-150 cursor-pointer"
                      title="Xóa bản vẽ"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Inline right upload trigger */}
        <button
          onClick={() => fileInputRef.current?.click()}
          className="shrink-0 flex items-center gap-1 px-3 py-1.5 bg-indigo-650 hover:bg-indigo-600 text-white font-bold rounded-xl text-xs shadow-md transition-all active:scale-95 cursor-pointer select-none"
          title="Dán bản vẽ thiết kế mới"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Dán bản vẽ mới</span>
        </button>
      </div>

      {/* 2. DYNAMIC COLOR PALETTE FLOATING */}
      {floorPlans.length > 0 && activeWhiteboardTool !== 'select' && activeWhiteboardTool !== 'marker' && (
        <div className="absolute top-16 left-4 z-30 bg-slate-950/95 border border-slate-800 shadow-xl rounded-2xl p-2.5 flex items-center gap-2.5">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider pr-1">Mã Màu:</div>
          <div className="flex items-center gap-1.5">
            {colors.map(col => (
              <button
                key={col.hex}
                onClick={() => setCurrentColor(col.hex)}
                style={{ backgroundColor: col.hex }}
                className={`w-5.5 h-5.5 rounded-full border-2 cursor-pointer transition-transform ${
                  currentColor === col.hex ? 'border-white scale-125' : 'border-slate-850 hover:scale-110'
                }`}
                title={col.name}
              />
            ))}
          </div>
        </div>
      )}

      {/* 3. WHITEBOARD WORKSPACE CONTAINER */}
      <div 
        className="flex-1 bg-slate-100 relative overflow-hidden flex items-center justify-center pointer-events-auto"
        onMouseMove={handleStageMouseMove}
        onMouseUp={handleStageMouseUp}
      >
        {/* Dynamic Instructional Banner for Pinning Camera and Voice Faults (Miro-style) */}
        {floorPlans.length > 0 && activeWhiteboardTool === 'marker' && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 bg-[#0f1222] border-2 border-emerald-500 text-white shadow-[0_15px_40px_rgba(8,10,24,0.6)] rounded-3xl p-4 flex items-center gap-3.5 max-w-xl w-[90%] md:w-auto animate-bounce-subtle pointer-events-auto">
            <div className="bg-emerald-500/20 border border-emerald-400 p-2.5 rounded-2xl shrink-0 flex items-center justify-center animate-pulse">
              <Camera className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="text-left font-sans">
              <div className="text-[9px] font-black uppercase tracking-widest text-emerald-400 mb-0.5">Quy trình ghim lỗi hiện trường DQH</div>
              <p className="text-xs font-bold leading-relaxed text-slate-100">
                👉 Nhấp chuột vào bất cứ điểm có lỗi nào trên bản vẽ bên dưới để <span className="text-emerald-400 underline decoration-emerald-500/50 decoration-2">ghim vị trí</span>, sau đó hệ thống sẽ tự động mở <span className="text-yellow-400 font-extrabold">Webcam chụp ảnh hiện trạng</span> & <span className="text-cyan-400 font-extrabold font-mono">Ghi âm Voice mô tả</span> ngay lập tức!
              </p>
            </div>
            <button 
              onClick={() => setActiveWhiteboardTool('select')}
              className="text-[10px] bg-slate-800 hover:bg-slate-700 hover:text-white text-slate-400 px-3 py-1.5 rounded-xl border border-slate-700 font-extrabold cursor-pointer h-fit self-center shrink-0 transition-all active:scale-95"
              title="Hủy công cụ ghim lỗi"
            >
              Hủy
            </button>
          </div>
        )}

        {floorPlans.length > 0 ? (
          <div
            ref={containerRef}
            className="w-full h-full absolute inset-0 select-none overflow-hidden"
            onMouseDown={handleStageMouseDown}
            onDragOver={(e) => {
              e.preventDefault();
              e.stopPropagation();
              e.dataTransfer.dropEffect = 'copy';
              setIsDraggingOver(true);
            }}
            onDragEnter={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setIsDraggingOver(true);
            }}
            onDragLeave={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setIsDraggingOver(false);
            }}
            onDrop={(e) => {
              e.preventDefault();
              e.stopPropagation();
              setIsDraggingOver(false);
              const coords = getCanvasCoords(e.clientX, e.clientY);
              handleImageDrop(e, coords);
            }}
            style={{
              // Styled with beautiful Figma/Miro-like light grey starry dots grid pattern
              backgroundImage: 'radial-gradient(#cbd5e1 1.5px, transparent 1.5px)',
              backgroundSize: '24px 24px',
              backgroundColor: '#ffffff',
              cursor: activeWhiteboardTool === 'select' ? (isPanning ? 'grabbing' : 'grab') : 'crosshair'
            }}
          >
            {/* Visual Drag and Drop reference image overlay alert */}
            {isDraggingOver && (
              <div className="absolute inset-0 bg-indigo-950/75 backdrop-blur-sm z-40 flex flex-col items-center justify-center border-4 border-dashed border-indigo-400 m-6 rounded-3xl pointer-events-none animate-pulse">
                <div className="p-5 bg-indigo-600/20 border border-indigo-500/30 rounded-2xl text-indigo-400 mb-4 shadow-xl">
                  <Upload className="w-12 h-12 animate-bounce text-indigo-400" />
                </div>
                <h3 className="text-lg font-black text-white uppercase tracking-wider">Thả để chèn ảnh Pinterest hoặc PC</h3>
                <p className="text-xs text-indigo-300 mt-2 font-medium">Bản vẽ hoặc hình ảnh tham khảo sẽ xuất hiện ngay tại vị trí kéo thả</p>
              </div>
            )}
            {/* GIANT TRANSFORMING BOARD CANVAS CANVAS LAYER */}
            <div
              className={`absolute origin-top-left ${isInteracting ? '' : 'transition-transform duration-300 ease-out'}`}
              style={{
                width: `${canvasWidth}px`,
                height: `${canvasHeight}px`,
                transform: `translate(${dragOffset.x}px, ${dragOffset.y}px) scale(${zoomLevel})`,
              }}
            >
              
              {/* LAYOUT DRAWINGS FRAMES GROUPED (Miro Card Boxes) */}
              {floorPlans.map((plan, idx) => {
                const pos = computePlanPosition(plan, idx);
                const isFocused = activeFloorPlanId === plan.id;
                const isBeingDragged = draggingPlanId === plan.id;
                const h = (plan.height / plan.width) * frameRenderWidth;
                
                return (
                  <div
                    key={plan.id}
                    className={`absolute rounded-2xl p-4 transition-all bg-white border-2 select-none ${
                      isFocused 
                        ? 'border-indigo-500 shadow-[0_0_50px_rgba(99,102,241,0.2)] ring-4 ring-indigo-500/10' 
                        : 'border-slate-300 shadow-lg'
                    } ${
                      activeWhiteboardTool === 'select'
                        ? isBeingDragged ? 'cursor-grabbing' : 'cursor-grab'
                        : ''
                    }`}
                    style={{
                      left: `${pos.x}px`,
                      top: `${pos.y}px`,
                      width: `${frameRenderWidth}px`,
                      height: `${h}px`,
                      zIndex: isBeingDragged ? 40 : (isFocused ? 30 : 10)
                    }}
                    onMouseDown={(e: ReactMouseEvent) => {
                      if (activeWhiteboardTool === 'select') {
                        const target = e.target as HTMLElement;
                        if (
                          target.closest('.whiteboard-element') || 
                          target.closest('button') || 
                          target.closest('input') || 
                          target.closest('textarea')
                        ) {
                          return;
                        }
                        handlePlanDragStart(e, plan, idx);
                      }
                    }}
                  >
                    {/* Frame Top Drag Header Title Handle Block */}
                    <div 
                      className="absolute left-0 right-0 -top-[48px] h-[40px] px-4 bg-slate-50 border border-slate-200 shadow-sm rounded-xl flex items-center justify-between no-pan-trigger select-none cursor-default"
                      onMouseDown={(e: ReactMouseEvent) => handlePlanDragStart(e, plan, idx)}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        {/* Drag and move pointer handle */}
                        <div className="p-1 hover:bg-slate-100 rounded cursor-grab active:cursor-grabbing text-slate-400 hover:text-slate-800 shrink-0">
                          <GripHorizontal className="w-4 h-4" />
                        </div>
                        <span className="text-[10px] bg-indigo-50 text-indigo-600 font-extrabold px-2 py-0.5 rounded-md shrink-0">BẢN VẼ #{idx + 1}</span>
                        <h4 className="text-xs font-black text-slate-800 truncate pr-2 leading-none">{plan.name}</h4>
                      </div>
                      
                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Pin/Unpin button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onUpdateFloorPlan({
                              ...plan,
                              isPinned: !plan.isPinned
                            });
                          }}
                          className={`px-2 py-1 text-[10px] font-bold rounded-lg border flex items-center gap-1 cursor-pointer transition-all ${
                            plan.isPinned
                              ? 'bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-600'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-250'
                          }`}
                          title={plan.isPinned ? "Bỏ Ghim khỏi thanh điều hướng trên" : "Ghim lên thanh điều hướng trên"}
                        >
                          <Pin className={`w-3 h-3 ${plan.isPinned ? 'fill-white rotate-45' : ''}`} />
                          <span>{plan.isPinned ? 'Đã Ghim' : 'Ghim'}</span>
                        </button>

                        {/* Center focus camera button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFloorPlanId(plan.id);
                            focusOnPlan(plan, idx, 0.6);
                          }}
                          className="px-2.5 py-1 text-[10px] font-bold text-emerald-450 hover:text-white bg-emerald-500/10 rounded-lg border border-emerald-500/15 cursor-pointer hover:bg-emerald-500/20"
                          title="Auto center and zoom in on this architectural sheet frame"
                        >
                          Phóng Cận Cảnh
                        </button>
                      </div>
                    </div>

                    {/* Actual Blueprint Graphic */}
                    <div className="w-full h-full rounded-xl overflow-hidden bg-white border border-slate-700/50 relative">
                      <img
                        src={plan.imageData}
                        alt={plan.name}
                        className="w-full h-full object-contain pointer-events-none block select-none"
                        draggable={false}
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>
                );
              })}


              {/* SINGLE CORE VECTOR GEOMETRY SVG LAYER OVER WHOLE BOARD */}
              <svg
                width={canvasWidth}
                height={canvasHeight}
                viewBox={`0 0 ${canvasWidth} ${canvasHeight}`}
                className="absolute inset-0 w-full h-full pointer-events-none z-20"
              >
                {/* Custom Marker Arrow head definitions */}
                <defs>
                  <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 0 L 10 5 L 0 10 z" fill={currentColor} />
                  </marker>
                  {annotations.map(annot => (
                    <marker 
                      key={`arrowmarker-${annot.id}`} 
                      id={`arrow-${annot.id}`} 
                      viewBox="0 0 10 10" 
                      refX="5" 
                      refY="5" 
                      markerWidth="6" 
                      markerHeight="6" 
                      orient="auto-start-reverse"
                    >
                      <path d="M 0 0 L 10 5 L 0 10 z" fill={annot.color} />
                    </marker>
                  ))}
                </defs>

                {/* Render Geometries (rectangles, ellipses, arrows, pens) across drawings! */}
                {annotations.map(annot => {
                  const isSelected = selectedAnnotationId === annot.id;
                  const borderCol = annot.color;
                  const layout = getLayoutForPlan(annot.floorPlanId);
                  
                  // Compute absolute canvas coordinates
                  const ax = layout.x + (annot.x / 100) * layout.w;
                  const ay = layout.y + (annot.y / 100) * layout.h;
                  const aw = (annot.width / 100) * layout.w;
                  const ah = (annot.height / 100) * layout.h;

                  // Dynamic stroke styling parameters
                  const baseStrokeWidth = annot.strokeWidth !== undefined ? annot.strokeWidth : (['pen', 'arrow', 'line', 'elbow-arrow'].includes(annot.type) ? 5 : 3.5);
                  const strokeW = isSelected ? baseStrokeWidth * 1.6 : baseStrokeWidth;

                  // Custom border stroke style dash array
                  let dashArray: string | undefined = undefined;
                  if (annot.strokeDash === 'dashed') {
                    dashArray = "12,6";
                  } else if (annot.strokeDash === 'dotted') {
                    dashArray = "3,6";
                  } else if (annot.strokeDash === 'solid') {
                    dashArray = undefined;
                  } else if (isSelected) {
                    dashArray = "10,6"; // selection highlight fallback
                  }

                  // Background color & opacity config
                  const fillOpacityConfig = annot.opacity !== undefined ? annot.opacity / 100 : 0.15;
                  const fillVal = annot.opacity === 0 ? "none" : borderCol;

                  if (annot.type === 'frame') {
                    return (
                      <g key={annot.id}>
                        {/* Frame main bounding container */}
                        <rect
                          x={ax}
                          y={ay}
                          width={aw}
                          height={ah}
                          fill={annot.opacity === 0 ? "none" : (borderCol || '#2563eb')}
                          fillOpacity={annot.opacity !== undefined ? annot.opacity / 100 : 0.04}
                          stroke={borderCol || '#2563eb'}
                          strokeWidth={isSelected ? strokeW * 1.5 : 2}
                          strokeDasharray={dashArray || (isSelected ? "6,4" : undefined)}
                        />
                        {/* Interactive Corner designators for aesthetic precision */}
                        <path d={`M ${ax} ${ay+12} L ${ax} ${ay} L ${ax+12} ${ay}`} stroke={borderCol || '#2563eb'} strokeWidth="3.5" fill="none" />
                        <path d={`M ${ax+aw-12} ${ay} L ${ax+aw} ${ay} L ${ax+aw} ${ay+12}`} stroke={borderCol || '#2563eb'} strokeWidth="3.5" fill="none" />
                        <path d={`M ${ax} ${ay+ah-12} L ${ax} ${ay+ah} L ${ax+12} ${ay+ah}`} stroke={borderCol || '#2563eb'} strokeWidth="3.5" fill="none" />
                        <path d={`M ${ax+aw-12} ${ay+ah} L ${ax+aw} ${ay+ah} L ${ax+aw} ${ay+ah-12}`} stroke={borderCol || '#2563eb'} strokeWidth="3.5" fill="none" />
                      </g>
                    );
                  }

                  if (annot.type === 'rect') {
                    return (
                      <rect
                        key={annot.id}
                        x={ax}
                        y={ay}
                        width={aw}
                        height={ah}
                        fill={fillVal}
                        fillOpacity={fillOpacityConfig}
                        stroke={borderCol}
                        strokeWidth={strokeW}
                        strokeDasharray={dashArray}
                      />
                    );
                  }

                  if (annot.type === 'ellipse') {
                    const cx = ax + aw / 2;
                    const cy = ay + ah / 2;
                    const rx = aw / 2;
                    const ry = ah / 2;
                    return (
                      <ellipse
                        key={annot.id}
                        cx={cx}
                        cy={cy}
                        rx={rx}
                        ry={ry}
                        fill={fillVal}
                        fillOpacity={fillOpacityConfig}
                        stroke={borderCol}
                        strokeWidth={strokeW}
                        strokeDasharray={dashArray}
                      />
                    );
                  }

                  // Enhanced arrows, lines, and elbow routes
                  if (['line', 'arrow', 'elbow-arrow'].includes(annot.type)) {
                    const ax2 = layout.x + ((annot.endX || annot.x) / 100) * layout.w;
                    const ay2 = layout.y + ((annot.endY || annot.y) / 100) * layout.h;

                    const isArrowType = annot.type === 'arrow' || annot.type === 'elbow-arrow';
                    const isElbowType = annot.lineType === 'elbow' || annot.type === 'elbow-arrow';
                    const isCurvedType = annot.lineType === 'curved';

                    let pathD = `M ${ax} ${ay} L ${ax2} ${ay2}`;

                    if (isElbowType) {
                      const midX = (ax + ax2) / 2;
                      const midY = (ay + ay2) / 2;

                      if (annot.lineJump) {
                        // Advanced overlapping Line Jump bridge arc
                        pathD = `M ${ax} ${ay} L ${midX} ${ay} L ${midX} ${midY - 8} A 8 8 0 0 1 ${midX} ${midY + 8} L ${midX} ${ay2} L ${ax2} ${ay2}`;
                      } else {
                        pathD = `M ${ax} ${ay} L ${midX} ${ay} L ${midX} ${ay2} L ${ax2} ${ay2}`;
                      }
                    } else if (isCurvedType) {
                      const midX = (ax + ax2) / 2;
                      pathD = `M ${ax} ${ay} Q ${midX} ${ay} ${ax2} ${ay2}`;
                    }

                    return (
                      <path
                        key={annot.id}
                        d={pathD}
                        fill="none"
                        stroke={borderCol}
                        strokeWidth={strokeW}
                        strokeDasharray={dashArray}
                        markerEnd={isArrowType ? `url(#arrow-${annot.id})` : undefined}
                      />
                    );
                  }

                  if (annot.type === 'block-arrow') {
                    const ay_mid = ay + ah / 2;
                    const ay_top_shaft = ay + ah * 0.3;
                    const ay_bottom_shaft = ay + ah * 0.7;
                    const ax_arrow_start = ax + aw * 0.6;
                    const pathD = `M ${ax} ${ay_top_shaft} 
                                   L ${ax_arrow_start} ${ay_top_shaft} 
                                   L ${ax_arrow_start} ${ay} 
                                   L ${ax + aw} ${ay_mid} 
                                   L ${ax_arrow_start} ${ay + ah} 
                                   L ${ax_arrow_start} ${ay_bottom_shaft} 
                                   L ${ax} ${ay_bottom_shaft} Z`;
                    return (
                      <path
                        key={annot.id}
                        d={pathD}
                        fill={fillVal}
                        fillOpacity={fillOpacityConfig}
                        stroke={borderCol}
                        strokeWidth={strokeW}
                        strokeDasharray={dashArray}
                      />
                    );
                  }

                  if (annot.type === 'rhombus') {
                    const midX = ax + aw / 2;
                    const midY = ay + ah / 2;
                    const points = `${midX},${ay} ${ax + aw},${midY} ${midX},${ay + ah} ${ax},${midY}`;
                    return (
                      <polygon
                        key={annot.id}
                        points={points}
                        fill={fillVal}
                        fillOpacity={fillOpacityConfig}
                        stroke={borderCol}
                        strokeWidth={strokeW}
                        strokeDasharray={dashArray}
                      />
                    );
                  }

                  if (annot.type === 'triangle') {
                    const midX = ax + aw / 2;
                    const points = `${midX},${ay} ${ax + aw},${ay + ah} ${ax},${ay + ah}`;
                    return (
                      <polygon
                        key={annot.id}
                        points={points}
                        fill={fillVal}
                        fillOpacity={fillOpacityConfig}
                        stroke={borderCol}
                        strokeWidth={strokeW}
                        strokeDasharray={dashArray}
                      />
                    );
                  }

                  if (annot.type === 'diagram') {
                    return (
                      <g key={annot.id}>
                        <rect
                          x={ax}
                          y={ay}
                          width={aw}
                          height={ah}
                          fill={fillVal}
                          fillOpacity={fillOpacityConfig}
                          stroke={borderCol}
                          strokeWidth={strokeW}
                          strokeDasharray={dashArray}
                        />
                        <line
                          x1={ax + Math.min(10, aw * 0.15)}
                          y1={ay}
                          x2={ax + Math.min(10, aw * 0.15)}
                          y2={ay + ah}
                          stroke={borderCol}
                          strokeWidth={isSelected ? strokeW * 0.5 : strokeW * 0.6}
                        />
                        <line
                          x1={ax + aw - Math.min(10, aw * 0.15)}
                          y1={ay}
                          x2={ax + aw - Math.min(10, aw * 0.15)}
                          y2={ay + ah}
                          stroke={borderCol}
                          strokeWidth={isSelected ? strokeW * 0.5 : strokeW * 0.6}
                        />
                      </g>
                    );
                  }

                  if (annot.type === 'pen' && annot.points) {
                    const mappedPolyPoints = parsePenPointsToAbs(annot.points, layout);
                    return (
                      <polyline
                        key={annot.id}
                        points={mappedPolyPoints}
                        fill="none"
                        stroke={borderCol}
                        strokeWidth={strokeW}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeDasharray={dashArray}
                      />
                    );
                  }

                  return null;
                })}

                {/* Real-time live drawing preview overlay line */}
                {isDrawing && tempAnnot && (
                  <>
                    {(() => {
                      const layout = getLayoutForPlan(drawParentId);
                      const ax = layout.x + (tempAnnot.x || 0) / 100 * layout.w;
                      const ay = layout.y + (tempAnnot.y || 0) / 100 * layout.h;
                      const aw = (tempAnnot.width || 0) / 100 * layout.w;
                      const ah = (tempAnnot.height || 0) / 100 * layout.h;

                      if (tempAnnot.type === 'rect') {
                        return (
                          <rect
                            x={ax}
                            y={ay}
                            width={aw}
                            height={ah}
                            fill="none"
                            stroke={currentColor}
                            strokeWidth="5"
                            strokeDasharray="8,8"
                          />
                        );
                      }
                      if (tempAnnot.type === 'ellipse') {
                        return (
                          <ellipse
                            cx={ax + aw / 2}
                            cy={ay + ah / 2}
                            rx={aw / 2}
                            ry={ah / 2}
                            fill="none"
                            stroke={currentColor}
                            strokeWidth="5"
                            strokeDasharray="8,8"
                          />
                        );
                      }
                      if (tempAnnot.type === 'arrow') {
                        const ax2 = layout.x + (tempAnnot.endX || 0) / 100 * layout.w;
                        const ay2 = layout.y + (tempAnnot.endY || 0) / 100 * layout.h;
                        return (
                          <line
                            x1={ax}
                            y1={ay}
                            x2={ax2}
                            y2={ay2}
                            stroke={currentColor}
                            strokeWidth="5"
                            markerEnd="url(#arrow)"
                          />
                        );
                      }
                      if (tempAnnot.type === 'line') {
                        const ax2 = layout.x + (tempAnnot.endX || 0) / 100 * layout.w;
                        const ay2 = layout.y + (tempAnnot.endY || 0) / 100 * layout.h;
                        return (
                          <line
                            x1={ax}
                            y1={ay}
                            x2={ax2}
                            y2={ay2}
                            stroke={currentColor}
                            strokeWidth="5"
                            strokeDasharray="4,4"
                          />
                        );
                      }
                      if (tempAnnot.type === 'elbow-arrow') {
                        const ax2 = layout.x + (tempAnnot.endX || 0) / 100 * layout.w;
                        const ay2 = layout.y + (tempAnnot.endY || 0) / 100 * layout.h;
                        const midX = (ax + ax2) / 2;
                        const pathD = `M ${ax} ${ay} L ${midX} ${ay} L ${midX} ${ay2} L ${ax2} ${ay2}`;
                        return (
                          <path
                            d={pathD}
                            fill="none"
                            stroke={currentColor}
                            strokeWidth="5"
                            markerEnd="url(#arrow)"
                          />
                        );
                      }
                      if (tempAnnot.type === 'block-arrow') {
                        const ay_mid = ay + ah / 2;
                        const ay_top_shaft = ay + ah * 0.3;
                        const ay_bottom_shaft = ay + ah * 0.7;
                        const ax_arrow_start = ax + aw * 0.6;
                        const pathD = `M ${ax} ${ay_top_shaft} 
                                       L ${ax_arrow_start} ${ay_top_shaft} 
                                       L ${ax_arrow_start} ${ay} 
                                       L ${ax + aw} ${ay_mid} 
                                       L ${ax_arrow_start} ${ay + ah} 
                                       L ${ax_arrow_start} ${ay_bottom_shaft} 
                                       L ${ax} ${ay_bottom_shaft} Z`;
                        return (
                          <path
                            d={pathD}
                            fill={`${currentColor}15`}
                            stroke={currentColor}
                            strokeWidth="3.5"
                            strokeDasharray="4,4"
                          />
                        );
                      }
                      if (tempAnnot.type === 'rhombus') {
                        const midX = ax + aw / 2;
                        const midY = ay + ah / 2;
                        const points = `${midX},${ay} ${ax + aw},${midY} ${midX},${ay + ah} ${ax},${midY}`;
                        return (
                          <polygon
                            points={points}
                            fill={`${currentColor}15`}
                            stroke={currentColor}
                            strokeWidth="3.5"
                            strokeDasharray="4,4"
                          />
                        );
                      }
                      if (tempAnnot.type === 'triangle') {
                        const midX = ax + aw / 2;
                        const points = `${midX},${ay} ${ax + aw},${ay + ah} ${ax},${ay + ah}`;
                        return (
                          <polygon
                            points={points}
                            fill={`${currentColor}15`}
                            stroke={currentColor}
                            strokeWidth="3.5"
                            strokeDasharray="4,4"
                          />
                        );
                      }
                      if (tempAnnot.type === 'diagram') {
                        return (
                          <g>
                            <rect
                              x={ax}
                              y={ay}
                              width={aw}
                              height={ah}
                              fill={`${currentColor}15`}
                              stroke={currentColor}
                              strokeWidth="3.5"
                              strokeDasharray="4,4"
                            />
                            <line
                              x1={ax + Math.min(10, aw * 0.15)}
                              y1={ay}
                              x2={ax + Math.min(10, aw * 0.15)}
                              y2={ay + ah}
                              stroke={currentColor}
                              strokeWidth="2"
                            />
                            <line
                              x1={ax + aw - Math.min(10, aw * 0.15)}
                              y1={ay}
                              x2={ax + aw - Math.min(10, aw * 0.15)}
                              y2={ay + ah}
                              stroke={currentColor}
                              strokeWidth="2"
                            />
                          </g>
                        );
                      }
                      if (tempAnnot.type === 'pen' && tempAnnot.points) {
                        const mappedPolyPoints = parsePenPointsToAbs(tempAnnot.points, layout);
                        return (
                          <polyline
                            points={mappedPolyPoints}
                            fill="none"
                            stroke={currentColor}
                            strokeWidth="5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        );
                      }
                    })()}
                  </>
                )}
              </svg>


              {/* INTERACTIVE STICKY NOTES, LABELS & FAULT PIN MARKERS overlays */}
              <div className="absolute inset-0 w-full h-full pointer-events-none z-30">
                
                {/* 1. FAULT CAMERA PIN MARKERS (Mapped exactly over blueprint cards or stacked dynamically) */}
                {(() => {
                  // Group markers close to each other on the same drawing
                  const clusters: { [key: string]: MarkerNote[] } = {};
                  const visited = new Set<string>();
                  
                  // Sort markers newest first so the latest error at a spot is the primary one
                  const sorted = [...markers].sort((a, b) => b.createdAt - a.createdAt);
                  
                  for (const m of sorted) {
                    if (visited.has(m.id)) continue;
                    
                    // Find close markers on the same floor plan
                    const closeGroup = sorted.filter(other => {
                      if (other.floorPlanId !== m.floorPlanId || visited.has(other.id)) return false;
                      const dx = other.x - m.x;
                      const dy = other.y - m.y;
                      const distance = Math.sqrt(dx * dx + dy * dy);
                      // Consider co-located if distance <= 2% of the drawing width/height
                      return distance <= 2.0;
                    });
                    
                    if (closeGroup.length > 0) {
                      clusters[m.id] = closeGroup;
                      for (const item of closeGroup) {
                        visited.add(item.id);
                      }
                    }
                  }

                  return Object.entries(clusters).map(([primaryId, closeGroup]) => {
                    const primaryMarker = closeGroup[0]; // The newest one is first due to sort
                    const parentIdx = floorPlans.findIndex(p => p.id === primaryMarker.floorPlanId);
                    if (parentIdx === -1) return null;
                    
                    const layout = getLayoutForPlan(primaryMarker.floorPlanId);
                    
                    // Center coordinate of this cluster grouping
                    const ax = layout.x + (primaryMarker.x / 100) * layout.w;
                    const ay = layout.y + (primaryMarker.y / 100) * layout.h;

                    // A cluster/group is selected if ANY marker in it is selected
                    const isGroupSelected = closeGroup.some(item => item.id === selectedMarkerId);
                    // A cluster is in presentation if any marker in it matches presentation slide
                    const isGroupCurrentSlide = isPresentationMode && closeGroup.some(item => activePlanMarkers[currentSlideIndex]?.id === item.id);
                    
                    const isActive = isGroupCurrentSlide || isGroupSelected;
                    
                    // Hover state: we target primaryId
                    const isHovered = hoveredMarkerId === primaryId && !isGroupSelected;
                    
                    const hasConcept = closeGroup.some(item => item.conceptNotes || item.conceptPhotoData);

                    return (
                      <div
                        key={primaryId}
                        onMouseEnter={() => setHoveredMarkerId(primaryId)}
                        onMouseLeave={() => setHoveredMarkerId(null)}
                        className={`absolute -translate-x-1/2 -translate-y-1/2 marker-pin-button ${
                          activeWhiteboardTool === 'marker' ? 'pointer-events-none' : 'pointer-events-auto'
                        }`}
                        style={{ 
                          left: `${ax}px`, 
                          top: `${ay}px`,
                          zIndex: isGroupSelected || isHovered ? 50 : 30 
                        }}
                      >
                        {/* Ping Animation backplane */}
                        <span className={`absolute inline-flex h-16 w-16 rounded-full opacity-70 -left-3 -top-3 animate-ping ${
                          isGroupCurrentSlide 
                            ? 'bg-yellow-400' 
                            : isGroupSelected 
                              ? 'bg-emerald-400' 
                              : 'bg-rose-500'
                        }`} />
                        
                        {/* Main clickable button pin */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveFloorPlanId(primaryMarker.floorPlanId);
                            onSelectMarker(primaryMarker.id);
                            onSelectAnnotation(null);
                            setActiveWhiteboardTool('select');
                            if (isPresentationMode) {
                              const sIdx = activePlanMarkers.findIndex(m => m.id === primaryMarker.id);
                              if (sIdx !== -1) setCurrentSlideIndex(sIdx);
                            }
                          }}
                          onMouseDown={(e) => {
                            e.stopPropagation();
                          }}
                          onTouchStart={(e) => {
                            e.stopPropagation();
                          }}
                          className="relative h-10 w-10 rounded-full border-4 shadow-2xl flex items-center justify-center transition-all duration-200 transform hover:scale-125 cursor-pointer focus:outline-none"
                          style={{
                            backgroundColor: isGroupCurrentSlide 
                              ? '#f59e0b' // amber-500
                              : isGroupSelected 
                                ? '#10b981' // emerald-500
                                : '#e11d48', // rose-600
                            borderColor: isGroupCurrentSlide 
                              ? '#fde047' // yellow-300
                              : '#ffffff',
                            color: isGroupCurrentSlide ? '#0f172a' : '#ffffff',
                            boxShadow: isGroupSelected 
                              ? '0 0 20px rgba(16, 185, 129, 0.4)' 
                              : '0 10px 25px rgba(0, 0, 0, 0.3)'
                          }}
                        >
                          <span className="text-sm">📷</span>
                        </button>
                        
                        {/* Count Badge for Multi-Fault stacking */}
                        {closeGroup.length > 1 && (
                          <div 
                            className="absolute -bottom-1 -right-1 bg-amber-500 border-2 border-slate-900 text-slate-950 text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow-lg select-none z-50 animate-pulse" 
                            title={`Có ${closeGroup.length} lỗi trùng lặp tại vị trí này!`}
                          >
                            {closeGroup.length}
                          </div>
                        )}

                        {/* Concept analysis indicator badge */}
                        {hasConcept && (
                          <div className="absolute -top-1.5 -right-1.5 bg-indigo-600 border-2 border-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center shadow-lg animate-bounce select-none z-50" title="Có phân tích concept ý tưởng / Ảnh minh họa">
                            💡
                          </div>
                        )}

                        {/* Interactive List Tooltip for detailed hovering */}
                        {isHovered && (
                          <div 
                            onClick={(e) => e.stopPropagation()}
                            onMouseDown={(e) => e.stopPropagation()}
                            className="absolute z-65 flex flex-col bg-[#0b0d19]/98 text-slate-100 rounded-3xl border-2 border-indigo-500/80 p-3.5 shadow-[0_15px_40px_rgba(0,0,0,0.85)] w-[300px] font-sans -translate-x-1/2 -translate-y-[calc(100%+14px)] transition-all duration-150 backdrop-blur-md cursor-default pointer-events-auto"
                          >
                            <div className="text-[10px] font-black uppercase tracking-wider text-indigo-400 mb-2 flex items-center justify-between border-b border-slate-800 pb-1.5">
                              <span>📍 VỊ TRÍ: {closeGroup.length} LỖI GHI NHẬN</span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setHoveredMarkerId(null);
                                  setActiveFloorPlanId(primaryMarker.floorPlanId);
                                  onAddMarker(primaryMarker.x, primaryMarker.y);
                                }}
                                className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-2.5 py-1 rounded-xl text-[8.5px] cursor-pointer transition-all flex items-center justify-center gap-1 hover:scale-105 active:scale-95 border border-emerald-500 hover:border-emerald-400 no-pan-trigger shadow-md shrink-0 select-none"
                                title="Ghi nhận thêm 1 lỗi mới chồng tại chính vị trí này"
                              >
                                ➕ Thêm lỗi ở đây
                              </button>
                            </div>

                            <div className="flex flex-col gap-2 max-h-[220px] overflow-y-auto pr-1 select-none custom-scrollbar pb-1">
                              {closeGroup.map((item) => {
                                const isItemSelected = selectedMarkerId === item.id;
                                const itemStatus = item.tags && item.tags[0] ? item.tags[0] : 'Chưa sửa';
                                const tagStyles: Record<string, string> = {
                                  'Chưa sửa': 'text-rose-400 bg-rose-500/10 border-rose-500/20',
                                  'Đang sửa': 'text-amber-400 bg-amber-500/10 border-amber-500/20',
                                  'Đã duyệt': 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
                                };
                                return (
                                  <div
                                    key={item.id}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setActiveFloorPlanId(item.floorPlanId);
                                      onSelectMarker(item.id);
                                      onSelectAnnotation(null);
                                      setActiveWhiteboardTool('select');
                                      if (isPresentationMode) {
                                        const sIdx = activePlanMarkers.findIndex(x => x.id === item.id);
                                        if (sIdx !== -1) setCurrentSlideIndex(sIdx);
                                      }
                                    }}
                                    className={`flex items-start gap-2.5 p-2 rounded-xl border cursor-pointer transition-all duration-100 ${
                                      isItemSelected 
                                        ? 'border-indigo-500 bg-indigo-950/40 shadow-[0_0_10px_rgba(99,102,241,0.2)]' 
                                        : 'border-slate-800/80 bg-slate-900/50 hover:bg-slate-850 hover:border-slate-700'
                                    }`}
                                  >
                                    {item.photoData ? (
                                      <img 
                                        src={item.photoData} 
                                        alt="Thumbnail" 
                                        className="w-10 h-10 object-cover rounded-lg border border-slate-800 bg-slate-950 shrink-0"
                                        referrerPolicy="no-referrer"
                                      />
                                    ) : (
                                      <div className="w-10 h-10 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-center shrink-0">
                                        <Camera className="w-4 h-4 text-slate-500" />
                                      </div>
                                    )}
                                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                                      <h6 className={`font-extrabold text-[11px] leading-tight truncate ${isItemSelected ? 'text-indigo-400' : 'text-white'}`}>
                                        {item.title || "Lỗi thi công chưa đặt tên"}
                                      </h6>
                                      <p className="text-[10px] text-slate-400 line-clamp-1 italic mt-0.5">
                                        {item.transcription || item.textNotes || "Chưa có mô tả chi tiết..."}
                                      </p>
                                      <div className="flex items-center justify-between mt-1.5 text-[9px]">
                                        <span className={`px-1.5 py-0.5 rounded border text-[8px] font-black ${tagStyles[itemStatus] || 'text-rose-400'}`}>
                                          {itemStatus}
                                        </span>
                                        <span className="text-slate-500 text-[8px] font-mono">
                                          📅 {new Date(item.createdAt).toLocaleDateString('vi-VN')}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>

                            <div className="mt-2.5 pt-2 border-t border-slate-800 text-center text-[8.5px] text-indigo-400 font-black tracking-wider animate-pulse select-none">
                              👉 CLICK DÒNG ĐỂ LỰA CHỌN XEM CHI TIẾT
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  });
                })()}

                {/* 1.5 FLOATING COLLABORATIVE COMMENT POPUP NEXT TO SELECTED PIN (Miro style) */}
                {(() => {
                  if (!selectedMarkerId) return null;
                  const activeM = markers.find(m => m.id === selectedMarkerId);
                  if (!activeM) return null;
                  
                  const pIdx = floorPlans.findIndex(p => p.id === activeM.floorPlanId);
                  if (pIdx === -1) return null;
                  
                  const layout = getLayoutForPlan(activeM.floorPlanId);
                  const ax = layout.x + (activeM.x / 100) * layout.w;
                  const ay = layout.y + (activeM.y / 100) * layout.h;
                  const activeComments = activeM.comments || [];
                  
                  // Handle sending comments in-place on the whiteboard canvas
                  const submitInPlaceComment = () => {
                    if (!inPlaceCommentText.trim() || !onUpdateMarker) return;
                    
                    const newReply = {
                      id: `reply-${Date.now()}`,
                      userId: activeUserRole.id,
                      userName: activeUserRole.name,
                      userRole: activeUserRole.role,
                      content: inPlaceCommentText.trim(),
                      createdAt: Date.now()
                    };
                    
                    const updated = {
                      ...activeM,
                      comments: [...activeComments, newReply]
                    };
                    
                    onUpdateMarker(updated);
                    setInPlaceCommentText('');
                  };
                  
                  const handlePopupUploadPhoto = (e: ChangeEvent<HTMLInputElement>) => {
                    const file = e.target.files?.[0];
                    if (file && onUpdateMarker) {
                      const reader = new FileReader();
                      reader.onloadend = () => {
                        onUpdateMarker({
                          ...activeM,
                          photoData: reader.result as string
                        });
                      };
                      reader.readAsDataURL(file);
                    }
                  };

                  const handlePopupUploadDetail = (e: ChangeEvent<HTMLInputElement>) => {
                    const file = e.target.files?.[0];
                    if (file && onUpdateMarker) {
                      const reader = new FileReader();
                      reader.onloadend = () => {
                        onUpdateMarker({
                          ...activeM,
                          conceptPhotoData: reader.result as string
                        });
                      };
                      reader.readAsDataURL(file);
                    }
                  };

                  const handleToggleStatus = (status: string) => {
                    if (!onUpdateMarker) return;
                    onUpdateMarker({
                      ...activeM,
                      tags: [status]
                    });
                  };

                  const togglePopoverAudio = () => {
                    const audioEl = document.getElementById(`popover-audio-${activeM.id}`) as HTMLAudioElement;
                    if (!audioEl) return;
                    if (audioEl.paused) {
                      audioEl.play().then(() => {
                        setIsPopoverAudioPlaying(true);
                      }).catch(err => console.error("Audio playback blocked:", err));
                      audioEl.onended = () => {
                        setIsPopoverAudioPlaying(false);
                      };
                    } else {
                      audioEl.pause();
                      setIsPopoverAudioPlaying(false);
                    }
                  };

                  const currentStatus = activeM.tags && activeM.tags[0] ? activeM.tags[0] : 'Chưa sửa';

                  return (
                    <div 
                      className="absolute z-50 pointer-events-auto flex"
                      style={{ 
                        left: `${ax + 24}px`, 
                        top: `${ay - 140}px`,
                        width: '380px'
                      }}
                      onClick={(e) => e.stopPropagation()}
                    >
                      {/* Miro-style connective arrowhead pointing to the camera pin */}
                      <div className="absolute left-[-8px] top-[152px] w-0 h-0 border-t-[8px] border-t-transparent border-r-[8px] border-r-[#0f1222] border-b-[8px] border-b-transparent z-10" />
                      
                      {/* Dark Elegant Glass Card Popover with blue glow border from screenshot */}
                      <div className="bg-[#0f1222] text-slate-100 rounded-3xl border-2 border-indigo-500 shadow-[0_20px_50px_rgba(8,10,24,0.8)] flex flex-col w-full overflow-hidden font-sans">
                        
                        {/* Popover Header with Title and Close Button */}
                        <div className="px-4 py-3 bg-[#151930] border-b border-slate-800 flex flex-col gap-2">
                          <div className="flex items-start justify-between">
                            <div className="flex-1 pr-2">
                              <input 
                                type="text"
                                value={activeM.title}
                                onChange={(e) => {
                                  if (onUpdateMarker) {
                                    onUpdateMarker({
                                      ...activeM,
                                      title: e.target.value
                                    });
                                  }
                                }}
                                className="w-full bg-transparent border-none text-white font-extrabold text-xs focus:ring-1 focus:ring-indigo-500 rounded px-1 -ml-1 text-ellipsis outline-none placeholder-slate-400"
                                placeholder="Nhập tên lỗi kỹ thuật..."
                              />
                              <div className="text-[9px] text-slate-400 font-mono mt-0.5 flex items-center gap-1">
                                <Calendar className="w-2.5 h-2.5 text-indigo-400" />
                                {new Date(activeM.createdAt).toLocaleDateString('vi-VN')} {new Date(activeM.createdAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </div>
                            
                            <button 
                              onClick={() => {
                                onSelectMarker(null);
                                setIsPopoverAudioPlaying(false);
                              }}
                              className="p-1 hover:bg-slate-800 rounded-full transition-colors cursor-pointer text-slate-400 hover:text-white shrink-0"
                              title="Đóng bảng thông tin"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Quick Interactive Status selector */}
                          <div className="flex items-center gap-1 border-t border-slate-800/80 pt-2 pb-0.5">
                            <span className="text-[9px] text-slate-400 font-bold uppercase mr-1">Trạng thái:</span>
                            {[
                              { value: 'Chưa sửa', label: '🔴 Chưa sửa', color: 'bg-rose-500/25 border-rose-500 text-rose-300' },
                              { value: 'Đang sửa', label: '🟡 Đang sửa', color: 'bg-amber-500/25 border-amber-500 text-amber-300' },
                              { value: 'Đã duyệt', label: '🟢 Đã duyệt', color: 'bg-emerald-500/25 border-emerald-500 text-emerald-300' }
                            ].map((st) => (
                              <button
                                key={st.value}
                                onClick={() => handleToggleStatus(st.value)}
                                className={`text-[9px] px-1.5 py-0.5 border rounded-md font-bold transition-all cursor-pointer ${
                                  currentStatus === st.value 
                                    ? st.color
                                    : 'bg-slate-900/50 border-slate-800/80 text-slate-400 hover:text-white'
                                }`}
                              >
                                {st.value}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Interactive Tab navigation bar */}
                        <div className="grid grid-cols-3 border-b border-slate-800 text-[10.5px] bg-[#111425] text-center font-bold">
                          <button
                            onClick={() => setPopoverTab('info')}
                            className={`py-2 flex items-center justify-center gap-1 cursor-pointer border-b-2 transition-colors ${
                              popoverTab === 'info'
                                ? 'border-emerald-500 text-emerald-400 bg-slate-900/40'
                                : 'border-transparent text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            <Camera className="w-3.5 h-3.5" />
                            <span>Hiện Trạng</span>
                          </button>
                          <button
                            onClick={() => setPopoverTab('detail')}
                            className={`py-2 flex items-center justify-center gap-1 cursor-pointer border-b-2 transition-colors ${
                              popoverTab === 'detail'
                                ? 'border-cyan-500 text-cyan-400 bg-slate-900/40'
                                : 'border-transparent text-slate-400 hover:text-slate-200'
                            }`}
                            title="Gửi chi tiết bản vẽ thi công"
                          >
                            <Lightbulb className="w-3.5 h-3.5" />
                            <span>Bản Vẽ Detail</span>
                          </button>
                          <button
                            onClick={() => setPopoverTab('discuss')}
                            className={`py-2 flex items-center justify-center gap-1 cursor-pointer border-b-2 transition-colors ${
                              popoverTab === 'discuss'
                                ? 'border-indigo-500 text-indigo-400 bg-slate-900/40'
                                : 'border-transparent text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Thảo Luận ({activeComments.length})</span>
                          </button>
                        </div>
                        
                        {/* Tab Content 1: Fault Info */}
                        {popoverTab === 'info' && (
                          <div className="px-4 py-3.5 flex flex-col gap-3.5 max-h-[280px] overflow-y-auto scrollbar-thin">
                            {/* Photo field status */}
                            {activeM.photoData ? (
                              <div className="relative rounded-2xl overflow-hidden border border-slate-800 group shadow-md bg-slate-900">
                                <img 
                                  src={activeM.photoData} 
                                  alt="Hiện trạng lỗi" 
                                  className="w-full max-h-[125px] object-cover block transition-transform duration-300 group-hover:scale-105"
                                  referrerPolicy="no-referrer"
                                />
                                <div className="absolute bottom-1.5 left-1.5 bg-slate-950/80 border border-slate-800 text-[8.5px] font-mono font-bold px-1.5 py-0.5 rounded backdrop-blur-xs">
                                  Ảnh hiện trường thực tế
                                </div>
                                <button
                                  onClick={() => {
                                    if (onUpdateMarker) onUpdateMarker({ ...activeM, photoData: null });
                                  }}
                                  className="absolute top-1.5 right-1.5 p-1 bg-slate-950/70 hover:bg-rose-600 rounded-full border border-slate-850 text-slate-300 hover:text-white transition-colors cursor-pointer"
                                  title="Gỡ ảnh"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            ) : (
                              <div className="h-[105px] border-2 border-dashed border-slate-800 bg-slate-900/30 rounded-2xl flex flex-col items-center justify-center text-center p-3">
                                <Camera className="w-5 h-5 text-slate-500 mb-1" />
                                <span className="text-[11px] font-bold text-slate-400 mb-1.5">Chưa có ảnh khảo sát hiện trạng</span>
                                <div>
                                  <label 
                                    htmlFor="popup-photo-uploader"
                                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-[10px] font-bold rounded-lg border border-slate-700 cursor-pointer transition-colors"
                                  >
                                    📁 Chọn tệp ảnh tải lên
                                  </label>
                                  <input 
                                    type="file" 
                                    id="popup-photo-uploader" 
                                    className="hidden" 
                                    accept="image/*" 
                                    onChange={handlePopupUploadPhoto} 
                                  />
                                </div>
                              </div>
                            )}

                            {/* Play Voice descriptions with custom audio controls */}
                            {activeM.audioData ? (
                              <div className="bg-[#12162a] border border-slate-800 p-2.5 rounded-2xl flex items-center justify-between gap-2.5">
                                <div className="flex items-center gap-2 min-w-0 flex-1">
                                  <button
                                    onClick={togglePopoverAudio}
                                    className="w-8.5 h-8.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-full flex items-center justify-center flex-shrink-0 transition-all font-black animate-pulse cursor-pointer"
                                    title={isPopoverAudioPlaying ? "Tạm dừng" : "Phát voice note thuyết minh"}
                                  >
                                    {isPopoverAudioPlaying ? (
                                      <Pause className="w-4 h-4 fill-slate-950" />
                                    ) : (
                                      <Play className="w-4 h-4 fill-slate-950 translate-x-[1px]" />
                                    )}
                                  </button>
                                  <div className="min-w-0 flex-1">
                                    <div className="text-[8.5px] uppercase font-black text-emerald-400 tracking-wider leading-none mb-0.5">Thuyết Minh Giọng Nói</div>
                                    <p className="text-[10px] text-slate-200 font-sans italic truncate">
                                      {activeM.transcription || 'Nhấn nút để nghe ghi chú hiện trường...'}
                                    </p>
                                  </div>
                                </div>
                                <audio 
                                  id={`popover-audio-${activeM.id}`} 
                                  src={activeM.audioData} 
                                  onEnded={() => setIsPopoverAudioPlaying(false)}
                                  className="hidden" 
                                />
                              </div>
                            ) : (
                              <div className="p-2 border border-slate-800 bg-slate-900/10 rounded-xl text-center text-[10px] text-slate-500 italic">
                                🎙 Chưa đính kèm voice note hiện trường
                              </div>
                            )}

                            {/* Detailed Description and Voice transcription translation info */}
                            <div className="flex flex-col gap-1">
                              <span className="text-[9px] uppercase font-black tracking-wider text-slate-400">Ghi chú hoặc Dịch thoại:</span>
                              <textarea
                                value={activeM.textNotes || ''}
                                onChange={(e) => {
                                  if (onUpdateMarker) {
                                    onUpdateMarker({
                                      ...activeM,
                                      textNotes: e.target.value
                                    });
                                  }
                                }}
                                rows={2}
                                className="w-full bg-[#131627] border border-slate-800 rounded-xl p-2 text-xs text-slate-200 placeholder-slate-405 resize-none focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans"
                                placeholder="Gõ mô tả lỗi kỹ thuật chi tiết tại đây..."
                              />
                            </div>
                          </div>
                        )}

                        {/* Tab Content 2: Architect's Proposed Detail & Rectification Blueprint */}
                        {popoverTab === 'detail' && (
                          <div className="px-4 py-3.5 flex flex-col gap-3.5 max-h-[280px] overflow-y-auto scrollbar-thin">
                            
                            {/* Blue explanatory Banner */}
                            <div className="bg-cyan-950/20 border border-cyan-800/40 text-[10.5px] leading-relaxed p-2.5 rounded-2xl text-cyan-300">
                              🏠 <strong>Hỗ trợ từ xa:</strong> Nhân sự ở văn phòng có thể đính kèm ảnh <strong>bản vẽ chi tiết thiết kế (Detail)</strong> & hướng dẫn kỹ thuật vào vị trí này để các bạn ngoài công trình thi công chuẩn xác!
                            </div>

                            {/* Illustrative drawing proposed detail drawing input or rendering */}
                            {activeM.conceptPhotoData ? (
                              <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 group shadow-md">
                                <img 
                                  src={activeM.conceptPhotoData} 
                                  alt="Bản vẽ Detail hướng dẫn" 
                                  className="w-full max-h-[125px] object-cover block transition-transform duration-300 group-hover:scale-105"
                                  referrerPolicy="no-referrer"
                                />
                                <div className="absolute bottom-1.5 left-1.5 bg-slate-950/80 border border-slate-800 text-[8.5px] font-mono font-bold px-1.5 py-0.5 rounded backdrop-blur-xs text-cyan-400">
                                  Bản vẽ Detail kỹ thuật thiết kế
                                </div>
                                <button
                                  onClick={() => {
                                    if (onUpdateMarker) onUpdateMarker({ ...activeM, conceptPhotoData: null });
                                  }}
                                  className="absolute top-1.5 right-1.5 p-1 bg-slate-950/70 hover:bg-rose-600 rounded-full border border-slate-850 text-slate-300 hover:text-white transition-colors cursor-pointer"
                                  title="Gỡ bản vẽ"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            ) : (
                              <div className="h-[105px] border-2 border-dashed border-cyan-950 bg-cyan-950/10 rounded-2xl flex flex-col items-center justify-center text-center p-3">
                                <Lightbulb className="w-5 h-5 text-cyan-500 mb-1" />
                                <span className="text-[11px] font-bold text-slate-400 mb-1.5">Chưa gửi tệp bản vẽ Detail thiết kế</span>
                                <div>
                                  <label 
                                    htmlFor="popup-detail-uploader"
                                    className="px-2.5 py-1 bg-cyan-900/60 hover:bg-cyan-800 text-cyan-200 hover:text-white text-[10px] font-bold rounded-lg border border-cyan-800 cursor-pointer transition-colors"
                                  >
                                    ➕ Tải Bản Vẽ Detail (Ảnh)
                                  </label>
                                  <input 
                                    type="file" 
                                    id="popup-detail-uploader" 
                                    className="hidden" 
                                    accept="image/*" 
                                    onChange={handlePopupUploadDetail} 
                                  />
                                </div>
                              </div>
                            )}

                            {/* Rectifying detail texts direction guide */}
                            <div className="flex flex-col gap-1">
                              <span className="text-[9px] uppercase font-black tracking-wider text-cyan-400">Chỉ bảo kỹ thuật / Hướng dẫn cách xử lý:</span>
                              <textarea
                                value={activeM.conceptNotes || ''}
                                onChange={(e) => {
                                  if (onUpdateMarker) {
                                    onUpdateMarker({
                                      ...activeM,
                                      conceptNotes: e.target.value
                                    });
                                  }
                                }}
                                rows={3}
                                className="w-full bg-[#131627] border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 placeholder-slate-500 resize-none focus:outline-none focus:ring-1 focus:ring-cyan-505 font-sans"
                                placeholder="Gõ hướng dẫn cách sửa, kích thước, chủng loại vật liệu sửa lỗi..."
                              />
                            </div>
                          </div>
                        )}

                        {/* Tab Content 3: Discussion List of Comments */}
                        {popoverTab === 'discuss' && (
                          <div className="px-4 py-3.5 flex flex-col gap-3 max-h-[220px] overflow-y-auto scrollbar-thin bg-[#0f1222]">
                            {activeComments.length === 0 ? (
                              <div className="py-8 text-center text-slate-500 text-xs italic flex flex-col items-center gap-1.5">
                                <MessageSquare className="w-6 h-6 text-slate-700 animate-pulse" />
                                <span>Vị trí lỗi chưa có thảo luận nào.</span>
                                <span className="text-[11px] text-indigo-400 not-italic font-medium">Bình luận nhanh dưới đây để thảo luận!</span>
                              </div>
                            ) : (
                              activeComments.map((c) => {
                                const roleCol = userRolesList.find(r => r.name === c.userName)?.color || '#4f46e5';
                                
                                // Check and replace "@mention" with styled tags
                                const renderWithMentions = (text: string) => {
                                  const parts = text.split(/(\s+)/);
                                  return parts.map((part, pIdx) => {
                                    if (part.startsWith('@')) {
                                      return (
                                        <span key={pIdx} className="text-cyan-400 font-bold bg-cyan-950/40 px-1 py-0.5 rounded text-[10.5px]">
                                          {part}
                                        </span>
                                      );
                                    }
                                    return part;
                                  });
                                };
                                
                                return (
                                  <div key={c.id} className="flex flex-col gap-0.5 text-[11px] bg-[#151829] border border-slate-800/80 p-2.5 rounded-2xl">
                                    <div className="flex items-center justify-between">
                                      <span className="font-extrabold text-white flex items-center gap-1">
                                        <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ backgroundColor: roleCol }} />
                                        {c.userName}
                                      </span>
                                      <span className="text-[8.5px] text-slate-500 font-mono">
                                        {new Date(c.createdAt).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}
                                      </span>
                                    </div>
                                    <span className="text-[8.5px] font-bold text-indigo-305 text-indigo-300 uppercase tracking-widest">
                                      {c.userRole}
                                    </span>
                                    <p className="text-slate-300 mt-1 font-sans break-words whitespace-pre-wrap">
                                      {renderWithMentions(c.content)}
                                    </p>
                                  </div>
                                );
                              })
                            )}
                          </div>
                        )}
                        
                        {/* Replying Context Indicator */}
                        <div className="px-4 py-1.5 bg-[#121628]/80 text-[10px] text-slate-400 flex items-center justify-between border-t border-slate-800/60 leading-none shrink-0 border-slate-800">
                          <span className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full inline-block animate-pulse" style={{ backgroundColor: activeUserRole.color }} />
                            Đang bình luận: <strong className="text-slate-200">{activeUserRole.name}</strong>
                          </span>
                        </div>
                        
                        {/* Comment Input Footer area */}
                        <div className="px-3.5 py-3 bg-[#131627] border-t border-[#1e293b] flex flex-col gap-2 shrink-0">
                          <div className="flex items-stretch gap-1.5">
                            <textarea
                              rows={2}
                              value={inPlaceCommentText}
                              onChange={(e) => setInPlaceCommentText(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                  e.preventDefault();
                                  submitInPlaceComment();
                                }
                              }}
                              placeholder="Gõ bình luận hoặc @Username..."
                              className="flex-1 bg-[#181c32] border border-slate-800 text-xs px-3 py-1.5 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 text-white placeholder-[#4d516d] resize-none font-sans"
                            />
                            
                            <button
                              onClick={submitInPlaceComment}
                              className="px-3 bg-indigo-600 hover:bg-[#6366f1] active:bg-indigo-800 text-white rounded-xl shadow-lg transition-colors flex items-center justify-center shrink-0 cursor-pointer"
                              title="Gửi phản hồi nhanh tại vị trí"
                            >
                              <Send className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="flex items-center justify-between text-[9px] text-[#4d516d] leading-none">
                            <span>Enter để gửi, Shift+Enter xuống dòng</span>
                            <span className="text-cyan-400 font-medium font-sans">DQH Architects</span>
                          </div>
                        </div>

                      </div>
                    </div>
                  );
                })()}


                {/* 2. MIRO INTERACTIVE STICKY NOTES AND FREE TEXT IN FRAME CARD LAYERS */}
                {annotations.slice().sort((a, b) => a.createdAt - b.createdAt).map((annot) => {
                  if (annot.type !== 'sticky' && annot.type !== 'text' && annot.type !== 'frame') return null;
                  
                  const isSelected = selectedAnnotationId === annot.id;
                  const isDragging = draggingAnnotId === annot.id;
                  const layout = getLayoutForPlan(annot.floorPlanId);

                  // Compute whiteboard absolute coordinate values
                  const ax = layout.x + (annot.x / 100) * layout.w;
                  const ay = layout.y + (annot.y / 100) * layout.h;
                  const aw = (annot.width / 100) * layout.w;
                  const ah = (annot.height / 100) * layout.h;

                  if (annot.type === 'frame') {
                    const isTitleEditing = editingFrameId === annot.id;
                    return (
                      <div
                        key={annot.id}
                        onMouseDown={(e) => handleAnnotDragStart(e, annot)}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectAnnotation(annot.id);
                          onSelectMarker(null);
                        }}
                        className={`absolute whiteboard-element pointer-events-auto select-none ${isDragging ? '' : 'transition-all'} group ${
                          isSelected ? 'z-30' : 'z-10'
                        }`}
                        style={{
                          left: `${ax}px`,
                          top: `${ay - 34}px`, // 34px above the frame top boundary
                          height: '32px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '6px',
                        }}
                      >
                        {/* Miro-style editable name handle tag */}
                        <div 
                          className={`px-3 py-1.5 text-xs font-extrabold flex items-center gap-1.5 rounded-t-xl border-t border-x shadow-md transition-colors ${
                            isSelected 
                              ? 'bg-indigo-600 text-white border-indigo-500' 
                              : 'bg-slate-900/95 text-indigo-400 border-slate-800 hover:text-indigo-300'
                          }`}
                        >
                          <Frame className="w-3.5 h-3.5 animate-pulse" />
                          {isTitleEditing ? (
                            <input
                              autoFocus
                              type="text"
                              value={annot.content || ''}
                              onClick={(e) => e.stopPropagation()}
                              onMouseDown={(e) => e.stopPropagation()}
                              onChange={(e) => {
                                onUpdateAnnotation({
                                  ...annot,
                                  content: e.target.value
                                });
                              }}
                              onBlur={() => setEditingFrameId(null)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  setEditingFrameId(null);
                                }
                              }}
                              className="bg-slate-950 text-white border border-indigo-500 rounded px-1.5 py-0.5 outline-none font-extrabold text-[11px] max-w-[150px] focus:ring-1 focus:ring-indigo-400"
                            />
                          ) : (
                            <span 
                              onDoubleClick={(e) => {
                                e.stopPropagation();
                                setEditingFrameId(annot.id);
                              }}
                              className="cursor-text select-text"
                              title="Nhấp đúp chuột để đổi tên vùng"
                            >
                              {annot.content || 'Khung chưa đặt tên'}
                            </span>
                          )}
                          
                          {!isTitleEditing && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingFrameId(annot.id);
                              }}
                              className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-slate-850 rounded text-[10px] text-slate-300 hover:text-white transition-opacity ml-1 cursor-pointer flex items-center justify-center font-bold"
                              title="Sửa tên vùng"
                            >
                              ✐
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={annot.id}
                      onMouseDown={(e) => handleAnnotDragStart(e, annot)}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectAnnotation(annot.id);
                        onSelectMarker(null);
                      }}
                      className={`absolute whiteboard-element pointer-events-auto select-none ${isDragging ? '' : 'transition-all'} ${
                        annot.type === 'sticky'
                          ? 'p-3.5 rounded-2xl shadow-2xl border text-sm text-slate-950 flex flex-col justify-between'
                          : 'p-1 text-sm font-bold text-slate-200 border border-transparent hover:border-slate-800 rounded-lg p-2 bg-slate-900/60 backdrop-blur-md'
                      } ${isSelected ? 'ring-8 ring-indigo-500/40 border-indigo-400 shadow-indigo-500/20' : ''} ${
                        isDragging ? 'opacity-80 scale-105 cursor-grabbing' : 'cursor-grab'
                      }`}
                      style={{
                        left: `${ax}px`,
                        top: `${ay}px`,
                        width: annot.type === 'sticky' ? `${aw}px` : 'auto',
                        height: annot.type === 'sticky' ? `${ah}px` : 'auto',
                        minWidth: annot.type === 'sticky' ? '180px' : '150px',
                        minHeight: annot.type === 'sticky' ? '150px' : 'auto',
                        backgroundColor: annot.type === 'sticky' ? `${annot.color}f9` : 'transparent',
                        borderColor: annot.type === 'sticky' ? annot.color : 'transparent',
                        borderLeftWidth: annot.type === 'sticky' ? '12px' : '1px'
                      }}
                    >
                      {/* Miro post-it notes custom interactive textarea */}
                      <textarea
                        value={annot.content}
                        onChange={(e) => {
                          onUpdateAnnotation({
                            ...annot,
                            content: e.target.value
                          });
                        }}
                        placeholder="Có chú thích nào kỹ thuật..."
                        className="w-full h-full bg-transparent border-none outline-none font-bold leading-relaxed resize-none text-xs text-slate-950 placeholder-slate-700 font-sans"
                        style={{ outline: 'none' }}
                        disabled={activeWhiteboardTool !== 'select'}
                      />
                      
                      {/* Creator Profile Avatar bottom footer bar */}
                      {annot.type === 'sticky' && (
                        <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-wider text-slate-700 mt-2.5 border-t border-slate-950/10 pt-2 shrink-0">
                          <span className="truncate max-w-[120px]">✐ {annot.userName}</span>
                          {isSelected && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteAnnotation(annot.id);
                              }}
                              className="p-1 hover:bg-slate-950/10 active:bg-slate-950/20 rounded shadow-sm text-rose-800 cursor-pointer text-xs"
                              title="Delete note"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          /* Blank Board Importer screen */
          <div className="flex flex-col items-center justify-center p-12 text-center max-w-sm shrink-0">
            <div className="w-20 h-20 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mb-6 shadow-inner animate-pulse">
              <Upload className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-100 text-base mb-1">Chưa có bản vẽ dự án nào</h4>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">
              Hãy tải lên bản vẽ thiết kế xây dựng JPG/PNG hoặc xem bản vẽ mẫu để bắt đầu whiteboard đa dự án!
            </p>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-350 font-bold px-6 py-3 rounded-2xl text-slate-950 text-xs shadow-xl cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              Tải bản vẽ kỹ thuật lên ngay
            </button>
          </div>
        )}

        {/* Miro Quick bottom scale controls info HUD */}
        {floorPlans.length > 0 && (
          <div className="absolute bottom-4 right-4 z-25 bg-slate-950/95 backdrop-blur-md rounded-2xl p-1 px-3 border border-slate-800 shadow-2xl flex items-center gap-2 select-none">
            <button onClick={zoomOut} className="p-1.5 text-slate-400 hover:text-white cursor-pointer transition-colors" title="Zoom Out">
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] font-mono font-bold text-indigo-400 px-1 w-11 text-center">{Math.round(zoomLevel * 100)}%</span>
            <button onClick={zoomIn} className="p-1.5 text-slate-400 hover:text-white cursor-pointer transition-colors" title="Zoom In">
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            
            <span className="h-4 w-px bg-slate-800 mx-1"></span>

            <button 
              onClick={() => {
                if (activePlanMarkers.length === 0) {
                  alert("Chưa có điểm ghim khảo sát thực tế hay concept nào được tạo trên bản vẽ này để mở chế độ slide trình diễn thuyết minh.");
                  return;
                }
                setIsPresentationMode(true);
                setCurrentSlideIndex(0);
              }} 
              className="px-3 py-1.5 text-[10.5px] bg-indigo-600 hover:bg-indigo-700 hover:active:bg-indigo-800 text-white rounded-lg font-bold cursor-pointer transition-all flex items-center gap-1.5 shrink-0 shadow-md shadow-indigo-900/20"
              title="Khởi động cuộc họp hoặc xem slide thuyết minh giải pháp kiến trúc"
            >
              <span>Trình Chiếu Slide 📽️</span>
            </button>

            <span className="h-4 w-px bg-slate-800 mx-0.5"></span>

            <button 
              onClick={() => {
                if (activePlanMarkers.length === 0) {
                  alert("Chưa có điểm ghim khảo sát hay đề xuất nào để tạo báo cáo kỹ thuật.");
                  return;
                }
                setIsReportOpen(true);
              }} 
              className="px-3 py-1.5 text-[10.5px] bg-emerald-600 hover:bg-emerald-700 hover:active:bg-emerald-800 text-white rounded-lg font-bold cursor-pointer transition-all flex items-center gap-1.5 shrink-0 shadow-md shadow-emerald-900/20"
              title="Xuất file báo cáo song song dạng PDF / In ấn bản cứng"
            >
              <span>Xuất Báo Cáo 🖨️</span>
            </button>

            <span className="h-4 w-px bg-slate-800 mx-0.5"></span>

            <button 
              onClick={() => {
                setZoomLevel(0.4);
                setDragOffset({ x: 50, y: 50 });
              }} 
              className="px-2.5 py-1 text-[10px] bg-indigo-500/10 border border-indigo-500/15 hover:bg-indigo-500/20 text-indigo-400 rounded-lg font-bold cursor-pointer transition-all"
            >
              Reset
            </button>
          </div>
        )}

        {/* Floating Vietnamese instructions Banner */}
        {floorPlans.length > 0 && showHelperMsg && (
          <div className="absolute bottom-4 left-4 right-4 md:left-1/2 md:right-auto md:-translate-x-1/2 bg-slate-950/95 backdrop-blur-md rounded-2xl px-5 py-3 text-[11px] text-slate-300 border border-slate-800 shadow-2xl flex items-center gap-3.5 max-w-lg z-20">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping shrink-0"></div>
            <div className="min-w-0 flex-1">
              <p className="font-bold text-white text-xs flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-yellow-405" />
                Vùng Whiteboard Hợp Nhất Hoạt Động (Miro Mode)
              </p>
              <p className="text-slate-400 text-[10px] mt-0.5 leading-relaxed">
                Các bản vẽ mặt bằng đang cùng nằm trên **1 Vùng duy nhất**. Phóng to/bản vẽ tự do. Bạn có thể kéo tiêu đề vùng gỗ để sắp xếp vị trí hoặc nhấp **"Phóng Cận Cảnh"** để nhảy nhanh!
              </p>
            </div>
            <button
              onClick={() => setShowHelperMsg(false)}
              className="text-xs text-slate-500 hover:text-white ml-2 cursor-pointer font-bold shrink-0 self-start"
            >
              ✕
            </button>
          </div>
        )}

        {/* SPATIAL PRESENTATION DECK OVERLAY (Sliding Sidebar panel overlay) */}
        {isPresentationMode && currentSlideMarker && (
          <div className="absolute top-16 right-4 bottom-22 w-[480px] bg-slate-950/98 border border-slate-800/85 rounded-3xl shadow-2xl z-40 flex flex-col overflow-hidden text-slate-105 backdrop-blur-md animate-fade-in no-pan-trigger pointer-events-auto">
            {/* Header */}
            <div className="p-4 bg-slate-900 border-b border-slate-800/60 flex items-center justify-between shadow-md">
              <div className="min-w-0 pr-4">
                <span className="text-[10px] tracking-widest font-black uppercase text-indigo-400 block mb-0.5 animate-pulse">
                  ⚡ THUYẾT MINH KHÔNG GIAN DỰ ÁN ({currentSlideIndex + 1}/{activePlanMarkers.length})
                </span>
                <h3 className="text-xs font-bold text-white truncate">{currentSlideMarker.title}</h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsPresentationMode(false);
                  setIsAutoPlaying(false);
                }}
                className="p-1 px-2.5 bg-slate-800 hover:bg-rose-900/50 hover:text-rose-400 text-slate-400 border border-slate-700 rounded-xl text-[10.5px] font-bold transition-all cursor-pointer shadow-sm"
              >
                ✕ Thoát
              </button>
            </div>

            {/* Scrollable Slide Body */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 divide-y divide-slate-800/50 scrollbar-thin">
              
              {/* SECTION 1: FIELD SITE CONDITION SURVEY */}
              <div className="flex flex-col gap-2.5 pt-1">
                <span className="text-[10.5px] uppercase font-extrabold text-emerald-400 flex items-center gap-1">
                  📸 1. Khảo Sát Hiện Trạng Thực Tế
                </span>
                
                {/* Survey Image Render */}
                {currentSlideMarker.photoData ? (
                  <div className="relative rounded-2xl overflow-hidden border border-slate-850 bg-slate-900 group shadow-md">
                    <img 
                      src={currentSlideMarker.photoData} 
                      alt="Hiện trạng thực tế" 
                      className="w-full max-h-[185px] object-cover block transition-transform duration-300 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-2 left-2 bg-slate-950/80 border border-slate-800 text-[9px] font-mono font-bold px-2 py-0.5 rounded-md backdrop-blur-xs">
                      Ảnh chụp hiện trường
                    </div>
                  </div>
                ) : (
                  <div className="h-[120px] bg-slate-900 border border-slate-850/60 rounded-2xl flex flex-col items-center justify-center text-center p-4">
                    <span className="text-slate-500 text-xs italic">Không có ảnh chụp hiện trạng đính kèm</span>
                  </div>
                )}

                {/* Voice notes in slideshow player */}
                {currentSlideMarker.audioData && (
                  <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-2.5 flex flex-col gap-2 shadow-sm mt-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-bold flex items-center gap-1">
                        📢 Thuyết minh ghi âm (Audio file):
                      </span>
                      {presentationAudioUrl && (
                        <button
                          type="button"
                          onClick={togglePresentationAudio}
                          className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[10px] rounded-lg cursor-pointer transition-all flex items-center gap-1 shadow-sm"
                        >
                          {isPlayingPresentationAudio ? "⏸ Dừng" : "▶ Nghe Thuyết Minh"}
                        </button>
                      )}
                    </div>
                    {presentationAudioUrl && (
                      <audio
                        id="presentation-slideshow-player"
                        src={presentationAudioUrl}
                        onEnded={() => setIsPlayingPresentationAudio(false)}
                        className="hidden"
                      />
                    )}
                    {currentSlideMarker.transcription && (
                      <p className="text-[10.5px] italic text-slate-350 leading-relaxed bg-slate-950/50 border-l-2 border-l-emerald-555 p-2 rounded-lg font-sans">
                        "{currentSlideMarker.transcription}"
                      </p>
                    )}
                  </div>
                )}

                {/* Survey detailed texts */}
                {currentSlideMarker.textNotes ? (
                  <div className="bg-slate-905/50 rounded-xl p-3 border border-slate-850 text-xs leading-relaxed text-slate-300 shadow-inner">
                    <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Mô tả chi tiết bổ túc kỹ thuật:</label>
                    <p className="font-sans break-words">{currentSlideMarker.textNotes}</p>
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500 italic">Chưa bổ sung mô tả hiện trạng chi tiết.</p>
                )}
              </div>

              {/* SECTION 2: IDEATION & DESIGN SOLUTION DECK */}
              <div className="flex flex-col gap-2.5 pt-4">
                <span className="text-[10.5px] uppercase font-extrabold text-indigo-400 flex items-center gap-1">
                  💡 2. Ý Tưởng & Giải Pháp Thiết Kế (DQH Concept)
                </span>

                {/* Moodboard Reference Render */}
                {currentSlideMarker.conceptPhotoData ? (
                  <div className="relative rounded-2xl overflow-hidden border border-indigo-950/80 bg-indigo-950/20 group shadow-md animate-fade-in">
                    <img 
                      src={currentSlideMarker.conceptPhotoData} 
                      alt="Ảnh minh họa ý tưởng" 
                      className="w-full max-h-[185px] object-cover block transition-transform duration-300 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-2 left-2 bg-indigo-950/90 border border-indigo-800/50 text-[9px] font-mono font-bold px-2 py-0.5 rounded-md text-indigo-300">
                      Moodboard Ý tưởng / Render đề xuất
                    </div>
                  </div>
                ) : (
                  <div className="h-[120px] bg-indigo-950/10 border border-indigo-950/20 border-dashed rounded-2xl flex flex-col items-center justify-center text-center p-4">
                    <span className="text-slate-500 text-xs italic mb-1">Chưa đính kèm hình ảnh minh họa concept</span>
                    <span className="text-[9px] text-slate-600">Đóng trình chiếu và vào TAB "Ý Tưởng & Minh Họa" ở Sidebar để thêm</span>
                  </div>
                )}

                {/* Concept solution notes */}
                {currentSlideMarker.conceptNotes ? (
                  <div className="bg-indigo-950/20 rounded-xl p-3 border border-indigo-900/30 text-xs leading-relaxed text-indigo-100 shadow-inner">
                    <label className="text-[10px] uppercase font-bold text-indigo-400 block mb-1">Thuyết minh giải pháp đề xuất:</label>
                    <p className="font-sans break-words">{currentSlideMarker.conceptNotes}</p>
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500 italic">Chưa bổ sung thuyết minh concept.</p>
                )}
              </div>
            </div>

            {/* Slide Navigation footer panel */}
            <div className="p-4 bg-slate-900 border-t border-slate-800/80 flex items-center justify-between shrink-0 select-none shadow-inner">
              <button
                type="button"
                disabled={currentSlideIndex === 0}
                onClick={() => setCurrentSlideIndex(currentSlideIndex - 1)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition-all disabled:pointer-events-none cursor-pointer flex items-center gap-0.5 border border-slate-700 shadow-sm"
              >
                ◀ Lùi lại
              </button>

              <div className="flex flex-col items-center">
                <span className="text-[11px] font-mono font-bold text-slate-350">
                  Slide {currentSlideIndex + 1} / {activePlanMarkers.length}
                </span>
                <button
                  type="button"
                  onClick={() => setIsAutoPlaying(!isAutoPlaying)}
                  className={`text-[9.5px] uppercase font-black px-2 py-0.5 mt-1 rounded-md transition-all cursor-pointer ${
                    isAutoPlaying 
                      ? 'bg-amber-500 text-slate-950 animate-pulse' 
                      : 'bg-slate-800 text-slate-405 hover:text-slate-200 border border-slate-700'
                  }`}
                >
                  {isAutoPlaying ? "⏸ Tạm dừng chạy" : "▶ Tự động phát (10s)"}
                </button>
              </div>

              <button
                type="button"
                disabled={currentSlideIndex === activePlanMarkers.length - 1}
                onClick={() => setCurrentSlideIndex(currentSlideIndex + 1)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition-all disabled:pointer-events-none cursor-pointer flex items-center gap-0.5 border border-slate-700 shadow-sm"
              >
                Kế tiếp ▶
              </button>
            </div>
          </div>
        )}

        {/* MIRO-STYLE PROPERTIES CONTEXTUAL TOOLBAR */}
        {selectedAnnotation && (
          <div className="absolute left-1/2 -translate-x-1/2 top-4 z-50 flex flex-col items-center gap-1.5 select-none pointer-events-none no-pan-trigger">
            <div className="p-1.5 bg-slate-900/95 backdrop-blur-lg border border-slate-800 shadow-2xl rounded-2xl flex items-center gap-2 pointer-events-auto text-slate-100 min-h-12 px-3">
              
              {/* Element Description info indicator */}
              <div className="flex items-center gap-2 border-r border-slate-800 pr-2 mr-1">
                <span className="text-xs font-mono px-1 py-0.5 bg-slate-850 rounded text-indigo-400 capitalize">
                  {selectedAnnotation.type.replace('-arrow', ' ➔')}
                </span>
                {selectedAnnotation.isLocked && (
                  <span className="text-[10px] px-1.5 py-0.5 bg-amber-500/20 text-amber-400 rounded-full font-bold flex items-center gap-0.5 animate-pulse">
                    🔒 Đang khóa
                  </span>
                )}
              </div>

              {/* Dynamic Disabled Container based on locked status */}
              <div className={`flex items-center gap-1.5 ${selectedAnnotation.isLocked ? 'pointer-events-none opacity-30' : ''}`}>
                
                {/* 1. Color Picker circle array */}
                <div className="flex items-center gap-1 bg-slate-850/50 p-1 rounded-xl">
                  {['#ef4444', '#10b981', '#3b82f6', '#f59e0b', '#06b6d4', '#8b5cf6', '#64748b'].map(c => (
                    <button
                      key={c}
                      onClick={() => onUpdateAnnotation({ ...selectedAnnotation, color: c })}
                      className="w-5 h-5 rounded-full border border-slate-700 cursor-pointer hover:scale-110 active:scale-95 transition-transform relative"
                      style={{ backgroundColor: c }}
                      title={`Đổi màu ${c}`}
                    >
                      {selectedAnnotation.color === c && (
                        <span className="absolute inset-0 flex items-center justify-center text-[10px] text-white font-black">✓</span>
                      )}
                    </button>
                  ))}
                  
                  {/* Custom color input tool */}
                  <input
                    type="color"
                    value={selectedAnnotation.color}
                    onChange={(e) => onUpdateAnnotation({ ...selectedAnnotation, color: e.target.value })}
                    className="w-5 h-5 bg-transparent border-0 p-0 cursor-pointer rounded-full overflow-hidden"
                    title="Màu tùy chỉnh"
                  />
                </div>

                {/* 2. Stroke Thickness Slider Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setActivePropDropdown(activePropDropdown === 'thickness' ? 'none' : 'thickness')}
                    className={`p-2 rounded-lg text-xs font-bold font-mono transition-colors flex items-center gap-1 border ${
                      activePropDropdown === 'thickness' ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500/30' : 'bg-slate-850 border-slate-750 text-slate-300 hover:bg-slate-800'
                    }`}
                    title="Phát nét vẽ (Cỡ đường nét)"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>{selectedAnnotation.strokeWidth !== undefined ? selectedAnnotation.strokeWidth : (['pen', 'arrow', 'line', 'elbow-arrow'].includes(selectedAnnotation.type) ? 5 : 3.5)}px</span>
                  </button>

                  {activePropDropdown === 'thickness' && (
                    <div className="absolute left-0 top-11 z-50 p-3 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl flex flex-col gap-2 min-w-[180px]">
                      <span className="text-[10px] text-slate-400 font-bold">Cỡ đường nét (Tùy chỉnh):</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="range"
                          min="1"
                          max="20"
                          step="1"
                          value={selectedAnnotation.strokeWidth !== undefined ? selectedAnnotation.strokeWidth : 4}
                          onChange={(e) => onUpdateAnnotation({ ...selectedAnnotation, strokeWidth: parseInt(e.target.value) })}
                          className="w-full accent-indigo-500"
                        />
                        <span className="text-xs font-mono w-6 text-right">
                          {selectedAnnotation.strokeWidth !== undefined ? selectedAnnotation.strokeWidth : 4}px
                        </span>
                      </div>
                      <div className="grid grid-cols-5 gap-1 mt-1">
                        {[2, 4, 6, 8, 12].map(v => (
                          <button
                            key={v}
                            onClick={() => {
                              onUpdateAnnotation({ ...selectedAnnotation, strokeWidth: v });
                              setActivePropDropdown('none');
                            }}
                            className={`p-1 rounded text-[10px] font-mono border ${
                              selectedAnnotation.strokeWidth === v ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                            }`}
                          >
                            {v}px
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* 3. Border Stroke Dash style switch */}
                <div className="relative">
                  <button
                    onClick={() => setActivePropDropdown(activePropDropdown === 'dash' ? 'none' : 'dash')}
                    className={`p-2 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 border capitalize ${
                      activePropDropdown === 'dash' ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500/30' : 'bg-slate-850 border-slate-750 text-slate-300 hover:bg-slate-800'
                    }`}
                    title="Kiểu nét viền đường biên"
                  >
                    <span>{selectedAnnotation.strokeDash || 'Solid'}</span>
                  </button>

                  {activePropDropdown === 'dash' && (
                    <div className="absolute left-0 top-11 z-50 p-1 bg-slate-900 border border-slate-800 rounded-lg shadow-2xl flex flex-col min-w-[125px]">
                      {(['solid', 'dashed', 'dotted'] as const).map(style => (
                        <button
                          key={style}
                          onClick={() => {
                            onUpdateAnnotation({ ...selectedAnnotation, strokeDash: style });
                            setActivePropDropdown('none');
                          }}
                          className={`px-3 py-1.5 text-left rounded text-xs transition-colors hover:bg-slate-850 flex items-center justify-between ${
                            selectedAnnotation.strokeDash === style || (style === 'solid' && !selectedAnnotation.strokeDash)
                              ? 'text-indigo-400 font-bold bg-slate-850/50'
                              : 'text-slate-300'
                          }`}
                        >
                          <span className="capitalize">{style}</span>
                          <span className="text-slate-500 font-mono">
                            {style === 'solid' && "━━━━━"}
                            {style === 'dashed' && "- - - -"}
                            {style === 'dotted' && ". . . ."}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* 4. Shape Fill Opacity switch */}
                <div className="relative">
                  <button
                    onClick={() => setActivePropDropdown(activePropDropdown === 'opacity' ? 'none' : 'opacity')}
                    className={`p-2 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 border ${
                      activePropDropdown === 'opacity' ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500/30 font-bold' : 'bg-slate-850 border-slate-750 text-slate-300 hover:bg-slate-800'
                    }`}
                    title="Đổ màu nền (Nồng độ mờ Fill Alpha)"
                  >
                    <span>Mờ: {selectedAnnotation.opacity !== undefined ? `${selectedAnnotation.opacity}%` : "15%"}</span>
                  </button>

                  {activePropDropdown === 'opacity' && (
                    <div className="absolute left-0 top-11 z-50 p-2 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl flex flex-col gap-1 min-w-[140px]">
                      <span className="text-[10px] text-slate-400 font-bold p-1">Nồng độ màu nền:</span>
                      {[0, 15, 40, 75, 100].map(op => (
                        <button
                          key={op}
                          onClick={() => {
                            onUpdateAnnotation({ ...selectedAnnotation, opacity: op });
                            setActivePropDropdown('none');
                          }}
                          className={`px-3 py-1 text-left rounded text-xs transition-colors hover:bg-slate-850 flex items-center justify-between ${
                            (selectedAnnotation.opacity === op || (op === 15 && selectedAnnotation.opacity === undefined))
                              ? 'text-indigo-400 font-bold bg-slate-850/50'
                              : 'text-slate-300'
                          }`}
                        >
                          <span>{op === 0 ? "Trong suốt (None)" : `${op}%`}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* 5. Path Connector routing options (Only for vectors!) */}
                {['line', 'arrow', 'elbow-arrow'].includes(selectedAnnotation.type) && (
                  <>
                    <div className="relative">
                      <button
                        onClick={() => setActivePropDropdown(activePropDropdown === 'linetype' ? 'none' : 'linetype')}
                        className={`p-2 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 border capitalize ${
                          activePropDropdown === 'linetype' ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500/30' : 'bg-slate-850 border-slate-750 text-slate-300 hover:bg-slate-800'
                        }`}
                        title="Đường rẽ nhánh liên kết"
                      >
                        <span>Cáp: {selectedAnnotation.lineType || 'straight'}</span>
                      </button>

                      {activePropDropdown === 'linetype' && (
                        <div className="absolute left-0 top-11 z-50 p-1 bg-slate-900 border border-slate-800 rounded-lg shadow-2xl flex flex-col min-w-[130px]">
                          {(['straight', 'elbow', 'curved'] as const).map(lt => (
                            <button
                              key={lt}
                              onClick={() => {
                                onUpdateAnnotation({ ...selectedAnnotation, lineType: lt });
                                setActivePropDropdown('none');
                              }}
                              className={`px-3 py-1.5 text-left rounded text-xs transition-colors hover:bg-slate-850 flex items-center justify-between ${
                                selectedAnnotation.lineType === lt || (lt === 'straight' && !selectedAnnotation.lineType)
                                  ? 'text-indigo-400 font-bold bg-slate-850/50'
                                  : 'text-slate-300'
                              }`}
                            >
                              <span className="capitalize">{lt}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Overlapping line jump switch */}
                    <button
                      onClick={() => onUpdateAnnotation({ ...selectedAnnotation, lineJump: !selectedAnnotation.lineJump })}
                      className={`p-2 rounded-lg text-xs font-bold transition-colors border flex items-center gap-1 ${
                        selectedAnnotation.lineJump ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-slate-850 border-slate-750 text-slate-300 hover:bg-slate-800'
                      }`}
                      title="Chế độ Cầu nhảy dây cáp (Tránh chéo nét)"
                    >
                      <span className={selectedAnnotation.lineJump ? 'text-white' : 'text-slate-400'}>⌒</span>
                      <span>Bridge</span>
                    </button>
                  </>
                )}

                {/* 6. Sorting depth positioning layers order */}
                <div className="flex items-center gap-1 bg-slate-850 p-1 rounded-lg border border-slate-750">
                  <button
                    onClick={() => {
                      if (annotations.length <= 1) return;
                      const allTimestamps = annotations.map(a => a.createdAt || 0);
                      const minTimestamp = Math.min(...allTimestamps);
                      onUpdateAnnotation({ ...selectedAnnotation, createdAt: minTimestamp - 1000 });
                    }}
                    className="p-1.5 hover:bg-slate-750 text-slate-300 hover:text-white rounded transition-colors text-xs flex items-center gap-0.5"
                    title="Đưa ra phía sau (Send to Back)"
                  >
                     ▼ Back
                  </button>
                  <span className="h-3 w-[1px] bg-slate-750" />
                  <button
                    onClick={() => {
                      onUpdateAnnotation({ ...selectedAnnotation, createdAt: Date.now() + 10000 });
                    }}
                    className="p-1.5 hover:bg-slate-750 text-slate-300 hover:text-white rounded transition-colors text-xs flex items-center gap-0.5"
                    title="Đưa lên trên cùng (Bring to Front)"
                  >
                     ▲ Front
                  </button>
                </div>

              </div>

              {/* 7. Miro Lock / Unlock Controller (Permanently interactive out of lock) */}
              <button
                onClick={() => onUpdateAnnotation({ ...selectedAnnotation, isLocked: !selectedAnnotation.isLocked })}
                className={`p-2.5 rounded-lg transition-colors border cursor-pointer ${
                  selectedAnnotation.isLocked
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold hover:bg-amber-400 shadow-lg'
                    : 'bg-slate-850 hover:bg-slate-850 text-slate-300 border-slate-750 hover:text-slate-100'
                }`}
                title={selectedAnnotation.isLocked ? "Mở khóa hình vẽ (Unlock)" : "Khóa hình vẽ cố định (Miro-style Lock)"}
              >
                {selectedAnnotation.isLocked ? (
                  <div className="flex items-center gap-1 text-[11px]">
                    <Lock className="w-3.5 h-3.5" />
                    <span>Mở khóa</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 text-[11px]">
                    <Unlock className="w-3.5 h-3.5 text-slate-400" />
                    <span>Khóa nét</span>
                  </div>
                )}
              </button>

              {/* 8. Recycle Bin Eraser deletion button */}
              <button
                onClick={() => {
                  if (selectedAnnotation.isLocked) return;
                  onDeleteAnnotation(selectedAnnotation.id);
                  onSelectAnnotation(null);
                }}
                disabled={selectedAnnotation.isLocked}
                className="p-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg cursor-pointer transition-colors border border-rose-500 disabled:opacity-30 disabled:pointer-events-none"
                title="Xóa đối tượng"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>

            </div>

            {/* Hint tip for better discoverability */}
            <p className="text-[10px] text-slate-500 font-medium bg-slate-950/80 backdrop-blur px-2.5 py-1 rounded-full shadow border border-slate-800">
              💡 {selectedAnnotation.isLocked ? "Ấn 'Mở khóa' để sửa đổi hoặc kéo thả đối tượng" : "Sử dụng phím Backspace / Delete để xóa nhanh vật thể đang chọn"}
            </p>
          </div>
        )}

        {/* MIRO-STYLE EXUCTIVE LEFT VERTICAL FLOATING TOOLBAR */}
        {floorPlans.length > 0 && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 z-40 flex flex-col gap-2 items-center pointer-events-none select-none">
            {/* The primary vertical bar */}
            <div className="p-2 bg-slate-900 border border-slate-850 rounded-2xl flex flex-col gap-2 shadow-2xl pointer-events-auto no-pan-trigger">
              
              {/* Tool 1: Select (Pointer) */}
              <button
                onClick={() => {
                  setActiveWhiteboardTool('select');
                  onSelectMarker(null);
                  onSelectAnnotation(null);
                  setIsShapesFlyoutOpen(false);
                  setIsFrameFlyoutOpen(false);
                }}
                className={`w-10 h-10 rounded-xl transition-all flex items-center justify-center cursor-pointer hover:bg-slate-800 ${
                  activeWhiteboardTool === 'select'
                    ? 'bg-indigo-600 text-white font-bold shadow-lg scale-105'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Công cụ Chọn & Di chuyển (V)"
              >
                <MousePointer className="w-5 h-5" />
              </button>

              <span className="w-6 h-px bg-slate-850"></span>

              {/* Tool 2: Camera Fault / Sticky pin */}
              <div className="relative group/tool flex items-center">
                <button
                  onClick={() => {
                    setActiveWhiteboardTool('marker');
                    setIsShapesFlyoutOpen(false);
                    setIsFrameFlyoutOpen(false);
                  }}
                  className={`w-10 h-10 rounded-xl transition-all flex items-center justify-center cursor-pointer ${
                    activeWhiteboardTool === 'marker'
                      ? 'bg-emerald-500 text-white font-bold shadow-[0_4px_20px_rgba(16,185,129,0.4)] scale-110 ring-2 ring-emerald-400'
                      : 'text-slate-400 hover:text-slate-250 hover:bg-slate-800'
                  }`}
                  title="Ghim lỗi chụp hình & kèm Voice mô tả (Phím tắt C)"
                >
                  <Camera className="w-5 h-5" />
                </button>
                {/* Always-on active indicator next to tool, or hover tooltip description */}
                {activeWhiteboardTool === 'marker' ? (
                  <div className="absolute left-14 bg-[#0f1222] border-2 border-emerald-500 shadow-2xl rounded-2xl py-2 px-3 flex items-center gap-2 whitespace-nowrap z-50 pointer-events-auto">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block animate-pulse shrink-0 ring-4 ring-emerald-500/20" />
                    <div className="flex flex-col text-left">
                      <span className="text-[10px] font-black uppercase text-emerald-400 tracking-wider leading-none">Chế độ ghim hiện trường</span>
                      <span className="text-[11px] font-bold text-slate-100 mt-0.5">Click lên bản vẽ để chèn Ghim Lỗi & Voice Thuyết Minh</span>
                    </div>
                  </div>
                ) : (
                  <div className="absolute left-14 bg-slate-950 border border-slate-850 shadow-xl rounded-xl py-1.5 px-3.5 whitespace-nowrap text-[10px] font-bold text-slate-300 opacity-0 group-hover/tool:opacity-100 transition-opacity duration-200 pointer-events-none z-50 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                    Ghim vị trí lỗi hiện trường + Camera + Voice Ghi Chú (C)
                  </div>
                )}
              </div>

              {/* Tool 3: Sticky Note */}
              <button
                onClick={() => {
                  setActiveWhiteboardTool('sticky');
                  setIsShapesFlyoutOpen(false);
                  setIsFrameFlyoutOpen(false);
                }}
                className={`w-10 h-10 rounded-xl transition-all flex items-center justify-center cursor-pointer hover:bg-slate-800 ${
                  activeWhiteboardTool === 'sticky'
                    ? 'bg-indigo-600 text-white font-bold shadow-lg scale-105'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Dán giấy nhớ (N)"
              >
                <StickyNote className="w-5 h-5 text-amber-400" />
              </button>

              {/* Tool 4: Free text */}
              <button
                onClick={() => {
                  setActiveWhiteboardTool('text');
                  setIsShapesFlyoutOpen(false);
                  setIsFrameFlyoutOpen(false);
                }}
                className={`w-10 h-10 rounded-xl transition-all flex items-center justify-center cursor-pointer hover:bg-slate-800 ${
                  activeWhiteboardTool === 'text'
                    ? 'bg-indigo-600 text-white font-bold shadow-lg scale-105'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Chèn nhãn văn bản (T)"
              >
                <Type className="w-5 h-5" />
              </button>

              <span className="w-6 h-px bg-slate-850"></span>

              {/* Tool 5: Shapes & Lines FLYOUT Trigger */}
              <div className="relative">
                <button
                  onClick={() => {
                    setIsShapesFlyoutOpen(!isShapesFlyoutOpen);
                    setIsFrameFlyoutOpen(false);
                  }}
                  className={`w-10 h-10 rounded-xl transition-all flex items-center justify-center cursor-pointer hover:bg-slate-800 relative ${
                    ['rect', 'ellipse', 'rhombus', 'triangle', 'line', 'elbow-arrow', 'block-arrow', 'diagram'].includes(activeWhiteboardTool)
                      ? 'bg-indigo-600 text-white font-bold shadow-lg scale-105'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Hình vẽ & Khối liên kết Miro (S/Sơ Đồ)"
                >
                  {/* Icon depending on active shape */}
                  {(() => {
                    switch (activeWhiteboardTool) {
                      case 'rect': return <Square className="w-5 h-5" />;
                      case 'ellipse': return <Circle className="w-5 h-5" />;
                      case 'rhombus': return <Diamond className="w-5 h-5" />;
                      case 'triangle': return <Triangle className="w-5 h-5" />;
                      case 'arrow': return <ArrowUpRight className="w-5 h-5" />;
                      case 'line': return (
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <line x1="4" y1="20" x2="20" y2="4" />
                        </svg>
                      );
                      case 'elbow-arrow': return (
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <polyline points="4,20 12,20 12,4 20,4" />
                          <polygon points="17,1 20,4 17,7" fill="currentColor" />
                        </svg>
                      );
                      case 'block-arrow': return (
                        <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <path d="M4 10h10V6l6 6-6 6v-4H4z" fill="currentColor" />
                        </svg>
                      );
                      case 'diagram': return <Boxes className="w-5 h-5" />;
                      default: return <Boxes className="w-5 h-5 text-indigo-400" />;
                    }
                  })()}
                  
                  {/* Indicator small dot */}
                  <span className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-slate-500"></span>
                </button>

                {/* MIRO POPUP FLYOUT MENU SHAPES & CONNECTIONS - STYLED EXACTLY LIKE SCREENSHOT 1 */}
                {isShapesFlyoutOpen && (
                  <div className="absolute left-[52px] top-1/2 -translate-y-1/2 bg-white text-slate-800 border border-slate-200 rounded-3xl w-64 shadow-2xl p-4 flex flex-col gap-1 z-50 pointer-events-auto no-pan-trigger animate-scale-up text-left whitespace-nowrap">
                    
                    {/* SECTION 1: LINES & CONNECTORS */}
                    <div className="px-2 py-1 text-[9.5px] font-black uppercase text-slate-400 tracking-wider">Đường vẽ & Kết nối</div>
                    
                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('line');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'line' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <svg className="w-4 h-4 text-slate-500 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <line x1="4" y1="20" x2="20" y2="4" />
                        </svg>
                        <span>Đường thẳng (Line)</span>
                      </span>
                      <span className="text-[10px] font-mono text-slate-450 bg-slate-100 px-1 rounded font-normal">L</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('arrow');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'arrow' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <ArrowUpRight className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>Mũi tên thẳng (Arrow)</span>
                      </span>
                      <span className="text-[10px] font-mono text-slate-450 bg-slate-100 px-1 rounded font-normal">A</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('elbow-arrow');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'elbow-arrow' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <svg className="w-4 h-4 text-slate-500 shrink-0 shadow-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <polyline points="4,20 12,20 12,4 20,4" />
                          <polygon points="17,1 20,4 17,7" fill="currentColor" />
                        </svg>
                        <span>Mũi tên vuông (Elbow)</span>
                      </span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('block-arrow');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'block-arrow' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <svg className="w-4 h-4 text-slate-500 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <path d="M4 10h10V6l6 6-6 6v-4H4z" fill="currentColor" />
                        </svg>
                        <span>Mũi tên khối (Block Arrow)</span>
                      </span>
                    </button>

                    <hr className="border-slate-100 my-1.5 shrink-0" />

                    {/* SECTION 2: BASIC SHAPES */}
                    <div className="px-2 py-1 text-[9.5px] font-black uppercase text-slate-400 tracking-wider">Hình học cơ bản</div>

                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('rect');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'rect' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <Square className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>Hình chữ nhật / Hộp kỹ thuật</span>
                      </span>
                      <span className="text-[10px] font-mono text-slate-450 bg-slate-100 px-1 rounded font-normal">R</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('ellipse');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'ellipse' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <Circle className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>Hình tròn / Vòng tròn khảo sát</span>
                      </span>
                      <span className="text-[10px] font-mono text-slate-450 bg-slate-100 px-1 rounded font-normal">O</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('rhombus');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'rhombus' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <Diamond className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>Hình thoi (Rhombus)</span>
                      </span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('triangle');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'triangle' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <Triangle className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>Hình tam giác (Triangle)</span>
                      </span>
                    </button>

                    <hr className="border-slate-100 my-1.5 shrink-0" />

                    <div className="px-2 py-1 text-[9.5px] font-black uppercase text-slate-400 tracking-wider">Luồng nghiệp vụ</div>

                    {/* DIAGRAM & PROCESS */}
                    <button
                      onClick={() => {
                        setActiveWhiteboardTool('diagram');
                        setIsShapesFlyoutOpen(false);
                      }}
                      className={`w-full text-xs font-bold px-2 py-1.5 rounded-xl flex items-center justify-between text-left hover:bg-slate-50 transition-colors ${
                        activeWhiteboardTool === 'diagram' ? 'bg-indigo-55/65 text-indigo-600' : 'text-slate-700'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <Boxes className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>Sơ đồ / Subroutine Block</span>
                      </span>
                    </button>

                    {/* Visual Placeholder: More Shapes */}
                    <div className="w-full text-xs font-bold px-2 py-1.5 text-slate-350 cursor-not-allowed flex items-center justify-between select-none">
                      <span className="flex items-center gap-2.5">
                        <Sparkles className="w-4 h-4 text-slate-300 shrink-0" />
                        <span>More shapes...</span>
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                  </div>
                )}
              </div>

              {/* Tool 6: Pen sketching */}
              <button
                onClick={() => {
                  setActiveWhiteboardTool('pen');
                  setIsShapesFlyoutOpen(false);
                  setIsFrameFlyoutOpen(false);
                }}
                className={`w-10 h-10 rounded-xl transition-all flex items-center justify-center cursor-pointer hover:bg-slate-800 ${
                  activeWhiteboardTool === 'pen'
                    ? 'bg-indigo-600 text-white font-bold shadow-lg scale-105'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Bút tự do phác thảo (P)"
              >
                <Paintbrush className="w-5 h-5" />
              </button>

              {/* Tool 7: Frame / Vùng Tool */}
              <div className="relative">
                <button
                  onClick={() => {
                    setIsFrameFlyoutOpen(!isFrameFlyoutOpen);
                    setIsShapesFlyoutOpen(false);
                  }}
                  className={`w-10 h-10 rounded-xl transition-all flex items-center justify-center cursor-pointer hover:bg-slate-800 ${
                    activeWhiteboardTool === 'frame'
                      ? 'bg-indigo-600 text-white font-bold shadow-lg scale-105'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Tạo vùng có đặt tên / Khung chứa Miro (F)"
                >
                  <Frame className="w-5 h-5" />
                </button>

                {/* MIRO-STYLE POPUP FLYOUT FOR FRAME PRESETS */}
                {isFrameFlyoutOpen && (
                  <div className="absolute left-[52px] top-0 bg-slate-900 text-slate-100 border border-slate-800 rounded-3xl w-72 shadow-2xl p-4 flex flex-col gap-3.5 z-55 pointer-events-auto no-pan-trigger animate-scale-up text-left whitespace-nowrap">
                    
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Chọn Kích Thước Vùng</span>
                      <span className="text-[9px] bg-indigo-55/20 text-indigo-400 font-bold px-1.5 py-0.5 rounded-full">Miro Mode</span>
                    </div>

                    {/* 1. Presets grid */}
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { name: 'Tự vẽ', key: 'custom', desc: 'Custom' },
                        { name: 'Khung A4', key: 'A4', desc: 'Dọc/Ngang' },
                        { name: 'Khung Thư', key: 'Letter', desc: 'Letter' },
                        { name: 'Màn hình', key: '16:9', desc: 'Tỉ lệ 16:9' },
                        { name: 'Sơ đồ', key: '4:3', desc: 'Tỉ lệ 4:3' },
                        { name: 'Hình vuông', key: '1:1', desc: 'Sơ đồ khối' },
                        { name: 'Điện thoại', key: 'mobile', desc: 'Mobile' },
                        { name: 'Tablet', key: 'tablet', desc: 'Ipad' },
                        { name: 'Desktop', key: 'desktop', desc: 'Ngang' },
                      ].map(item => (
                        <button
                          key={item.key}
                          onClick={() => handleCreateFrameWithPreset(item.key)}
                          className="flex flex-col items-center justify-center p-2 rounded-2xl bg-slate-850 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/50 transition-all cursor-pointer text-center group active:scale-95"
                        >
                          <div className="w-7 h-7 rounded-lg bg-slate-900 shadow-sm border border-slate-800 flex items-center justify-center text-slate-450 group-hover:text-indigo-400 group-hover:border-indigo-500/40 mb-1 transition-colors">
                            <Frame className="w-3.5 h-3.5" />
                          </div>
                          <span className="text-[10px] font-extrabold text-slate-200 group-hover:text-white leading-tight">{item.name}</span>
                          <span className="text-[8px] text-slate-500 pointer-events-none leading-none mt-0.5">{item.desc}</span>
                        </button>
                      ))}
                    </div>

                    <hr className="border-slate-800 my-0.5" />

                    {/* 2. Extra Templates */}
                    <div className="flex flex-col gap-1 text-left">
                      <button
                        onClick={() => handleCreateFrameWithPreset('slides')}
                        className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-800 hover:text-indigo-400 transition-colors flex items-center justify-between w-full cursor-pointer"
                      >
                        <span className="flex items-center gap-2">
                          🖥️ <span>Khung slide thuyết trình</span>
                        </span>
                        <span className="text-[8px] bg-amber-500/15 text-amber-500 font-extrabold px-1.5 py-0.5 rounded">New Beta</span>
                      </button>
                      
                      <button
                        onClick={() => handleCreateFrameWithPreset('diagram')}
                        className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-800 hover:text-indigo-400 transition-colors flex items-center justify-between w-full cursor-pointer"
                      >
                        <span className="flex items-center gap-2">
                          📊 <span>Khung sơ đồ phân tích</span>
                        </span>
                      </button>
                    </div>

                  </div>
                )}
              </div>
            </div>

            {/* Minor control accessories attached vertically under the Miro toolbar */}
            <div className="p-1 px-1.5 bg-slate-900 border border-slate-850 rounded-xl flex flex-col gap-1 shadow-2xl pointer-events-auto no-pan-trigger">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onUndo();
                }}
                disabled={!canUndo}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 disabled:opacity-30 cursor-pointer transition-all active:scale-95 flex items-center justify-center"
                title="Undo (Ctrl+Z)"
              >
                <Undo2 className="w-4 h-4" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onRedo();
                }}
                disabled={!canRedo}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 disabled:opacity-30 cursor-pointer transition-all active:scale-95 flex items-center justify-center"
                title="Redo (Ctrl+Y)"
              >
                <Redo2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Importer reference element */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* 4. PROFESSIONAL HIGH-FIDELITY SURVEY & CONCEPT REPORT MODAL */}
      {isReportOpen && (
        <div id="survey-concept-report-modal" className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 overflow-y-auto p-4 md:p-8 flex items-start justify-center pointer-events-auto select-text">
          {/* Custom style block to handle clean white CSS when printing */}
          <style dangerouslySetInnerHTML={{ __html: `
            @media print {
              body * {
                visibility: hidden !important;
                background: white !important;
                color: black !important;
              }
              #survey-printable-area, #survey-printable-area * {
                visibility: visible !important;
              }
              #survey-printable-area {
                position: absolute !important;
                left: 0 !important;
                top: 0 !important;
                width: 100% !important;
                background: white !important;
                color: black !important;
                padding: 0 !important;
                margin: 0 !important;
                box-shadow: none !important;
                border: none !important;
              }
              .no-print {
                display: none !important;
              }
            }
          `}} />

          <div className="w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 md:p-8 flex flex-col gap-6 relative animate-scale-up">
            
            {/* Modal Control Actions (no-print) */}
            <div className="no-print flex items-center justify-between border-b border-slate-800 pb-4 shrink-0">
              <div className="flex items-center gap-2">
                <span className="p-1 px-2.5 bg-indigo-500/10 text-indigo-400 rounded-lg text-[10px] font-black uppercase tracking-wider animate-pulse">
                  🖨️ PDF REPORT CREATOR
                </span>
                <h2 className="text-sm font-extrabold text-white">Xem Trước Bản In Báo Cáo Song Song</h2>
              </div>
              
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-350 text-slate-950 font-bold text-xs rounded-xl cursor-pointer shadow-lg transition-all flex items-center gap-2"
                >
                  <span>In Báo Cáo / Xuất PDF 🎴</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsReportOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold text-xs rounded-xl cursor-pointer transition-all border border-slate-700"
                >
                  Đóng Lại
                </button>
              </div>
            </div>

            {/* Printable Area Wrapper */}
            <div id="survey-printable-area" className="bg-white text-slate-900 p-8 md:p-12 rounded-2xl shadow-xl font-sans leading-relaxed border border-slate-200">
              
              {/* Document Header */}
              <div className="flex flex-col md:flex-row md:items-start justify-between border-b-4 border-slate-900 pb-6 mb-8 gap-6">
                <div>
                  <h1 className="text-xl font-black tracking-tight text-slate-950 uppercase select-none">
                    ĐÀO QUỐC HUY ARCHITECTS & ASSOCIATES
                  </h1>
                  <p className="text-[10px] font-mono font-bold tracking-widest text-slate-500 uppercase mt-1">
                    DQH DESIGN STUDIO • HỆ THỐNG GIÁM SÁT THỰC ĐỊA & PHẢN BIỆN DESIGN CONCEPT
                  </p>
                  <p className="text-xs text-slate-500 mt-2 font-medium">
                    Địa chỉ văn phòng: Tòa nhà D_QH, Quận 1, TP. HCM • Hotline: (+84) DESIGN-FLOW
                  </p>
                </div>
                <div className="text-left md:text-right md:min-w-[200px]">
                  <span className="text-[10px] bg-slate-100 text-slate-800 border border-slate-200 font-black px-2.5 py-1 rounded-md block w-fit md:ml-auto">
                    MÃ PHIẾU: D_QH-{floorPlan ? floorPlan.id.substring(0,6).toUpperCase() : 'SURVEY'}
                  </span>
                  <p className="text-xs font-bold text-slate-900 mt-3">Ngày lập: {new Date().toLocaleDateString('vi-VN')}</p>
                  <p className="text-[11px] text-slate-500 mt-1">Nguồn: Whiteboard D_QH Collaborative Space</p>
                </div>
              </div>

              {/* Title Section */}
              <div className="text-center mb-10 max-w-2xl mx-auto">
                <h2 className="text-lg md:text-xl font-black text-slate-950 tracking-tight uppercase leading-tight">
                  BÁO CÁO SONG SONG KHẢO SÁT HIỆN TRẠNG & BIỆN PHÁP Ý TƯỞNG THIẾT KẾ CHUYÊN SÂU
                </h2>
                <div className="h-1.5 w-16 bg-indigo-600 mx-auto my-3 rounded-full"></div>
                <p className="text-xs text-slate-500 font-medium">
                  Trực quan hóa sự tương hợp trực tiếp giữa hiện trạng sai hỏng thực tế tại công trình và layout đề xuất cải tạo thiết kế từ Team Kiến trúc sư ĐQH Architects
                </p>
              </div>

              {/* Meta brief boxes */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8 bg-slate-50 border border-slate-200/80 rounded-2xl p-4.5">
                <div>
                  <span className="text-[10px] font-mono tracking-wider text-slate-400 block uppercase">Hồ sơ thiết bản vẽ:</span>
                  <span className="text-xs font-bold text-slate-900 mt-0.5 block">{floorPlan ? floorPlan.name : 'Chưa có'}</span>
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-wider text-slate-400 block uppercase">Tổng số điểm ghim:</span>
                  <span className="text-xs font-bold text-slate-900 mt-0.5 block">{activePlanMarkers.length} vị trí kỹ thuật</span>
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-wider text-slate-400 block uppercase">Trạng thái hồ sơ:</span>
                  <span className="text-xs font-bold text-emerald-700 mt-0.5 block">✓ Đang đối sánh & Trình duyệt</span>
                </div>
              </div>

              {/* MAIN CONTENT LISTING (Parallel rows) */}
              <div className="flex flex-col gap-10">
                {activePlanMarkers.map((marker, mIdx) => (
                  <div key={marker.id} className="border-2 border-slate-200/80 rounded-2xl overflow-hidden shadow-sm page-break-inside-avoid">
                    
                    {/* Row Header Banner */}
                    <div className="bg-slate-100 border-b border-slate-200 p-3.5 flex flex-wrap items-center justify-between gap-2.5">
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-6 rounded-full bg-slate-950 text-white font-mono text-xs font-bold flex items-center justify-center">
                          {mIdx + 1}
                        </span>
                        <div>
                          <h4 className="text-xs font-black text-slate-950">{marker.title}</h4>
                          <span className="text-[9.5px] text-slate-500 font-mono">Tọa độ ghim trên mặt bằng thiết kế: X: {Math.round(marker.x)}%, Y: {Math.round(marker.y)}%</span>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono font-bold tracking-wider text-slate-500 uppercase bg-white border border-slate-200/80 px-2 py-0.5 rounded">
                        ĐIỂM KHẢO SÁT CHUYÊN BIỆT
                      </span>
                    </div>

                    {/* Table-like Side-by-Side Dual Grid columns */}
                    <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200">
                      
                      {/* Left Column: Field conditions */}
                      <div className="p-4 flex flex-col gap-3.5 bg-slate-50/30">
                        <span className="text-[10px] tracking-wide uppercase font-extrabold text-emerald-755 flex items-center gap-1 border-b border-slate-200 pb-1.5">
                          📸 PHẦN I: KHẢO SÁT HIỆN TRẠNG thực tế tại hiện trường
                        </span>
                        
                        {/* Survey Image */}
                        {marker.photoData ? (
                          <div className="rounded-xl overflow-hidden border border-slate-200 bg-white max-w-sm mx-auto shadow-xs">
                            <img 
                              src={marker.photoData} 
                              alt="Khảo sát hiện trạng" 
                              className="w-full max-h-[170px] object-cover block"
                              referrerPolicy="no-referrer"
                            />
                            <div className="bg-slate-50 text-[9px] text-slate-500 font-medium px-2 py-1 text-center border-t border-slate-100">
                              Ảnh hiện trường thu thập trực tiếp
                            </div>
                          </div>
                        ) : (
                          <div className="h-[100px] border border-slate-200 border-dashed rounded-xl flex items-center justify-center p-3 text-center bg-slate-50">
                            <span className="text-slate-400 text-xs italic">Không đính kèm tệp ảnh khảo sát hiện trạng</span>
                          </div>
                        )}

                        {/* Transcription */}
                        {marker.transcription && (
                          <div className="bg-emerald-50/20 border-l-2 border-emerald-500 rounded p-2.5">
                            <span className="text-[9px] font-black uppercase text-slate-400 block mb-0.5">Bản dịch Thuyết Minh thoại hiện trường:</span>
                            <p className="text-[11px] italic text-slate-800 leading-relaxed font-sans font-medium">"{marker.transcription}"</p>
                          </div>
                        )}

                        {/* Text note description */}
                        <div className="text-xs text-slate-700 bg-white border border-slate-150 rounded-xl p-3 shadow-xs">
                          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Mô tả bổ túc kỹ thuật thực địa:</span>
                          {marker.textNotes ? (
                            <p className="font-sans whitespace-pre-wrap leading-relaxed">{marker.textNotes}</p>
                          ) : (
                            <p className="text-slate-400 italic">Kiến trúc sư chưa bổ sung mô tả khảo sát.</p>
                          )}
                        </div>
                      </div>

                      {/* Right Column: Concept Solutions */}
                      <div className="p-4 flex flex-col gap-3.5">
                        <span className="text-[10px] tracking-wide uppercase font-extrabold text-indigo-755 flex items-center gap-1 border-b border-slate-200 pb-1.5">
                          💡 PHẦN II: BIỆN PHÁP Ý tưởng & Giải Pháp (DQH Design Reference)
                        </span>

                        {/* Concept Design Image */}
                        {marker.conceptPhotoData ? (
                          <div className="rounded-xl overflow-hidden border border-slate-200 bg-white max-w-sm mx-auto shadow-xs animate-fade-in">
                            <img 
                              src={marker.conceptPhotoData} 
                              alt="Ý tưởng thiết kế" 
                              className="w-full max-h-[170px] object-cover block"
                              referrerPolicy="no-referrer"
                            />
                            <div className="bg-indigo-50 text-[9px] text-indigo-700 font-medium px-2 py-1 text-center border-t border-slate-100">
                              Ý tưởng đề xuất / Render Concept / Catalog tệp mẫu
                            </div>
                          </div>
                        ) : (
                          <div className="h-[100px] border border-slate-200 border-dashed rounded-xl flex items-center justify-center p-3 text-center bg-slate-50">
                            <span className="text-slate-400 text-xs italic">Không đính kèm minh họa Concept cải tạo</span>
                          </div>
                        )}

                        {/* Concept notes text desc */}
                        <div className="text-xs text-slate-700 bg-indigo-50/15 border border-indigo-100 rounded-xl p-3 shadow-xs">
                          <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-wider block mb-1">Thuyết minh giải pháp kiến trúc đề xuất:</span>
                          {marker.conceptNotes ? (
                            <p className="font-sans text-slate-900 whitespace-pre-wrap leading-relaxed">{marker.conceptNotes}</p>
                          ) : (
                            <p className="text-slate-400 italic">Kiến trúc sư chưa bổ sung thuyết minh concept.</p>
                          )}
                        </div>
                      </div>

                    </div>
                  </div>
                ))}
              </div>

              {/* Signature bottom blocks for legal design handoffs */}
              <div className="border-t-2 border-slate-350 mt-12 pt-8 grid grid-cols-2 gap-12 page-break-inside-avoid">
                <div className="text-center">
                  <span className="text-[11px] font-medium text-slate-500 uppercase tracking-widest block">CHỦ ĐẦU TƯ / BAN QUẢN LÝ DỰ ÁN</span>
                  <span className="text-[10px] italic text-slate-400 block mt-1">(Ký, ghi rõ họ tên và đóng dấu duyệt giải pháp)</span>
                  <div className="h-20"></div>
                  <span className="h-px bg-slate-200 w-32 block mx-auto"></span>
                </div>
                <div className="text-center">
                  <span className="text-[11px] font-medium text-slate-500 uppercase tracking-widest block">ĐẠI DIỆN ĐƠN VỊ TƯ VẤN THIẾT KẾ</span>
                  <span className="text-[10px] italic text-slate-400 block mt-1">DQH Architects & Associates</span>
                  <div className="h-20"></div>
                  <span className="h-px bg-slate-200 w-32 block mx-auto"></span>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
}
