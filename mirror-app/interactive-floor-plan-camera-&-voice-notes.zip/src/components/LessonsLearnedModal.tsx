import { useState } from 'react';
import { 
  X, Search, BookOpen, Clock, AlertTriangle, Check, CheckCircle2, 
  Trash2, FileText, ChevronRight, Filter, Info, Award, HelpCircle, 
  Sparkles, FolderArchive, ArrowRight, CornerDownRight, CheckSquare, Settings
} from 'lucide-react';
import { FloorPlan, MarkerNote, WhiteboardAnnotation } from '../types';

// Pre-seeded database for 10 simulated projects with lessons learned and defect historical markers
export interface DemoProject {
  id: string;
  name: string;
  client: string;
  status: 'active' | 'archived'; // Active (đang chạy) vs Archived (hoàn thành rút bài học)
  address: string;
  leader: string;
  completionDate?: string;
  defects: {
    title: string;
    location: string;
    transcription: string; // Voice notes
    textNotes: string; // Solution details
    tags: string[];
    severity: 'High' | 'Medium' | 'Low';
    comments: { user: string; role: string; text: string }[];
  }[];
}

const INITIAL_DEMO_PROJECTS: DemoProject[] = [
  {
    id: "proj-1",
    name: "Căn hộ 3PN Estella Heights Q2",
    client: "Anh Minh Tuấn",
    status: "archived",
    address: "Xa lộ Hà Nội, An Phú, Quận 2, TPHCM",
    leader: "KTS. Võ Ngọc Quang",
    completionDate: "15/12/2025",
    defects: [
      {
        title: "Nứt rạn chân chim mối nối vách thạch cao và cột bê tông",
        location: "Khu vực giao sảnh phụ",
        transcription: "Phát hiện vết nứt chân chim kéo dài 1m5 tại dải giao nhau giữa tường thạch cao hệ thống phụ và cột bê tông chịu lực phòng khách.",
        textNotes: "Nguyên nhân do không đóng lưới thép mắt cáo chống nứt hoặc dán băng thủy tinh chống co giãn nhiệt trước khi bả matit hoàn thiện sơn nước.",
        tags: ["Vách", "Thạch cao", "Bả matit", "Sơn nước"],
        severity: "Medium",
        comments: [
          { user: "Thắng", role: "Quản Lý", text: "Sau này nghiêm cấm bả dải thạch cao giáp cột bê tông mà không sấp lưới keo búa thạch cao chịu ẩm." },
          { user: "Quang", role: "Admin", text: "Đã cho dán băng lưới thủy tinh cường lực và xả bả trét bột mastic mịn xoa bóng lại." }
        ]
      }
    ]
  },
  {
    id: "proj-2",
    name: "Penthouse Serenity Sky Villas",
    client: "Chị Thảo Vy",
    status: "archived",
    address: "Điện Biên Phủ, Võ Thị Sáu, Quận 3, TPHCM",
    leader: "KTS. Thắng Nguyễn",
    completionDate: "10/01/2026",
    defects: [
      {
        title: "Rò rỉ nước ngưng âm trần thạch cao quạt thông gió FCU",
        location: "Phòng ngủ Master tầng lửng",
        transcription: "Nước ngưng tủ điều hòa ẩm mốc thạch cao góc tủ áo quần, nhỏ giọt đều đặn xuống sàn gỗ phía dưới làm đổi màu rộp sàn gỗ nhẹ.",
        textNotes: "Ống đồng thoát nước xả ngược dốc do ty treo ống treo bị võng trùng ở giữa. Khay xả quat FCU bị bít rác bẩn keo bảo ôn.",
        tags: ["Sàn", "Trần", "FCU", "Nước", "Rò rỉ"],
        severity: "High",
        comments: [
          { user: "Thắng", role: "Quản Lý", text: "Bắt buộc thầu phụ cơ điện chỉnh dốc tối thiểu 1.5% hướng phễu thoát, quấn bảo ôn Superlon kín khít khớp nối." },
          { user: "Vy", role: "Thiết kế", text: "Đã nghiệm thu nâng dốc ty treo và xử lý bảo ôn lại hoàn chỉnh." }
        ]
      }
    ]
  },
  {
    id: "proj-3",
    name: "Biệt thự Chateau Phú Mỹ Hưng",
    client: "Bác Sĩ Nguyễn Hoàng",
    status: "archived",
    address: "Khu biệt thự lâu đài Chateau, Quận 7, TPHCM",
    leader: "KTS. Mụi Ngô",
    completionDate: "28/02/2026",
    defects: [
      {
        title: "Thấm rỉ nước chân vách kính phòng tắm đứng Master",
        location: "Phòng Master tắm đứng",
        transcription: "Nước từ vòi tắm đứng thẩm thấu luồn qua kẹp định vị vách kính, rỉ lan rộng ra mặt đá lát ngoài phòng ngủ sồi.",
        textNotes: "Không lắp đặt gờ đá tự nhiên chặn nước chênh cao 3-5cm hoặc không dán keo sủi silicone axit chịu môi trường ẩm mặn đáy vách kính chân đứng.",
        tags: ["Sàn", "Vách", "Thủy tinh", "Thấm", "Apollo"],
        severity: "High",
        comments: [
          { user: "Mụi Ngô", role: "Quản Lý Thiết Kế", text: "Rút kinh nghiệm sâu sắc cho Chateau: Tất cả phòng tắm kính phải có gờ đá sẫm chặn nước cao hơn phòng tắm khô 25mm." },
          { user: "MInh", role: "Thiết kế", text: "Đã cắt đá bổ sung và bơm dán keo Apollo chống sương trắng." }
        ]
      }
    ]
  },
  {
    id: "proj-4",
    name: "Villa Sân vườn Thảo Điền",
    client: "Mr. Johnathan Smith",
    status: "active",
    address: "Nguyễn Văn Hưởng, Thảo Điền, Quận 2, TPHCM",
    leader: "KTS. Vy Nguyễn",
    defects: [
      {
        title: "Nứt vỡ nhiệt vách kính cường lực hông nhà ngoài trời",
        location: "Kính mặt dựng phía Tây",
        transcription: "Kính hộp mặt thoáng cường lực nứt vỡ rạn góc dưới bên trái sau đợt nắng nóng đỉnh điểm chiếu rọi trực tiếp cả ngày.",
        textNotes: "Nẹp sập nhôm quá khít không có biên độ thở nco giãn nở cho tấm kính lớn, gioăng cao su bọt biển bị nén quá chết.",
        tags: ["Vách", "Thủy tinh", "Nứt kính", "Gioăng"],
        severity: "High",
        comments: [
          { user: "Vy", role: "Thiết kế", text: "Cần đổi sang gioăng cao su EPDM đàn hồi tốt hơn và chừa hở rìa sập tối thiểu 5-6mm nạp keo trám nở mút." }
        ]
      }
    ]
  },
  {
    id: "proj-5",
    name: "Căn hộ Duplex Vista Verde Q2",
    client: "Chị Mai Phương",
    status: "archived",
    address: "Đồng Văn Cống, Thạnh Mỹ Lợi, Quận 2, TPHCM",
    leader: "KTS. Khoa Nguyễn",
    completionDate: "20/03/2026",
    defects: [
      {
        title: "Thấm rột sàn ban công lội nước ngược qua cửa kính lùa",
        location: "Ban công phòng khách",
        transcription: "Cơn dông lớn rác lá cây bịt kín lấp máng thoát phễu thu sàn ban công, nước dâng tràn lên cốt khuôn cửa sổ lùa ngập hết sàn gỗ trong phòng.",
        textNotes: "Cốt sàn ban công ban đầu đổ quá cao, chênh lệch cao độ so với sàn trong nhà chỉ dưới 1cm không bảo đảm an toàn khi bão ngập phễu.",
        tags: ["Sàn", "Thấm", "Phễu thu", "Cốt cửa lùa"],
        severity: "High",
        comments: [
          { user: "Thắng", role: "Quản Lý", text: "Tiêu chuẩn DQH: Cốt sàn ban công sảnh thô đổ âm móng ít nhất 50mm so với trong phòng và lắp phễu phồng thoát rác." },
          { user: "Khoa", role: "Thiết kế", text: "Đã đục vợi bớt lớp cán nền, dán chống thấm và tạo rãnh tràn dự phòng lệch mạn mép hiên." }
        ]
      }
    ]
  },
  {
    id: "proj-6",
    name: "Shophouse Sala Đại Quang Minh",
    client: "Anh Trọng Nghĩa",
    status: "active",
    address: "Mai Chí Thọ, Thủ Thiêm, Quận 2, TPHCM",
    leader: "KS. Trung Nguyễn",
    defects: [
      {
        title: "Lệch tim đấu nối đầu phun chữa cháy Spinkler trần thạch cao",
        location: "Trần thạch cao tầng trệt cửa hàng",
        transcription: "Đầu phun chữa cháy Spinkler bị lệch 15cm so với tim trục lưới cốt ô vuông trần thạch cao hoàn thiện tháo nắp xương định dạng.",
        textNotes: "Đơn vị cứu hỏa thi công đường ống ống sắt cố định cứng trước khi đơn vị decor hoàn thiện đóng khung xương trần.",
        tags: ["Trần", "Đầu phun", "Thạch cao", "Cứu hỏa"],
        severity: "Medium",
        comments: [
          { user: "trung test", role: "giam sat", text: "Cần yêu cầu chuyển từ ống kẽm cứng sang đấu nối ống mềm Inox bọc bảo bối dải uốn lượn dễ điều chỉnh tim." }
        ]
      }
    ]
  },
  {
    id: "proj-7",
    name: "Villa Rivera Thảo Điền Q2",
    client: "Anh Quốc Bảo",
    status: "archived",
    address: "Đường số 9, Thảo Điền, Quận 2, TPHCM",
    leader: "KTS. Võ Ngọc Quang",
    completionDate: "05/04/2026",
    defects: [
      {
        title: "Sàn gỗ sồi tự nhiên bị trương nở nén ép phồng rộp",
        location: "Khu sảnh thông tầng phòng khách biệt thự",
        transcription: "Sàn gỗ tự nhiên xuất hiện gồ gợn sóng phồng hẳn lên mặt sau vài tuần chịu ảnh hưởng của nồm ẩm cao.",
        textNotes: "Kỹ thuật của tổ thầu phụ lát khít chặt sát mép vách chân tường không chừa đủ khoảng hở giãn nở nhiệt cho gỗ tấm nở.",
        tags: ["Sàn", "Gỗ", "Phồng sàn", "Khe co giãn"],
        severity: "High",
        comments: [
          { user: "Quang", role: "Admin", text: "Đã chỉ đạo thợ tháo nẹp chân len, xẻ gỗ xén vát đi 12mm quanh chu vi tường để gỗ tự do co rút." },
          { user: "Thắng", role: "Quản Lý", text: "Bài học kinh nghiệm: Lắp sàn gỗ tự nhiên bắt buộc giữ khoảng thở từ 12-15mm che bởi nẹp rầm phào." }
        ]
      }
    ]
  },
  {
    id: "proj-8",
    name: "Căn hộ Studio Vinhomes Golden River",
    client: "Chị Phương Trinh",
    status: "active",
    address: "Tôn Đức Thắng, Bến Nghé, Quận 1, TPHCM",
    leader: "KTS. Vy Nguyễn",
    defects: [
      {
        title: "Nhảy Aptomat bảo vệ quá tải nhánh tủ bếp chính ngẫu nhiên",
        location: "Góc tủ bếp bếp từ & lò nướng",
        transcription: "Aptomat nhánh ngắt nhảy sập liên tục khi người dùng đun bếp từ đồng thời nướng sấy lò vi sóng âm kệ tủ bếp.",
        textNotes: "Dây dẫn tiết diện nhánh chính kéo dây Cadivi 2.5mm2 không đủ công suất chịu nhiệt ấm lên gây sụt ampe tải, Aptomat 20A quá bé.",
        tags: ["Hệ thống điện", "Aptomat", "Quá tải", "Tủ bếp"],
        severity: "High",
        comments: [
          { user: "Vy", role: "Thiết kế", text: "Cần đi lại tuyến dây trục riêng bếp Cadivi 4.0mm2 và cụm át bảo vệ 32A độc lập để tránh cháy nổ ẩm hóc." }
        ]
      }
    ]
  },
  {
    id: "proj-9",
    name: "Nhà phố phố Khang Điền Q9",
    client: "Chú Hữu Phước",
    status: "active",
    address: "Liên Phường, Phú Hữu, Quận 9, TPHCM",
    leader: "KS. Trung Nguyễn",
    defects: [
      {
        title: "Bản lề vách kính kẹp tắm ngoài ban công bị rỉ sét loang ố",
        location: "Phòng ngủ tầng hai ban công mở",
        transcription: "Các kẹp định vị kính và vít lề inox bị phủ một lớp gỉ sét ố vàng đỏ sẫm mạ đen trông cực kỳ mất mỹ quan dự án.",
        textNotes: "Phía thầu lắp ráp vật liệu dùng inox rẻ SUS 201 không kháng nước muối sương thay vì dùng Inox SUS 304 nguyên khối hoặc 316 kháng muối biển.",
        tags: ["Vách", "Vít lề", "Rỉ sét", "Inox 316"],
        severity: "Medium",
        comments: [
          { user: "trung test", role: "giam sat", text: "Yêu cầu đo độ nhiễm mặn và thu tháo thay thế 100% bằng kẹp đồng mạ crom hoặc Inox SUS 316 tinh xảo sọc xước." }
        ]
      }
    ]
  },
  {
    id: "proj-10",
    name: "Office Studio DQH Architects",
    client: "Nội Bộ DQH",
    status: "archived",
    address: "Trần Não, An Khánh, Quận 2, TPHCM",
    leader: "KTS. Thắng Nguyễn",
    completionDate: "30/04/2026",
    defects: [
      {
        title: "Lộ vết giáp nối thấu quang vách thạch cao đèn hắt khe LED",
        location: "Phòng họp lớn",
        transcription: "Bật dải khe đèn led hắt sát vách thấy sọc bóng gồ ghề trồi lún rõ rệt tại sọc mí nối giữa các tấm thạch cao phẳng.",
        textNotes: "Do thợ sơn trét không xả bột xi măng phẳng nhám mịn hoặc không dùng đèn cao áp rọi song song mặt tường rà soát khuyết tật trước sơn lót.",
        tags: ["Vách", "Led hắt khe", "Thạch cao", "Mí nối"],
        severity: "Low",
        comments: [
          { user: "Thắng", role: "Quản Lý", text: "Xây dựng quy chuẩn buộc thầu sơn bả phải rọi đèn trợ giúp vách xả nhám mịn, bọc máng tản mica led tản sáng đều." },
          { user: "Quang", role: "Admin", text: "Đã dặm bả nhám tinh xảo lại toàn bộ các tuyến khe hắt chéo, nghiệm thu phẳng bóng 100%." }
        ]
      }
    ]
  }
];

interface LessonsLearnedModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportMockBluePrint: (planName: string, defects: any[], planId: string) => void;
}

export default function LessonsLearnedModal({ isOpen, onClose, onImportMockBluePrint }: LessonsLearnedModalProps) {
  const [activeTab, setActiveTab] = useState<'projects' | 'search'>('projects');
  const [projectsList, setProjectsList] = useState<DemoProject[]>(INITIAL_DEMO_PROJECTS);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  if (!isOpen) return null;

  // Manage archiving toggles
  const toggleProjectStatus = (id: string) => {
    setProjectsList(prev => prev.map(p => {
      if (p.id === id) {
        const nextStatus = p.status === 'active' ? 'archived' : 'active';
        return { 
          ...p, 
          status: nextStatus,
          completionDate: nextStatus === 'archived' ? new Date().toLocaleDateString('vi-VN') : undefined
        };
      }
      return p;
    }));
  };

  // Extract all unique tags list across pre-seeded projects
  const allTags = Array.from(
    new Set(
      projectsList.flatMap(p => p.defects.flatMap(d => d.tags))
    )
  );

  // Filter defects from active AND archived projects with search querying
  const searchResults = projectsList.flatMap(proj => {
    return proj.defects
      .filter(defect => {
        // Search matches query keyword inside title, transcription, textNotes, or tags
        const q = searchQuery.toLowerCase();
        const matchesQuery = !searchQuery || 
          defect.title.toLowerCase().includes(q) ||
          defect.transcription.toLowerCase().includes(q) ||
          defect.textNotes.toLowerCase().includes(q) ||
          defect.tags.some(t => t.toLowerCase().includes(q));

        // Matches tag filter
        const matchesTag = !selectedTag || defect.tags.includes(selectedTag);

        return matchesQuery && matchesTag;
      })
      .map(defect => ({
        ...defect,
        project: proj
      }));
  });

  const activeCount = projectsList.filter(p => p.status === 'active').length;
  const archivedCount = projectsList.filter(p => p.status === 'archived').length;

  // Convert rich pre-seeded defect schemas dynamically into interactive drawings to explore
  const loadDefectToActiveBoard = (defect: any, project: DemoProject) => {
    onImportMockBluePrint(project.name, project.defects, project.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in select-none">
      <div 
        id="lessons-learned-center-card" 
        className="bg-slate-950 border border-slate-900 w-full max-w-4xl h-[88vh] rounded-3xl flex flex-col overflow-hidden shadow-2xl"
      >
        {/* Header Toolbar Title */}
        <div className="flex items-center justify-between p-5 border-b border-slate-900 bg-slate-950">
          <div className="flex items-center gap-2.5">
            <div className="p-2.2 bg-amber-500/15 rounded-xl text-amber-400 border border-amber-500/20">
              <BookOpen className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-black text-white uppercase tracking-wider">Hệ Thống Kho Bài Học Ghi Nhận Lỗi Kỹ Thuật (Toàn Bộ Dự Án Lịch Sử)</h3>
                <span className="text-[8px] font-black bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1.5 rounded uppercase">DQH Lịch Sử Lessons Learned CRM</span>
              </div>
              <p className="text-[10px] text-slate-450 mt-0.5">Kho tra cứu bài học kinh nghiệm từ toàn bộ hàng trăm dự án cũ đã bàn giao qua các năm, độc lập hoàn toàn với 10 dự án thiết kế đang chạy ngoài màn hình chính.</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 bg-slate-900 border border-slate-800 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection Area */}
        <div className="flex items-center gap-1.5 px-6 py-2 bg-slate-900/40 border-b border-slate-900">
          <button
            onClick={() => setActiveTab('projects')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'projects'
                ? 'bg-slate-800/80 text-white border border-slate-700/50 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            <span>Danh mục Toàn bộ dự án đã lưu trữ ({projectsList.length})</span>
            <span className="text-[9px] bg-amber-500/10 text-amber-400 px-1.5 py-0.5 rounded-md font-mono font-bold">KHO LƯU TRỮ LỊCH SỬ</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('search');
              setSelectedTag(null);
              setSearchQuery('');
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'search'
                ? 'bg-slate-800/80 text-white border border-slate-700/50 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Search className="w-3.5 h-3.5 text-amber-400" />
            <span>Tra cứu theo từ khóa lỗi (Vách, Sàn, Thạch Cao...)</span>
            <span className="text-[9px] bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded-md font-mono font-bold animate-pulse">HOT: NHẤP "VÁCH" HOẶC "SÀN"</span>
          </button>
        </div>

        {/* Main Content scrollable panel */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-950 flex flex-col gap-5">
          
          {/* TAB 1: 10 PROJECTS MANAGEMENT */}
          {activeTab === 'projects' && (
            <div className="flex flex-col gap-4">
              
              {/* Quick info banner */}
              <div className="bg-gradient-to-r from-blue-500/5 to-indigo-500/5 border border-indigo-500/15 rounded-2xl p-4 flex items-start gap-3">
                <Info className="w-4.5 h-4.5 text-indigo-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-450 leading-relaxed">
                  Trực thuộc <span className="text-amber-400 font-bold">thư viện kỹ thuật số bài học thất bại</span> của DQH. Các dự án lịch sử dưới đây đã hoàn tất bóc tách lỗi, khảo sát hiện trạng nứt dầm vách gạch gỗ, và lưu trữ sẵn sàng. Bạn có thể nhấn ghim bài học để trích lục trực tiếp tiêu bản này lên khung vẽ whiteboard tương tác bất cứ lúc nào!
                </div>
              </div>

              {/* Projects Grid Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projectsList.map((proj, index) => (
                  <div 
                    key={proj.id} 
                    className={`p-4 rounded-2xl border transition-all ${
                      proj.status === 'archived'
                        ? 'bg-slate-900/30 border-amber-500/20 hover:border-amber-500/40'
                        : 'bg-slate-900/60 border-slate-900 hover:border-indigo-500/30'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-1.5">
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-mono text-slate-500 font-bold">DỰ ÁN #{index + 1}</span>
                          {proj.status === 'archived' ? (
                            <span className="text-[8px] bg-amber-500/15 text-amber-400 border border-amber-500/30 px-1.5 py-0.5 rounded-md font-extrabold flex items-center gap-0.5">
                              <Award className="w-2.5 h-2.5" />
                              LƯU TRỮ HỌC LIỆU
                            </span>
                          ) : (
                            <span className="text-[8px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded-md font-extrabold">
                              ĐANG THI CÔNG
                            </span>
                          )}
                        </div>
                        <h4 className="text-xs font-black text-slate-100 mt-1.5 truncate leading-tight">{proj.name}</h4>
                        <p className="text-[10px] text-slate-400 font-mono mt-1">Đại diện: {proj.client}</p>
                      </div>

                      {/* Power toggler handle action button */}
                      <button
                        onClick={() => toggleProjectStatus(proj.id)}
                        className={`px-2.5 py-1.5 rounded-xl text-[9px] font-extrabold tracking-wider uppercase border cursor-pointer shrink-0 transition-colors ${
                          proj.status === 'archived'
                            ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20 hover:bg-indigo-500/20'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20'
                        }`}
                        title={proj.status === 'archived' ? "Mở khóa dự án để tiếp tục vẽ sửa" : "Hoàn thành và đưa vào kho kinh nghiệm"}
                      >
                        {proj.status === 'archived' ? '⚡ Phục hồi chạy' : '📁 Lưu Trữ Lỗi'}
                      </button>
                    </div>

                    <div className="mt-3 text-[10px] text-slate-450 border-t border-slate-900 pt-3 flex flex-col gap-1 gap-y-1.5">
                      <p><span className="text-slate-500 font-bold">Vị trí:</span> {proj.address}</p>
                      <p><span className="text-slate-500 font-bold">KTS Phụ trách:</span> <span className="font-bold text-slate-300">{proj.leader}</span></p>
                      {proj.completionDate && (
                        <p className="text-amber-400/90 font-mono"><span className="text-slate-500 font-bold">Nghiệm thu đóng hồ sơ:</span> {proj.completionDate}</p>
                      )}
                    </div>

                    {/* Pre-seeded Defects Quick Peek Box */}
                    <div className="mt-3 bg-slate-950 p-2.5 rounded-xl border border-slate-900 flex flex-col gap-1.5">
                      <span className="text-[8px] uppercase font-bold text-slate-500 tracking-wider">Lỗi điển hình giựt kinh nghiệm ({proj.defects.length}):</span>
                      {proj.defects.map((def, dIdx) => (
                        <div key={dIdx} className="text-[10px] text-slate-300 flex items-start gap-1">
                          <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0 mt-0.5" />
                          <div className="min-w-0 flex-1">
                            <span className="font-bold text-slate-200">{def.title}</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {def.tags.map(t => (
                                <span key={t} className="text-[8px] bg-slate-900 border border-slate-800 text-slate-400 px-1 py-0.2 rounded font-sans leading-none">{t}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Simulation Load interactive drawing board */}
                    <button
                      onClick={() => loadDefectToActiveBoard(proj.defects[0], proj)}
                      className="w-full mt-3 py-2 bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800 text-[10px] font-black rounded-lg flex items-center justify-center gap-1 cursor-pointer transition-colors"
                    >
                      <span>Mở tương tác Whiteboard bản vẽ này</span>
                      <ChevronRight className="w-3 h-3 text-indigo-400" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: DETAILED DEFECT KNOWLEDGE SEARCH CENTER */}
          {activeTab === 'search' && (
            <div className="flex flex-col gap-4">
              
              {/* Search controller search card */}
              <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-900 flex flex-col gap-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-450 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Nhập từ khóa tìm kiếm (Ví dụ: vách, sàn, thạch cao, thấm, rò rỉ, phồng sàn...)"
                    className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-850 text-xs font-bold text-white rounded-xl placeholder:text-slate-500 focus:border-indigo-500 select-all outline-none"
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3.5 top-3.5 text-slate-400 hover:text-white text-[10px] font-bold"
                    >
                      Xóa
                    </button>
                  )}
                </div>

                {/* Filter tags panel */}
                <div className="flex flex-col gap-1.5">
                  <span className="text-[8px] uppercase font-bold text-indigo-400 tracking-wider">Từ khóa gợi ý thông dụng:</span>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      onClick={() => { setSelectedTag(null); setSearchQuery(''); }}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                        selectedTag === null ? 'bg-indigo-600 text-white' : 'bg-slate-950 border border-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      Tất cả lỗi
                    </button>
                    {allTags.map(tag => (
                      <button
                        key={tag}
                        onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                          selectedTag === tag 
                            ? 'bg-amber-500 text-slate-950 border border-transparent' 
                            : 'bg-slate-950 border border-slate-850 text-slate-300 hover:text-white hover:border-slate-800'
                        }`}
                      >
                        <Filter className="w-2.5 h-2.5 opacity-65" />
                        <span>{tag}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Header stats showing match info */}
              <div className="flex items-center justify-between text-[11px] text-slate-450 px-1 font-mono">
                <span>Phát hiện: <strong className="text-white">{searchResults.length} học liệu lỗi</strong> tương thích</span>
                {selectedTag && <span>Đang lọc nhãn: <strong className="text-amber-400">"{selectedTag}"</strong></span>}
              </div>

              {/* Map rendering search results list */}
              {searchResults.length === 0 ? (
                <div className="bg-slate-900/30 border border-dashed border-slate-900 p-12 rounded-3xl text-center flex flex-col items-center justify-center gap-3">
                  <AlertTriangle className="w-8 h-8 text-amber-500/80 animate-bounce" />
                  <p className="text-xs text-slate-450 leading-relaxed max-w-sm">
                    Không tìm thấy bài học kinh nghiệm nào phù hợp với từ khóa <span className="text-rose-400 font-mono">"{searchQuery}"</span>. Hãy thử tìm các từ khóa liên quan như <strong>vách, sàn, thạch cao, thấm, kính, ống</strong> hoặc xem danh mục 10 dự án phía trên.
                  </p>
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  {searchResults.map((defect, dIdx) => (
                    <div 
                      key={dIdx} 
                      className="bg-slate-900/60 border border-slate-900 p-5 rounded-2xl flex flex-col gap-4 hover:border-slate-800 transition-all"
                    >
                      {/* Badge project source info */}
                      <div className="flex items-center justify-between gap-2.5 flex-wrap border-b border-slate-900 pb-3">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-rose-500" />
                          <h5 className="text-xs font-extrabold text-slate-100">{defect.title}</h5>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-950 font-bold text-slate-300 border border-slate-850">
                            🏢 {defect.project.name}
                          </span>
                          {defect.project.status === 'archived' ? (
                            <span className="text-[8.5px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-md font-bold font-mono">
                              ĐÃ LƯU TRỮ (LESSON LEARNED)
                            </span>
                          ) : (
                            <span className="text-[8.5px] bg-slate-900 text-slate-450 border border-slate-800 px-2 py-0.5 rounded-md font-bold font-mono">
                              ĐANG CO-WORKING
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Voice caption transcription notes */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-slate-950 p-3 rounded-xl border border-slate-900 flex flex-col gap-1.5">
                          <span className="text-[9px] uppercase font-black text-rose-400 flex items-center gap-1">
                            🎙️ THUYẾT MINH GHI ÂM (GIỌNG NÓI):
                          </span>
                          <p className="text-xs text-slate-350 italic leading-relaxed">
                            "{defect.transcription}"
                          </p>
                          <div className="mt-1 text-[9px] font-mono text-slate-500">
                            Khảo sát bởi: {defect.project.leader} tại {defect.location}
                          </div>
                        </div>

                        <div className="bg-slate-950 p-3 rounded-xl border border-slate-900 flex flex-col gap-1.5">
                          <span className="text-[9px] uppercase font-black text-emerald-400 flex items-center gap-1">
                            🛠️ PHÁT ĐỒ / QUY TRÌNH SỬA & RÚT KINH NGHIỆM:
                          </span>
                          <p className="text-xs text-slate-300 leading-relaxed font-sans">
                            {defect.textNotes}
                          </p>
                          <div className="mt-1.5 flex flex-wrap gap-1">
                            {defect.tags.map(t => (
                              <span key={t} className="text-[8.5px] bg-indigo-500/10 text-indigo-400 px-2 py-0.2 rounded font-sans">{t}</span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Collaborative remarks thread */}
                      <div className="bg-slate-950/40 p-3 rounded-xl border border-slate-900/40 flex flex-col gap-2">
                        <span className="text-[8px] uppercase font-bold text-slate-500 tracking-wider">Biên bản thảo luận kỹ thuật của DQH Architects:</span>
                        <div className="flex flex-col gap-1.5">
                          {defect.comments.map((comment, cIdx) => (
                            <div key={cIdx} className="text-[10.5px] text-slate-400 flex items-start gap-1 leading-normal">
                              <span className="font-extrabold text-slate-200">{comment.user} ({comment.role}):</span>
                              <span>{comment.text}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Quick launch interactive whiteboarding button */}
                      <div className="flex items-center justify-between mt-1 text-[10px] text-slate-500">
                        <span>Độ nghiêm trọng: <strong className={defect.severity === 'High' ? 'text-red-400 font-bold' : 'text-slate-400'}>{defect.severity}</strong></span>
                        <button
                          onClick={() => loadDefectToActiveBoard(defect, defect.project)}
                          className="px-3.5 py-1.8 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl cursor-pointer flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
                        >
                          <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                          <span>Xuất bản vẽ này lên Whiteboard</span>
                        </button>
                      </div>

                    </div>
                  ))}
                </div>
              )}

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-900 flex items-center justify-between text-[10px] text-slate-500 font-mono">
          <span>DQH Architects Lessons Learned Knowledge Base</span>
          <span>© 2026 DQH Architects - Đúc kết kinh nghiệm bàn giao dự án</span>
        </div>
      </div>
    </div>
  );
}
