import { FloorPlan, MarkerNote, WhiteboardAnnotation } from '../types';

const DB_NAME = 'FloorPlanInspectorDB_v2';
const PLANS_STORE = 'floor_plans';
const NOTES_STORE = 'marker_notes';
const ANNOT_STORE = 'whiteboard_annotations';

function getDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 2);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(PLANS_STORE)) {
        db.createObjectStore(PLANS_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(NOTES_STORE)) {
        db.createObjectStore(NOTES_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(ANNOT_STORE)) {
        db.createObjectStore(ANNOT_STORE, { keyPath: 'id' });
      }
    };
  });
}

export async function saveFloorPlan(plan: FloorPlan): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([PLANS_STORE], 'readwrite');
    const store = transaction.objectStore(PLANS_STORE);
    const request = store.put(plan);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getFloorPlans(): Promise<FloorPlan[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([PLANS_STORE], 'readonly');
    const store = transaction.objectStore(PLANS_STORE);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

export async function deleteFloorPlan(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([PLANS_STORE, NOTES_STORE, ANNOT_STORE], 'readwrite');
    
    // Delete floor plan
    transaction.objectStore(PLANS_STORE).delete(id);
    
    // Delete all notes associated with this floor plan
    const notesStore = transaction.objectStore(NOTES_STORE);
    const cursorReq = notesStore.openCursor();
    cursorReq.onsuccess = (event) => {
      const cursor = (event.target as IDBRequest<IDBCursorWithValue | null>).result;
      if (cursor) {
        if (cursor.value.floorPlanId === id) {
          cursor.delete();
        }
        cursor.continue();
      }
    };

    // Delete all annotations associated with this floor plan
    const annotStore = transaction.objectStore(ANNOT_STORE);
    const cursorReqAnnot = annotStore.openCursor();
    cursorReqAnnot.onsuccess = (event) => {
      const cursor = (event.target as IDBRequest<IDBCursorWithValue | null>).result;
      if (cursor) {
        if (cursor.value.floorPlanId === id) {
          cursor.delete();
        }
        cursor.continue();
      }
    };

    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
}

export async function saveMarkerNote(note: MarkerNote): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([NOTES_STORE], 'readwrite');
    const store = transaction.objectStore(NOTES_STORE);
    const request = store.put(note);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getMarkerNotes(floorPlanId?: string): Promise<MarkerNote[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([NOTES_STORE], 'readonly');
    const store = transaction.objectStore(NOTES_STORE);
    const request = store.getAll();

    request.onsuccess = () => {
      const allNotes = request.result || [];
      if (floorPlanId) {
        resolve(allNotes.filter(n => n.floorPlanId === floorPlanId));
      } else {
        resolve(allNotes);
      }
    };
    request.onerror = () => reject(request.error);
  });
}

export async function deleteMarkerNote(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([NOTES_STORE], 'readwrite');
    const store = transaction.objectStore(NOTES_STORE);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function saveAnnotation(annot: WhiteboardAnnotation): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([ANNOT_STORE], 'readwrite');
    const store = transaction.objectStore(ANNOT_STORE);
    const request = store.put(annot);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getAnnotations(floorPlanId?: string): Promise<WhiteboardAnnotation[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([ANNOT_STORE], 'readonly');
    const store = transaction.objectStore(ANNOT_STORE);
    const request = store.getAll();

    request.onsuccess = () => {
      const allAnnots = request.result || [];
      if (floorPlanId) {
        resolve(allAnnots.filter(a => a.floorPlanId === floorPlanId));
      } else {
        resolve(allAnnots);
      }
    };
    request.onerror = () => reject(request.error);
  });
}

export async function deleteAnnotation(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([ANNOT_STORE], 'readwrite');
    const store = transaction.objectStore(ANNOT_STORE);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

