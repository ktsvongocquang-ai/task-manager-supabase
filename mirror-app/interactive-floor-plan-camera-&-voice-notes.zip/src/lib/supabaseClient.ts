import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { FloorPlan, MarkerNote, WhiteboardAnnotation } from '../types';

let supabaseInstance: SupabaseClient | null = null;

// Credentials can be loaded dynamically from localStorage so the user can easily
// configure their own Supabase keys in the UI without modifying target code or env!
export interface SupabaseConfig {
  url: string;
  anonKey: string;
}

export function getSupabaseConfig(): SupabaseConfig | null {
  try {
    const stored = localStorage.getItem('dqh_supabase_config');
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Error reading Supabase config', e);
  }
  return null;
}

export function saveSupabaseConfig(config: SupabaseConfig | null) {
  if (config) {
    localStorage.setItem('dqh_supabase_config', JSON.stringify(config));
    supabaseInstance = null; // Reset to force re-initialization
  } else {
    localStorage.removeItem('dqh_supabase_config');
    supabaseInstance = null;
  }
}

export function getSupabaseClient(): SupabaseClient | null {
  if (supabaseInstance) return supabaseInstance;

  const config = getSupabaseConfig();
  const metaEnv = (import.meta as any).env || {};
  const url = config?.url || metaEnv.VITE_SUPABASE_URL || '';
  const anonKey = config?.anonKey || metaEnv.VITE_SUPABASE_ANON_KEY || '';

  if (url && anonKey) {
    try {
      supabaseInstance = createClient(url, anonKey, {
        auth: { persistSession: false }
      });
      return supabaseInstance;
    } catch (e) {
      console.error('Failed to initialize Supabase client:', e);
    }
  }
  return null;
}

/**
 * SQL queries to run inside Supabase SQL Editor for 1-click database initialization
 */
export const SUPABASE_SQL_SETUP = `-- DQH Architects - SQL Tạo Bảng Cơ Sở Dữ Liệu Miễn Phí Trên Supabase
-- Chạy đoạn mã này trong "SQL Editor" tại giao diện quản trị Supabase

-- 1. Bảng Mặt bằng Bản vẽ
CREATE TABLE IF NOT EXISTS floor_plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  image_data TEXT, -- Lưu dạng base64/URL vẽ thiết kế thô
  width REAl DEFAULT 1000,
  height REAL DEFAULT 700,
  project_id TEXT,
  plan_type TEXT,
  created_at BIGINT NOT NULL
);

-- 2. Bảng Điểm Ghim Lỗi Hiện Trường
CREATE TABLE IF NOT EXISTS marker_notes (
  id TEXT PRIMARY KEY,
  floor_plan_id TEXT NOT NULL REFERENCES floor_plans(id) ON DELETE CASCADE,
  x REAL NOT NULL,
  y REAL NOT NULL,
  title TEXT NOT NULL,
  photo_data TEXT, -- Lưu base64 hiện trạng rò rỉ/nứt vỡ
  audio_data TEXT, -- Lưu base64 thuyết minh ghi âm
  transcription TEXT,
  text_notes TEXT,
  comments JSONB DEFAULT '[]'::jsonb,
  tags TEXT[],
  created_at BIGINT NOT NULL
);

-- 3. Bảng Nhãn Nhớ/Hình Vẽ Whiteboard (Hỗ trợ cộng tác kiểu Miro)
CREATE TABLE IF NOT EXISTS whiteboard_annotations (
  id TEXT PRIMARY KEY,
  floor_plan_id TEXT NOT NULL REFERENCES floor_plans(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  x REAL NOT NULL,
  y REAL NOT NULL,
  width REAL,
  height REAL,
  color TEXT,
  content TEXT,
  user_name TEXT,
  comments JSONB DEFAULT '[]'::jsonb,
  created_at BIGINT NOT NULL
);

-- Kích hoạt quyền truy cập công khai không giới hạn ghi nhận (có thể tùy biến chính sách bảo mật RLS sau)
ALTER TABLE floor_plans DISABLE ROW LEVEL SECURITY;
ALTER TABLE marker_notes DISABLE ROW LEVEL SECURITY;
ALTER TABLE whiteboard_annotations DISABLE ROW LEVEL SECURITY;
`;

/**
 * Cloud database sync commands
 */
export async function syncLocalToSupabase(
  plans: FloorPlan[],
  markers: MarkerNote[],
  annots: WhiteboardAnnotation[]
): Promise<{ success: boolean; message: string; count: number }> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, message: 'Supabase không được cấu hình hoặc thiếu API Key hợp lệ.', count: 0 };
  }

  try {
    let syncedCount = 0;

    // 1. Sync plans
    for (const plan of plans) {
      const { error } = await client.from('floor_plans').upsert({
        id: plan.id,
        name: plan.name,
        image_data: plan.imageData || null,
        width: plan.width,
        height: plan.height,
        project_id: plan.projectId || null,
        plan_type: plan.planType || null,
        created_at: plan.createdAt
      });
      if (error) throw error;
      syncedCount++;
    }

    // 2. Sync marker notes
    for (const marker of markers) {
      const { error } = await client.from('marker_notes').upsert({
        id: marker.id,
        floor_plan_id: marker.floorPlanId,
        x: marker.x,
        y: marker.y,
        title: marker.title,
        photo_data: marker.photoData || null,
        audio_data: marker.audioData || null,
        transcription: marker.transcription || null,
        text_notes: marker.textNotes || null,
        comments: marker.comments || [],
        tags: marker.tags || [],
        created_at: marker.createdAt
      });
      if (error) throw error;
      syncedCount++;
    }

    // 3. Sync annotations
    for (const annot of annots) {
      const { error } = await client.from('whiteboard_annotations').upsert({
        id: annot.id,
        floor_plan_id: annot.floorPlanId,
        type: annot.type,
        x: annot.x,
        y: annot.y,
        width: annot.width || null,
        height: annot.height || null,
        color: annot.color || null,
        content: annot.content || '',
        user_name: annot.userName || '',
        comments: annot.comments || [],
        created_at: annot.createdAt
      });
      if (error) throw error;
      syncedCount++;
    }

    return {
      success: true,
      message: `Đồng bộ thành công! Đã đẩy ${syncedCount} bản ghi lên máy chủ Supabase.`,
      count: syncedCount
    };
  } catch (err: any) {
    console.error('Supabase Sync Error:', err);
    return { 
      success: false, 
      message: `Lỗi đồng bộ: ${err.message || err}. Hãy bảo đảm bạn đã tạo đầy đủ các bảng thông qua mã SQL Setup.`, 
      count: 0 
    };
  }
}

/**
 * Direct selective cloud pulling
 */
export async function pullFromSupabase(): Promise<{
  success: boolean;
  plans: FloorPlan[];
  markers: MarkerNote[];
  annots: WhiteboardAnnotation[];
  message: string;
}> {
  const client = getSupabaseClient();
  if (!client) {
    return { success: false, plans: [], markers: [], annots: [], message: 'Supabase chưa được cấu hình.' };
  }

  try {
    // Pull Floor plans
    const { data: plansData, error: plansErr } = await client.from('floor_plans').select('*');
    if (plansErr) throw plansErr;

    // Pull markers
    const { data: markersData, error: markersErr } = await client.from('marker_notes').select('*');
    if (markersErr) throw markersErr;

    // Pull annotations
    const { data: annotsData, error: annotsErr } = await client.from('whiteboard_annotations').select('*');
    if (annotsErr) throw annotsErr;

    // Map back to correct types
    const plans: FloorPlan[] = (plansData || []).map(p => ({
      id: p.id,
      name: p.name,
      imageData: p.image_data,
      width: p.width,
      height: p.height,
      projectId: p.project_id || undefined,
      planType: (p.plan_type as any) || undefined,
      createdAt: Number(p.created_at)
    }));

    const markers: MarkerNote[] = (markersData || []).map(m => ({
      id: m.id,
      floorPlanId: m.floor_plan_id,
      x: m.x,
      y: m.y,
      title: m.title,
      photoData: m.photo_data,
      audioData: m.audio_data,
      transcription: m.transcription,
      textNotes: m.text_notes,
      comments: m.comments || [],
      tags: m.tags || [],
      createdAt: Number(m.created_at)
    }));

    const annots: WhiteboardAnnotation[] = (annotsData || []).map(a => ({
      id: a.id,
      floorPlanId: a.floor_plan_id,
      type: a.type as any,
      x: a.x,
      y: a.y,
      width: a.width,
      height: a.height,
      color: a.color,
      content: a.content,
      userName: a.user_name,
      comments: a.comments || [],
      createdAt: Number(a.created_at)
    }));

    return {
      success: true,
      plans,
      markers,
      annots,
      message: `Tìm thấy ${plans.length} bản vẽ, ${markers.length} điểm ghim lỗi, và ${annots.length} nhãn dán trên đám mây.`
    };

  } catch (err: any) {
    console.error('Supabase pull error:', err);
    return {
      success: false,
      plans: [],
      markers: [],
      annots: [],
      message: `Thao tác tải đám mây thất bại: ${err.message || err}`
    };
  }
}
