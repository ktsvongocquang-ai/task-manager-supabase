import { useState, useEffect, useMemo } from 'react';
import { FloorPlan, MarkerNote, WhiteboardAnnotation, UserRoleProfile, Project } from './types';
import { 
  getFloorPlans, saveFloorPlan, deleteFloorPlan, 
  getMarkerNotes, saveMarkerNote, deleteMarkerNote,
  saveAnnotation, getAnnotations, deleteAnnotation 
} from './lib/db';
import { getDemoFloorPlan, getMockProjectFloorPlan, getFlavorFloorPlan } from './lib/demoPlan';
import { 
  Camera, Mic, Plus, FileText, Trash2, Printer, Download, BookOpen, 
  Map, LayoutDashboard, Share2, Upload, Sparkles, Check, CheckCircle2, 
  ChevronRight, HelpCircle, Users, Layers, Layout, ChevronDown, Cloud, CheckSquare, Settings,
  FolderArchive, Award, Briefcase, FileSignature, CheckSquare2, FileCheck, Layers3, RefreshCw,
  Search, Star, ArrowLeft, ExternalLink, Calendar, Grid, List as ListIcon
} from 'lucide-react';
import CameraModal from './components/CameraModal';
import FloorPlanViewer from './components/FloorPlanViewer';
import MarkerDetailSidebar from './components/MarkerDetailSidebar';
import OpsMapModal from './components/OpsMapModal';
import ShareProjModal from './components/ShareProjModal';
import LessonsLearnedModal from './components/LessonsLearnedModal';


const INITIAL_PROJECTS: Project[] = [
  { id: 'proj-1', name: 'Căn hộ 3PN Estella Heights Q2', client: 'Anh Minh Tuấn', leader: 'KTS. Võ Ngọc Quang', address: 'Xa lộ Hà Nội, An Phú, Quận 2, TPHCM', status: 'active', progress: 75, createdAt: Date.now() - 100000 },
  { id: 'proj-2', name: 'Penthouse Serenity Sky Villas Q3', client: 'Chị Thảo Vy', leader: 'KTS. Thắng Nguyễn', address: 'Điện Biên Phủ, Võ Thị Sáu, Quận 3, TPHCM', status: 'active', progress: 90, createdAt: Date.now() - 90000 },
  { id: 'proj-3', name: 'Biệt Thự Lâu Đài Chateau Q7', client: 'Bác Sĩ Nguyễn Hoàng', leader: 'KTS. Mụi Ngô', address: 'Khu Château, Phú Mỹ Hưng, Q7, TPHCM', status: 'active', progress: 40, createdAt: Date.now() - 80000 },
  { id: 'proj-4', name: 'Villa Sân Vườn Thảo Điền Q2', client: 'Mr. Johnathan Smith', leader: 'KTS. Vy Nguyễn', address: 'Nguyễn Văn Hưởng, Thảo Điền, Q2, TPHCM', status: 'active', progress: 60, createdAt: Date.now() - 70000 },
  { id: 'proj-5', name: 'Duplex Vista Verde Thạnh Mỹ Lợi', client: 'Chị Mai Phương', leader: 'KTS. Khoa Nguyễn', address: 'Đồng Văn Cống, Thạnh Mỹ Lợi, Q2, TPHCM', status: 'active', progress: 85, createdAt: Date.now() - 60000 },
  { id: 'proj-6', name: 'Shophouse Sala Đại Quang Minh', client: 'Anh Trọng Nghĩa', leader: 'KS. Trung Nguyễn', address: 'Mai Chí Thọ, Thủ Thiêm, Q2, TPHCM', status: 'active', progress: 30, createdAt: Date.now() - 50000 },
  { id: 'proj-7', name: 'Biệt Thự Ven Sông Thảo Điền', client: 'Chị Bảo Trân Trần', leader: 'KTS. Vy Nguyễn', address: 'Thảo Điền, Quận 2, TPHCM', status: 'active', progress: 52, createdAt: Date.now() - 40000 },
  { id: 'proj-8', name: 'Studio Vinhomes Golden River Q1', client: 'Anh Quốc Bảo', leader: 'KTS. Minh Nguyễn', address: 'Tôn Đức Thắng, Bến Nghé, Quận 1, TPHCM', status: 'active', progress: 95, createdAt: Date.now() - 30000 },
  { id: 'proj-9', name: 'Nhà Phố Đô Thị Khang Điền Q9', client: 'Chị Thanh Nhàn', leader: 'KTS. Hậu Trần', address: 'Dương Đình Hội, Phú Hữu, Q9, TPHCM', status: 'active', progress: 65, createdAt: Date.now() - 20000 },
  { id: 'proj-10', name: 'Văn Phòng Collab DQH Architects', client: 'DQH Partners', leader: 'KTS. Thắng Admin', address: 'Sông Hành, Thảo Điền, TP. Thủ Đức, TPHCM', status: 'active', progress: 100, createdAt: Date.now() - 10000 }
];


export default function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [floorPlans, setFloorPlans] = useState<FloorPlan[]>([]);
  const [activeFloorPlanId, setActiveFloorPlanId] = useState<string | null>(null);
  
  // Marker pins states
  const [markerNotes, setMarkerNotes] = useState<MarkerNote[]>([]);
  const [selectedMarkerId, setSelectedMarkerId] = useState<string | null>(null);

  // Whiteboard annotations states (Miro features)
  const [annotations, setAnnotations] = useState<WhiteboardAnnotation[]>([]);
  const [selectedAnnotationId, setSelectedAnnotationId] = useState<string | null>(null);
  const [activeWhiteboardTool, setActiveWhiteboardTool] = useState<'select' | 'marker' | 'sticky' | 'text' | 'rect' | 'ellipse' | 'arrow' | 'pen' | 'line' | 'elbow-arrow' | 'block-arrow' | 'rhombus' | 'triangle' | 'diagram' | 'frame'>('select');
  const [currentColor, setCurrentColor] = useState<string>('#f43f5e'); // Default beautiful rose-red

  // Undo / Redo history stacks
  const [undoStack, setUndoStack] = useState<WhiteboardAnnotation[][]>([]);
  const [redoStack, setRedoStack] = useState<WhiteboardAnnotation[][]>([]);

  // Simulation Concurrency User Roles (Satisfying Moro / Miro screenshots of DQH Architects)
  const userRolesList: UserRoleProfile[] = [
    { id: 'role-1', name: 'Thắng', role: 'Quản Lý', email: 'thang@dqh.vn', tag: 'QUẢN LÝ THIẾT KẾ', color: '#1d4ed8' },
    { id: 'role-2', name: 'Admin', role: 'Admin', email: 'admin@dqh.vn', tag: 'ADMIN', color: '#f97316' },
    { id: 'role-3', name: 'QUANG', role: 'Quản trị viên', email: 'vongocquangarc@gmail.com', tag: 'ADMIN', color: '#ea580c' },
    { id: 'role-4', name: 'Minh', role: 'Thiết kế', email: 'minhnhox200022@gmail.com', tag: 'THIẾT KẾ', color: '#475569' },
    { id: 'role-5', name: 'Vy', role: 'Thiết kế', email: 'vy@dqh.vn', tag: 'THIẾT KẾ', color: '#64748b' },
    { id: 'role-6', name: 'Hậu', role: 'Nhân viên', email: 'hau@dqh.vn', tag: 'MARKETING', color: '#8b5cf6' },
    { id: 'role-7', name: 'Khoa', role: 'Thiết kế', email: 'khoa@dqh.vn', tag: 'THIẾT KẾ', color: '#0284c7' },
    { id: 'role-8', name: 'Mụi Ngô', role: 'Quản Lý Thiết Kế', email: 'Thanhthi.tknt@gmail.com', tag: 'QUẢN LÝ THIẾT KẾ', color: '#06b6d4' },
    { id: 'role-9', name: 'trung test', role: 'giam sat', email: 'trung@dqh.vn', tag: 'QUẢN LÝ THI CÔNG', color: '#4f46e5' },
    { id: 'role-10', name: 'KHÁCH HÀNG DUYỆT', role: 'Khách Hàng', email: 'ai.dqharchitects@gmail.com', tag: 'KHÁCH HÀNG', hasConstruction: true, color: '#10b981' }
  ];
  const [activeUserRole, setActiveUserRole] = useState<UserRoleProfile>(userRolesList[0]);

  // Miro-like Space & Board selections (for Left Panel organization)
  const spaces = ['Kiểm tra bàn giao HQ', 'Phase 1 - Xây thô', 'MEP & Hoàn thiện nội thất'];
  const [activeSpace, setActiveSpace] = useState<string>(spaces[0]);
  const boards = ['Bản vẽ Ground Floor', 'Sơ đồ cứu hỏa tầng lửng', 'Nhiệm thu hoàn thiện'];
  const [activeBoardName, setActiveBoardName] = useState<string>(boards[0]);

  // Modal and layout controllers
  const [showCameraModal, setShowCameraModal] = useState<boolean>(false);
  const [showReportPreview, setShowReportPreview] = useState<boolean>(false);
  const [showDowmarkModal, setShowDowmarkModal] = useState<boolean>(false);
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [showLessonsModal, setShowLessonsModal] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);

  // Optimized Workspace UI / Zen Mode controls
  const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState<boolean>(true);
  const [isRightSidebarOpen, setIsRightSidebarOpen] = useState<boolean>(true);
  const [isBottomPanelOpen, setIsBottomPanelOpen] = useState<boolean>(true);
  const [isHeaderOpen, setIsHeaderOpen] = useState<boolean>(true);
  const [isZenMode, setIsZenMode] = useState<boolean>(false);

  // Miro Dashboard states
  const [currentView, setCurrentView] = useState<'dashboard' | 'workspace'>('dashboard');
  const [favoriteProjectIds, setFavoriteProjectIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('dqh_starred_projects');
    return saved ? JSON.parse(saved) : ['proj-1', 'proj-3', 'proj-8']; // default favorite projects matching screen
  });
  const [dbSearchQuery, setDbSearchQuery] = useState('');
  const [dbStatusFilter, setDbStatusFilter] = useState('all');
  const [dbSortBy, setDbSortBy] = useState('newest');
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [dashboardLayout, setDashboardLayout] = useState<'grid' | 'list'>('list'); // Miro board view defaults to List (table-like as requested)

  // Custom project creation input states
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectLeader, setNewProjectLeader] = useState('KTS. Võ Ngọc Quang');
  const [newProjectClient, setNewProjectClient] = useState('');
  const [newProjectAddress, setNewProjectAddress] = useState('');

  // Auto-open right details panel when drawing or defect element is focused
  useEffect(() => {
    if (selectedMarkerId || selectedAnnotationId) {
      setIsRightSidebarOpen(true);
    }
  }, [selectedMarkerId, selectedAnnotationId]);

  // Fetch initial data from IndexedDB
  async function loadData() {
    try {
      setIsLoading(true);
      let plans = await getFloorPlans();
      
      // Load or initialize projects
      const storedProjects = localStorage.getItem('dqh_active_projects_v2');
      let projsList: Project[] = [];
      if (storedProjects) {
        projsList = JSON.parse(storedProjects);
      } else {
        projsList = INITIAL_PROJECTS;
        localStorage.setItem('dqh_active_projects_v2', JSON.stringify(INITIAL_PROJECTS));
      }
      setProjects(projsList);

      // If plans list is empty, we seed the 3 key floorplans for ALL 10 projects!
      if (plans.length === 0) {
        const seededPlans: FloorPlan[] = [];
        
        for (const proj of projsList) {
          // Plan 1: Sàn ốp lát
          const planTiling: FloorPlan = {
            id: `${proj.id}-tiling`,
            name: `Sàn ốp lát`,
            imageData: getFlavorFloorPlan(proj.name, 'tiling'),
            width: 1000,
            height: 700,
            createdAt: Date.now() - 100,
            projectId: proj.id,
            planType: 'tiling',
            isPinned: true
          };
          await saveFloorPlan(planTiling);
          seededPlans.push(planTiling);

          // Plan 2: Gạch hiện trạng
          const planExisting: FloorPlan = {
            id: `${proj.id}-existing`,
            name: `Gạch hiện trạng`,
            imageData: getFlavorFloorPlan(proj.name, 'existing'),
            width: 1000,
            height: 700,
            createdAt: Date.now() - 200,
            projectId: proj.id,
            planType: 'existing',
            isPinned: true
          };
          await saveFloorPlan(planExisting);
          seededPlans.push(planExisting);

          // Plan 3: Bố trí nội thất
          const planLayout: FloorPlan = {
            id: `${proj.id}-layout`,
            name: `Bố trí nội thất`,
            imageData: getFlavorFloorPlan(proj.name, 'layout'),
            width: 1000,
            height: 700,
            createdAt: Date.now() - 300,
            projectId: proj.id,
            planType: 'layout',
            isPinned: true
          };
          await saveFloorPlan(planLayout);
          seededPlans.push(planLayout);

          // Seed realistic defect pins inside Project 1's plans on startup
          if (proj.id === 'proj-1') {
            const marker1: MarkerNote = {
              id: 'seeded-marker-proj1-1',
              floorPlanId: planTiling.id,
              x: 42,
              y: 52,
              title: 'Nứt sạt mạch keo vách kính tắm sát sàn',
              photoData: null,
              audioData: null,
              transcription: 'Phát hiện tại khe hở chân đế vách bath-tub. Keo co dập rách sủi bong.',
              textNotes: 'Biện pháp: KTS. Thắng chỉ thị cạo sủi sạch silicone mốc bẩn, khò khô rãnh và bơm nạp đầy keo chịu moisture mác mốt Apollo chống rêu đen.',
              createdAt: Date.now() - 3600000,
              comments: [
                { id: 'sc-1', userId: 'role-1', userName: 'Thắng', userRole: 'Quản Lý', content: 'Cần đốc thúc xử lý gấp để nghiệm thu.', createdAt: Date.now() - 1800000 }
              ],
              tags: ['Vách', 'Kính', 'Keo silicon']
            };
            await saveMarkerNote(marker1);

            const marker2: MarkerNote = {
              id: 'seeded-marker-proj1-2',
              floorPlanId: planExisting.id,
              x: 75,
              y: 35,
              title: 'Lệch cốt gạch hiện trạng sảnh phòng khách',
              photoData: null,
              audioData: null,
              transcription: 'Cốt bê tông lồi lõm nhô cục bộ lên 12mm vượt mức khoan cấn xây thô.',
              textNotes: 'Giải pháp: Cho máy cán mài phẳng gồ ghề bê tông nền thô, xịt rửa sạch bụi mạt rồi mới tiến hành đắp vữa hồ cát polymer bù bám dính.',
              createdAt: Date.now() - 7200000,
              comments: [
                { id: 'sc-2', userId: 'role-3', userName: 'QUANG', userRole: 'Quản trị viên', content: 'Đã hoàn tất dọn bãi bào cốt bê tông hoàn toàn phẳng.', createdAt: Date.now() - 3600000 }
              ],
              tags: ['Sàn', 'Cốt cán', 'Bê tông']
            };
            await saveMarkerNote(marker2);

            const stickySeed: WhiteboardAnnotation = {
              id: 'seeded-sticky-proj1',
              floorPlanId: planTiling.id,
              type: 'sticky',
              x: 18,
              y: 25,
              width: 14,
              height: 12,
              color: '#f59e0b',
              content: 'Ghi chú KTS Thắng:\nƯu tiên dải hàng gạch nguyên tấm từ sảnh chính vào trong, gạch vụn xẻ ghép khuất góc tủ dồ!',
              createdAt: Date.now(),
              userName: 'Thắng'
            };
            await saveAnnotation(stickySeed);
          }
        }
        plans = seededPlans;
      } else {
        // Check for backwards compatibility: assign floorplans without projectId to Proj-1
        for (const p of plans) {
          if (!p.projectId) {
            p.projectId = 'proj-1';
            await saveFloorPlan(p);
          }
        }
      }

      setFloorPlans(plans);

      // Track active selections
      const storedActiveProjId = localStorage.getItem('last_active_project_id_v2') || projsList[0].id;
      setActiveProjectId(storedActiveProjId);

      const projectPlans = plans.filter(p => p.projectId === storedActiveProjId);
      if (projectPlans.length > 0) {
        const storedActiveId = localStorage.getItem('last_active_floor_plan_v2');
        const exists = projectPlans.some(p => p.id === storedActiveId);
        setActiveFloorPlanId(exists ? storedActiveId : projectPlans[0].id);
      } else if (plans.length > 0) {
        setActiveFloorPlanId(plans[0].id);
      }

    } catch (err) {
      console.error('Lỗi khi tải dữ liệu từ database:', err);
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  // Sync markerNotes & whiteboard annotations on active floor plan changes
  useEffect(() => {
    if (activeFloorPlanId) {
      localStorage.setItem('last_active_floor_plan', activeFloorPlanId);
    }
    loadActiveFloorData();
  }, [activeFloorPlanId]);

  async function loadActiveFloorData() {
    try {
      // 1. Load ALL Camera marker notes from DB (no parameters -> yields all)
      const notes = await getMarkerNotes();
      notes.sort((a, b) => a.createdAt - b.createdAt);
      setMarkerNotes(notes);

      // 2. Load ALL Whiteboard annotations from DB (no parameters -> yields all)
      const annots = await getAnnotations();
      setAnnotations(annots);
    } catch (e) {
      console.error(e);
    }
  }

  async function handleUpdateFloorPlan(updated: FloorPlan) {
    try {
      await saveFloorPlan(updated);
      setFloorPlans(prev => prev.map(p => p.id === updated.id ? updated : p));
    } catch (e) {
      console.error(e);
    }
  }

  // Dashboard Project management event handlers
  async function handleCreateProject(name: string, leader: string, client: string, address: string) {
    const newProj: Project = {
      id: `proj-${Date.now()}`,
      name,
      client: client || 'Khách hàng mới',
      leader: leader || 'KTS. Thắng Admin',
      address: address || 'Chưa cập nhật địa chỉ',
      status: 'active',
      progress: Math.floor(Math.random() * 20) + 10, // random start progress
      createdAt: Date.now()
    };
    
    const updatedProjects = [newProj, ...projects];
    setProjects(updatedProjects);
    localStorage.setItem('dqh_active_projects_v2', JSON.stringify(updatedProjects));

    // Seed beautiful floor plans for this new project so the canvas loads properly!
    const seed1: FloorPlan = {
      id: `${newProj.id}-tiling`,
      name: `Sàn ốp lát`,
      imageData: getFlavorFloorPlan(newProj.name, 'tiling'),
      width: 1000,
      height: 700,
      createdAt: Date.now() - 100,
      projectId: newProj.id,
      planType: 'tiling',
      isPinned: true
    };
    const seed2: FloorPlan = {
      id: `${newProj.id}-existing`,
      name: `Gạch hiện trạng`,
      imageData: getFlavorFloorPlan(newProj.name, 'existing'),
      width: 1000,
      height: 700,
      createdAt: Date.now() - 200,
      projectId: newProj.id,
      planType: 'existing',
      isPinned: true
    };
    const seed3: FloorPlan = {
      id: `${newProj.id}-layout`,
      name: `Bố trí nội thất`,
      imageData: getFlavorFloorPlan(newProj.name, 'layout'),
      width: 1000,
      height: 700,
      createdAt: Date.now() - 300,
      projectId: newProj.id,
      planType: 'layout',
      isPinned: true
    };
    await saveFloorPlan(seed1);
    await saveFloorPlan(seed2);
    await saveFloorPlan(seed3);

    setFloorPlans(prev => [seed1, seed2, seed3, ...prev]);

    // Automatically set and active this new project workspace
    setActiveProjectId(newProj.id);
    setActiveFloorPlanId(seed1.id);
    localStorage.setItem('last_active_project_id_v2', newProj.id);
    setCurrentView('workspace');
  }

  async function handleDeleteProject(id: string) {
    if (window.confirm('Bạn có chắc chắn muốn xóa dự án này? Mọi bản vẽ mặt bằng và ghim lỗi đi kèm sẽ bị xóa hoàn toàn.')) {
      const updated = projects.filter(p => p.id !== id);
      setProjects(updated);
      localStorage.setItem('dqh_active_projects_v2', JSON.stringify(updated));

      // Clean up local related floor plans and delete them
      const relatedDocs = floorPlans.filter(fp => fp.projectId === id);
      for (const doc of relatedDocs) {
        await deleteFloorPlan(doc.id);
      }
      setFloorPlans(prev => prev.filter(fp => fp.projectId !== id));

      if (activeProjectId === id) {
        const nextActive = updated[0]?.id || null;
        setActiveProjectId(nextActive);
        if (nextActive) {
          const related = floorPlans.filter(p => p.projectId === nextActive);
          setActiveFloorPlanId(related[0]?.id || null);
        } else {
          setActiveFloorPlanId(null);
        }
      }
    }
  }

  function toggleFavoriteProject(id: string) {
    const list = favoriteProjectIds.includes(id)
      ? favoriteProjectIds.filter(item => item !== id)
      : [...favoriteProjectIds, id];
    setFavoriteProjectIds(list);
    localStorage.setItem('dqh_starred_projects', JSON.stringify(list));
  }

  // Handle uploading custom drawings
  async function handleFloorPlanUpload(name: string, imageData: string, canvasX?: number, canvasY?: number, width?: number, height?: number) {
    const id = `plan-${Date.now()}`;
    const newPlan: FloorPlan = {
      id,
      name,
      imageData,
      width: width || 800,
      height: height || 600,
      createdAt: Date.now(),
      canvasX,
      canvasY,
      projectId: activeProjectId || 'proj-1',
      planType: 'layout',
      isPinned: false
    };
    
    setUploadProgress('Đang lưu bản vẽ mặt bằng...');
    try {
      await saveFloorPlan(newPlan);
      setFloorPlans(prev => [newPlan, ...prev]);
      setActiveFloorPlanId(id);
    } catch (e) {
      console.error(e);
    } finally {
      setUploadProgress(null);
    }
  }

  // Handle successful imports from partner/customer JSON backups
  async function handleImportSuccess(importedPlan: FloorPlan, importedMarkers: MarkerNote[], importedAnnotations: WhiteboardAnnotation[]) {
    try {
      setIsLoading(true);
      
      // 1. Save import drawing meta
      await saveFloorPlan(importedPlan);
      
      // 2. Clear old database items of THIS SPECIFIC drawing so it updates flawlessly
      // (This prevents duplicating existing markers or lines)
      const existingMarkers = markerNotes.filter(m => m.floorPlanId === importedPlan.id);
      for (const m of existingMarkers) {
        await deleteMarkerNote(m.id);
      }
      
      const existingAnnots = annotations.filter(a => a.floorPlanId === importedPlan.id);
      for (const a of existingAnnots) {
        await deleteAnnotation(a.id);
      }

      // 3. Save new markers
      for (const m of importedMarkers) {
        await saveMarkerNote(m);
      }

      // 4. Save new annotations
      for (const a of importedAnnotations) {
        await saveAnnotation(a);
      }

      // 5. Update local state
      setFloorPlans(prev => {
        const filtered = prev.filter(p => p.id !== importedPlan.id);
        return [importedPlan, ...filtered];
      });
      setActiveFloorPlanId(importedPlan.id);
      
      // Force refresh active board data
      const finalMarkers = await getMarkerNotes();
      setMarkerNotes(finalMarkers);
      
      const finalAnnots = await getAnnotations();
      setAnnotations(finalAnnots);

    } catch (err) {
      console.error('Error importing JSON package:', err);
      alert('Không thể nhập file dữ liệu này!');
    } finally {
      setIsLoading(false);
    }
  }

  // Handle importing a simulated project lessons learned drawing & database
  async function handleImportMockBluePrint(planName: string, defects: any[], planId: string) {
    try {
      setIsLoading(true);
      const customId = `sim-plan-${planId}`;
      
      const newPlan: FloorPlan = {
        id: customId,
        name: `Bản vẽ trích lục: ${planName}`,
        imageData: getMockProjectFloorPlan(planName),
        width: 1000,
        height: 700,
        createdAt: Date.now(),
        projectId: activeProjectId || 'proj-1',
        planType: 'layout'
      };

      // 1. Save or replace floor plan drawing metadata
      await saveFloorPlan(newPlan);

      // Clean existing notes/annots of this project to prevent duplicate accumulation
      const prevNotes = await getMarkerNotes();
      const matchNotes = prevNotes.filter(n => n.floorPlanId === customId);
      for (const n of matchNotes) {
        await deleteMarkerNote(n.id);
      }

      const prevAnnots = await getAnnotations();
      const matchAnnots = prevAnnots.filter(a => a.floorPlanId === customId);
      for (const a of matchAnnots) {
        await deleteAnnotation(a.id);
      }

      // 2. Transcribe defects list into real MarkerNote pins
      // We will spread them strategically around the blueprint so they don't overlap (e.g. 30%, 45%, 65%)
      const seedOrigins = [
        { x: 28, y: 48 },
        { x: 72, y: 42 },
        { x: 50, y: 25 },
        { x: 35, y: 75 }
      ];

      for (let i = 0; i < defects.length; i++) {
        const def = defects[i];
        const coord = seedOrigins[i % seedOrigins.length];
        
        const mId = `sim-marker-${planId}-${i}`;
        const seedMarker: MarkerNote = {
          id: mId,
          floorPlanId: customId,
          x: coord.x,
          y: coord.y,
          title: def.title,
          photoData: null,
          audioData: null,
          transcription: def.transcription,
          textNotes: def.textNotes,
          createdAt: Date.now() - (i * 3600000),
          comments: def.comments ? def.comments.map((c: any, cIdx: number) => ({
            id: `sim-comment-${planId}-${i}-${cIdx}`,
            userId: `role-${(cIdx % 4) + 1}`,
            userName: c.user,
            userRole: c.role,
            content: c.text,
            createdAt: Date.now() - (i * 3600000) + (cIdx * 60000)
          })) : [],
          tags: def.tags
        };

        await saveMarkerNote(seedMarker);
      }

      // 3. Add an explanatory sticky note on the Miro board!
      const stickyAnnot: WhiteboardAnnotation = {
        id: `sim-sticky-${planId}`,
        floorPlanId: customId,
        type: 'sticky',
        x: 10,
        y: 60,
        width: 14,
        height: 12,
        color: '#f59e0b', // Amber yellow sticky
        content: `BÀI HỌC KINH NGHIỆM:\n\n${defects[0].title}\n\n👉 Kéo dán giấy nhớ thảo luận lỗi này để rút kinh nghiệm!`,
        createdAt: Date.now(),
        userName: 'Thắng'
      };
      await saveAnnotation(stickyAnnot);

      // 4. Update memory states
      setFloorPlans(prev => {
        const filtered = prev.filter(p => p.id !== customId);
        return [newPlan, ...filtered];
      });
      setActiveFloorPlanId(customId);

      // Force refresh active database data in state
      const finalMarkers = await getMarkerNotes();
      setMarkerNotes(finalMarkers);
      
      const finalAnnots = await getAnnotations();
      setAnnotations(finalAnnots);

      alert(`Đã trích lục thành công "${planName}" từ kho tư liệu kiểm tra! Vui lòng zoom/pan bảng vẽ hoặc nhấp vào các điểm lỗi màu đỏ để xem chi tiết bài học kinh nghiệm.`);

    } catch (err) {
      console.error('Error seeding simulated blueprint:', err);
      alert('Không thể tải tiêu bản bài học lỗi này.');
    } finally {
      setIsLoading(false);
    }
  }

  // Handle dropping a marker pin onto the board
  async function handleAddMarker(x: number, y: number) {
    if (!activeFloorPlanId) return;
    
    const count = markerNotes.length + 1;
    const newMarkerId = `marker-${Date.now()}`;
    const newMarker: MarkerNote = {
      id: newMarkerId,
      floorPlanId: activeFloorPlanId,
      x,
      y,
      title: `Chấm lỗi #${count} - Tên Lỗi Kỹ Thuật`,
      photoData: null,
      audioData: null,
      transcription: '',
      textNotes: '',
      createdAt: Date.now(),
      comments: []
    };

    try {
      await saveMarkerNote(newMarker);
      setMarkerNotes(prev => [...prev, newMarker]);
      setSelectedMarkerId(newMarkerId);
      setSelectedAnnotationId(null);
      
      // Auto open camera to take photo immediately for visual fluid workflow!
      setShowCameraModal(true);
    } catch (e) {
      console.error(e);
    }
  }

  // Handle updates to existing markers
  async function handleUpdateMarker(updated: MarkerNote) {
    try {
      await saveMarkerNote(updated);
      setMarkerNotes(prev => prev.map(m => m.id === updated.id ? updated : m));
    } catch (e) {
      console.error(e);
    }
  }

  // Handle deleting markers
  async function handleDeleteMarker(id: string) {
    const doubleCheck = confirm('Bạn có chắc chắn muốn xóa điểm note này cùng toàn bộ tệp chụp ảnh và thuyết minh giọng nói đính kèm?');
    if (!doubleCheck) return;

    try {
      await deleteMarkerNote(id);
      setMarkerNotes(prev => prev.filter(m => m.id !== id));
      if (selectedMarkerId === id) {
        setSelectedMarkerId(null);
      }
    } catch (e) {
      console.error(e);
    }
  }

  // Delete entire floor plan
  async function handleDeleteFloorPlan(id: string) {
    const doubleCheck = confirm('Bạn có chắc chắn muốn xóa bản vẽ mặt bằng này? Tất cả các điểm ghim, hình ảnh, whiteboard và voice notes liên quan sẽ bị xóa vĩnh viễn khỏi máy.');
    if (!doubleCheck) return;

    try {
      await deleteFloorPlan(id);
      const remaining = floorPlans.filter(p => p.id !== id);
      setFloorPlans(remaining);
      
      if (activeFloorPlanId === id) {
        setActiveFloorPlanId(remaining.length > 0 ? remaining[0].id : null);
      }
    } catch (e) {
      console.error(e);
    }
  }

  // Handle inserting captured photo into focused marker
  async function handleCapturePhoto(photoBase64: string) {
    const currentMarker = markerNotes.find(m => m.id === selectedMarkerId);
    if (currentMarker) {
      const updated = {
        ...currentMarker,
        photoData: photoBase64
      };
      await handleUpdateMarker(updated);
    }
  }

  // ==========================================
  // WHITEBOARD ANNOTATIONS OPS
  // ==========================================
  
  // Push state to undo stack
  function pushUndoState(currentAnnotsList: WhiteboardAnnotation[]) {
    // Keep stack size max 25
    setUndoStack(prev => [...prev.slice(-24), [...currentAnnotsList]]);
    setRedoStack([]); // Clear redo stack on new progressive actions
  }

  async function handleAddAnnotation(newAnnot: WhiteboardAnnotation) {
    pushUndoState(annotations);
    try {
      await saveAnnotation(newAnnot);
      setAnnotations(prev => [...prev, newAnnot]);
      setSelectedAnnotationId(newAnnot.id);
    } catch (e) {
      console.error(e);
    }
  }

  async function handleUpdateAnnotation(updated: WhiteboardAnnotation) {
    // Only push to undo state if we actually changed content or repositioned
    try {
      await saveAnnotation(updated);
      setAnnotations(prev => prev.map(a => a.id === updated.id ? updated : a));
    } catch (e) {
      console.error(e);
    }
  }

  async function handleDeleteAnnotation(id: string) {
    pushUndoState(annotations);
    try {
      await deleteAnnotation(id);
      setAnnotations(prev => prev.filter(a => a.id !== id));
      if (selectedAnnotationId === id) {
        setSelectedAnnotationId(null);
      }
    } catch (e) {
      console.error(e);
    }
  }

  // Undo/Redo trigger mechanics
  async function handleUndo() {
    if (undoStack.length === 0) return;
    const previousState = undoStack[undoStack.length - 1];
    
    // Save current into redo stack
    setRedoStack(prev => [...prev, [...annotations]]);
    
    // Set annotations
    setAnnotations(previousState);
    setUndoStack(prev => prev.slice(0, -1));

    // Persist all onto IndexedDB
    // For safety, clear all annotations in store and save previousState to keep it synced
    try {
      // Clear annotations associated with current activeFloorPlanId
      if (activeFloorPlanId) {
        const stored = await getAnnotations(activeFloorPlanId);
        for (const item of stored) {
          await deleteAnnotation(item.id);
        }
        for (const item of previousState) {
          await saveAnnotation(item);
        }
      }
    } catch (e) {
      console.warn("Error resolving DB sync during undo:", e);
    }
  }

  async function handleRedo() {
    if (redoStack.length === 0) return;
    const nextState = redoStack[redoStack.length - 1];

    setUndoStack(prev => [...prev, [...annotations]]);
    setAnnotations(nextState);
    setRedoStack(prev => prev.slice(0, -1));

    try {
      if (activeFloorPlanId) {
        const stored = await getAnnotations(activeFloorPlanId);
        for (const item of stored) {
          await deleteAnnotation(item.id);
        }
        for (const item of nextState) {
          await saveAnnotation(item);
        }
      }
    } catch (e) {
      console.warn("Error resolving DB sync during redo:", e);
    }
  }

  // Export full JSON backup
  function exportDataPackage() {
    const activePlan = floorPlans.find(p => p.id === activeFloorPlanId);
    if (!activePlan) return;

    const exportBundle = {
      floorPlan: activePlan,
      markers: projectMarkerNotes,
      annotations: projectAnnotations,
      exportedAt: Date.now(),
      vibe: "Floor Plan Camera, Whiteboard & Voice Notes Miro Export Package"
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(exportBundle, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute('href', dataStr);
    dlAnchor.setAttribute('download', `bao_cao_${activePlan.name.toLowerCase().replace(/\s+/g, '_')}_export.json`);
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();
  }

  // Derived state to keep each project's whiteboard/pins scoped correctly!
  const projectFloorPlans = useMemo(() => {
    return floorPlans.filter(fp => fp.projectId === activeProjectId);
  }, [floorPlans, activeProjectId]);

  const projectFloorPlanIds = useMemo(() => {
    return projectFloorPlans.map(fp => fp.id);
  }, [projectFloorPlans]);

  const projectMarkerNotes = useMemo(() => {
    return markerNotes.filter(m => projectFloorPlanIds.includes(m.floorPlanId));
  }, [markerNotes, projectFloorPlanIds]);

  const projectAnnotations = useMemo(() => {
    return annotations.filter(a => projectFloorPlanIds.includes(a.floorPlanId));
  }, [annotations, projectFloorPlanIds]);

  const selectedMarker = markerNotes.find(m => m.id === selectedMarkerId) || null;
  const selectedAnnotation = annotations.find(a => a.id === selectedAnnotationId) || null;
  const activePlan = floorPlans.find(p => p.id === activeFloorPlanId) || null;

  // ==========================================
  // Render the Miro-Style Project Dashboard (Vùng cổng vào)
  // ==========================================
  if (currentView === 'dashboard') {
    const sortedAndFiltered = [...projects].filter(p => {
      const q = dbSearchQuery.toLowerCase();
      const matchSearch = p.name.toLowerCase().includes(q) || 
                          p.leader.toLowerCase().includes(q) || 
                          p.client.toLowerCase().includes(q) ||
                          p.address.toLowerCase().includes(q);
      
      if (dbStatusFilter === 'starred') {
        return matchSearch && favoriteProjectIds.includes(p.id);
      }
      return matchSearch;
    });

    if (dbSortBy === 'newest') {
      sortedAndFiltered.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    } else if (dbSortBy === 'progress') {
      sortedAndFiltered.sort((a, b) => b.progress - a.progress);
    } else if (dbSortBy === 'alphabet') {
      sortedAndFiltered.sort((a, b) => a.name.localeCompare(b.name));
    }

    return (
      <div className="min-h-screen bg-[#0e131f] text-slate-100 flex flex-col font-sans selection:bg-emerald-500/15 selection:text-emerald-300">
        
        {/* MIRO DASHBOARD TOP BAR */}
        <header className="bg-[#0b0f19] border-b border-slate-900 h-14 px-4 md:px-6 flex items-center justify-between shrink-0 select-none">
          <div className="flex items-center gap-6">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-gradient-to-tr from-indigo-500 to-emerald-400 rounded-xl text-white shadow-inner flex items-center justify-center shrink-0">
                <Layout className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-black tracking-tight text-white block leading-none">Moro Board</span>
                <span className="text-[9px] text-slate-500 font-bold block mt-0.5 uppercase tracking-widest">DQH Architects</span>
              </div>
            </div>
            
            {/* Miro-Like "Free / Pro" Team Badge */}
            <div className="hidden lg:flex items-center gap-1.5 bg-slate-900 border border-slate-850 px-2.5 py-1 rounded-full text-[9px] font-black text-amber-400">
              <span className="bg-amber-400/10 px-1.5 py-0.5 rounded text-amber-400 font-extrabold">STUDIO DQH</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400 font-medium">Khảo Sát & Whiteboard Cộng Tác</span>
            </div>
          </div>

          {/* Quick Stats Search & Active user profiles */}
          <div className="flex items-center gap-2.5">
            <div className="hidden md:flex items-center gap-2 text-xs bg-slate-900/60 border border-slate-850 px-3 py-1.5 rounded-xl text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{projects.length} Dự án sẵn có</span>
            </div>

            <button
              onClick={() => {
                setShowLessonsModal(true);
              }}
              className="flex items-center gap-1 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-black cursor-pointer shadow-md transition-all active:scale-95 duration-150 shrink-0"
              title="Quản lý các mẫu lỗi công trình thiết kế"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Mẫu lỗi</span>
            </button>

            <button
              onClick={() => {
                setShowDowmarkModal(true);
              }}
              className="flex items-center gap-1 px-3 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 rounded-xl text-xs font-bold cursor-pointer transition-colors shrink-0"
              title="Đồng bộ cơ sở dữ liệu IndexedDB"
            >
              <Cloud className="w-3.5 h-3.5 text-emerald-400" />
              <span>Đồng bộ</span>
            </button>
            
            <div className="hidden sm:flex items-center -space-x-1.5 overflow-hidden ml-1">
              {userRolesList.slice(0, 4).map((user) => (
                <div
                  key={user.id}
                  className="w-6 h-6 rounded-full border border-slate-950 flex items-center justify-center text-[8.5px] font-bold text-white shrink-0"
                  style={{ backgroundColor: user.color }}
                  title={`${user.name} (${user.role})`}
                >
                  {user.name.charAt(0).toUpperCase()}
                </div>
              ))}
              <div className="w-6 h-6 rounded-full bg-slate-850 border border-slate-950 flex items-center justify-center text-[8.5px] font-bold text-slate-400 shrink-0 select-none">
                +{userRolesList.length - 4}
              </div>
            </div>
          </div>
        </header>

        {/* MIRO DASHBOARD WRAPPER CONTAINER */}
        <div className="flex-1 overflow-y-auto px-4 py-6 md:px-8 max-w-7xl w-full mx-auto flex flex-col gap-8">
          
          {/* A. TEMPLATE BAR (Tương tự dải template Miro) */}
          <section className="bg-slate-900/30 border border-slate-900/60 rounded-3xl p-5 select-none relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xs font-black text-indigo-400 uppercase tracking-widest">
                Mẫu bản vẽ & Thiết lập nhanh (Templates)
              </h2>
              <span className="text-[10px] text-slate-500 hover:text-indigo-400 cursor-pointer flex items-center gap-0.5">
                Xem tất cả mẫu
                <ChevronRight className="w-3 h-3" />
              </span>
            </div>

            {/* Grid of Templates in Miro */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
              {/* Card 1: Blank Board */}
              <div 
                onClick={() => {
                  setNewProjectName('Dự án biệt thự nghỉ dưỡng');
                  setNewProjectLeader('KTS. Võ Ngọc Quang');
                  setNewProjectClient('Chị Kim Dung');
                  setNewProjectAddress('Phú Quốc, Kiên Giang');
                  setShowNewProjectModal(true);
                }}
                className="bg-slate-950/80 border-2 border-dashed border-slate-800 hover:border-indigo-500/50 rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] transition-all hover:-translate-y-1 active:scale-95 group shadow-sm hover:shadow-indigo-500/10"
              >
                <div className="w-8 h-8 rounded-full bg-indigo-500/10 border border-indigo-400/20 text-indigo-400 flex items-center justify-center group-hover:scale-110 transition-transform mb-2">
                  <Plus className="w-5 h-5 animate-pulse" />
                </div>
                <span className="text-xs font-bold text-white leading-tight">Blank Board</span>
                <span className="text-[9px] text-slate-500 mt-1">Khởi tạo board trống</span>
              </div>

              {/* Template Card 2 */}
              <div 
                onClick={() => {
                  handleCreateProject('Căn Hộ Đột Phá 1PN Studio Q1', 'KTS. Võ Ngọc Quang', 'Anh Hoàng Kiên', 'Số 2 Tôn Đức Thắng, Quận 1, TPHCM');
                }}
                className="bg-slate-950/40 hover:bg-slate-900 border border-slate-850 hover:border-slate-750 rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] transition-all hover:-translate-y-1 active:scale-95 group"
              >
                <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform text-lg">
                  📐
                </div>
                <span className="text-xs font-bold text-slate-200 leading-tight">AI Playground</span>
                <span className="text-[9px] text-slate-500 mt-1">Căn hộ Studio thông minh</span>
              </div>

              {/* Template Card 3 */}
              <div 
                onClick={() => {
                  handleCreateProject('Thiết Kế Cải Tạo Penthouse Gold', 'KTS. Thắng Nguyễn', 'Chị Ngọc Hà', 'Central Park, Bình Thạnh, TPHCM');
                }}
                className="bg-slate-950/40 hover:bg-slate-900 border border-slate-850 hover:border-slate-750 rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] transition-all hover:-translate-y-1 active:scale-95 group"
              >
                <div className="w-8 h-8 rounded-xl bg-orange-500/10 text-orange-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform text-lg">
                  🧱
                </div>
                <span className="text-xs font-bold text-slate-200 leading-tight">Kanban Framework</span>
                <span className="text-[9px] text-slate-500 mt-1">Quản lý thi công thô</span>
              </div>

              {/* Template Card 4 */}
              <div 
                onClick={() => {
                  handleCreateProject('Biệt Thự Vườn Sinh Thái Thảo Điền', 'KTS. Vy Nguyễn', 'Mr. Robert Chen', 'Thảo Điền, Quận 2, TPHCM');
                }}
                className="bg-slate-950/40 hover:bg-slate-900 border border-slate-850 hover:border-slate-750 rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] transition-all hover:-translate-y-1 active:scale-95 group"
              >
                <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform text-lg">
                  🛋️
                </div>
                <span className="text-xs font-bold text-slate-200 leading-tight">Nội thất Chateau</span>
                <span className="text-[9px] text-slate-500 mt-1">Xác lập không gian biệt thự</span>
              </div>

              {/* Template Card 5 */}
              <div 
                onClick={() => {
                  handleCreateProject('Văn Phòng Collab DQH Architects', 'KTS. Thắng Admin', 'DQH Partners', 'Thành phố Thủ Đức, TPHCM');
                }}
                className="bg-slate-950/40 hover:bg-slate-900 border border-slate-850 hover:border-slate-750 rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] transition-all hover:-translate-y-1 active:scale-95 group"
              >
                <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform text-lg">
                  💻
                </div>
                <span className="text-xs font-bold text-slate-200 leading-tight">Sprint Planning</span>
                <span className="text-[9px] text-slate-500 mt-1">Thiết kế hoàn thiện nội thất</span>
              </div>
            </div>
          </section>

          {/* B. MAIN PROJECT BOARDS SECTION (Danh mục bản vẽ tương tự Miro) */}
          <section className="flex flex-col gap-4">
            
            {/* Header filters and controls */}
            <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-slate-900 pb-4">
              <div>
                <h2 className="text-base font-black text-slate-100 flex items-center gap-2">
                  Dự án thiết kế trong Team ({sortedAndFiltered.length})
                </h2>
                <p className="text-xs text-slate-500 mt-1">Mạng lưới trực quan hóa bản vẽ đính kèm dập ghim lỗi trực tuyến dành cho KTS & Nhà Thầu</p>
              </div>

              {/* Action Control Panel */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Search Bar */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-550" />
                  <input
                    type="text"
                    placeholder="Tìm tên dự án, KTS, khách..."
                    value={dbSearchQuery}
                    onChange={(e) => setDbSearchQuery(e.target.value)}
                    className="bg-[#111827] border border-slate-850 rounded-xl pl-9 pr-4 py-1.5 text-xs w-full sm:w-[220px] text-slate-200 focus:outline-none focus:border-indigo-500 transition-all placeholder:text-slate-600"
                  />
                </div>

                {/* Filter Star status */}
                <select
                  value={dbStatusFilter}
                  onChange={(e) => setDbStatusFilter(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-300 focus:outline-none cursor-pointer hover:border-slate-700 focus:border-indigo-500"
                >
                  <option value="all">Tất cả dự án mẫu</option>
                  <option value="starred">⭐ Dự án Đã Ghim Yêu Thích</option>
                </select>

                {/* Sort Selector */}
                <select
                  value={dbSortBy}
                  onChange={(e) => setDbSortBy(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-300 focus:outline-none cursor-pointer hover:border-slate-700 focus:border-indigo-500"
                >
                  <option value="newest">Ngày khởi tạo gần nhất</option>
                  <option value="progress">Tiến độ thiết kế giật đỉnh</option>
                  <option value="alphabet">Xếp tên bảng chữ cái A-Z</option>
                </select>

                {/* Grid / List Layout toggle */}
                <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5">
                  <button
                    onClick={() => setDashboardLayout('grid')}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${dashboardLayout === 'grid' ? 'bg-slate-800 text-indigo-400' : 'text-slate-400 hover:text-white'}`}
                    title="Dạng lưới"
                  >
                    <Grid className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDashboardLayout('list')}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${dashboardLayout === 'list' ? 'bg-slate-800 text-indigo-400' : 'text-slate-400 hover:text-white'}`}
                    title="Dạng bảng kê (Giống Miro)"
                  >
                    <ListIcon className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Create Board Button */}
                <button
                  onClick={() => {
                    setNewProjectName('');
                    setNewProjectClient('');
                    setNewProjectAddress('');
                    setNewProjectLeader('KTS. Võ Ngọc Quang');
                    setShowNewProjectModal(true);
                  }}
                  className="h-8 pl-3 pr-4 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl cursor-pointer flex items-center gap-1 shadow-md transition-all active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tạo dự án mới</span>
                </button>
              </div>
            </div>

            {/* C. RENDER CORES */}
            {sortedAndFiltered.length === 0 ? (
              <div className="bg-slate-900/10 border-2 border-slate-900/60 border-dashed rounded-3xl p-16 text-center select-none">
                <Layout className="w-12 h-12 text-slate-700 mx-auto mb-3" />
                <p className="text-sm text-slate-400 font-bold">Không tìm thấy dự án phù hợp</p>
                <p className="text-xs text-slate-600 mt-1">Vui lòng nhập từ khóa khác hoặc click nút "Tạo dự án mới" để bắt đầu dập ghim lỗi và vẽ phối thảo.</p>
              </div>
            ) : dashboardLayout === 'grid' ? (
              /* GRID LAYOUT MODE */
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {sortedAndFiltered.map((p) => {
                  const isStarred = favoriteProjectIds.includes(p.id);
                  return (
                    <div 
                      key={p.id}
                      className="bg-[#111827]/40 border border-slate-900 hover:border-slate-800 hover:bg-[#111827]/75 rounded-2xl flex flex-col p-4 transition-all hover:-translate-y-0.5 group relative"
                    >
                      {/* Favorite star */}
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavoriteProject(p.id);
                        }}
                        className="absolute top-4 right-4 p-1.5 rounded-lg border border-slate-850 text-slate-500 bg-slate-950/60 hover:text-amber-400 transition-all z-10"
                        title="Ủy thác dự án mẫu yêu thích"
                      >
                        <Star className={`w-3.5 h-3.5 ${isStarred ? 'fill-amber-400 text-amber-400 font-bold' : 'text-slate-500'}`} />
                      </button>

                      <div className="flex-1 cursor-pointer" onClick={() => {
                        setActiveProjectId(p.id);
                        const related = floorPlans.filter(fp => fp.projectId === p.id);
                        if (related.length > 0) {
                          setActiveFloorPlanId(related[0].id);
                        }
                        localStorage.setItem('last_active_project_id_v2', p.id);
                        setCurrentView('workspace');
                      }}>
                        <div className="flex items-center gap-1.5 mb-2 text-[10px] text-slate-550">
                          <span className="font-extrabold text-indigo-400 uppercase tracking-widest">KTS: {p.leader.replace('KTS. ', '')}</span>
                        </div>
                        <h3 className="text-sm font-black text-white group-hover:text-indigo-400 transition-colors line-clamp-2 pr-6 mb-2" title={p.name}>
                          {p.name}
                        </h3>
                        <p className="text-xs text-slate-400 line-clamp-1 mb-1">👤 Khách hàng: <span className="font-semibold text-slate-300">{p.client}</span></p>
                        <p className="text-[11px] text-slate-500 line-clamp-2 max-w-sm mb-4">📍 {p.address}</p>
                      </div>

                      {/* Progress bar and entering */}
                      <div className="border-t border-slate-900/60 pt-3 mt-auto flex items-center justify-between">
                        <div className="w-[58%]">
                          <div className="flex items-center justify-between text-[9px] text-slate-550 font-bold mb-1">
                            <span>Tiến độ</span>
                            <span className="text-amber-400 font-mono">{p.progress}%</span>
                          </div>
                          <div className="w-full bg-slate-950 rounded-full h-1 overflow-hidden">
                            <div className="bg-gradient-to-r from-amber-400 to-indigo-500 h-1 rounded-full" style={{ width: `${p.progress}%` }} />
                          </div>
                        </div>

                        <div className="flex items-center gap-1 text-[11px]">
                          <button
                            onClick={() => {
                              setActiveProjectId(p.id);
                              const related = floorPlans.filter(fp => fp.projectId === p.id);
                              if (related.length > 0) {
                                setActiveFloorPlanId(related[0].id);
                              }
                              localStorage.setItem('last_active_project_id_v2', p.id);
                              setCurrentView('workspace');
                            }}
                            className="p-1 px-3 bg-indigo-500/10 hover:bg-indigo-500/25 border border-indigo-500/20 rounded-lg text-[9px] font-black text-indigo-300 transition-colors uppercase cursor-pointer flex items-center gap-1"
                          >
                            <span>Vào Board</span>
                          </button>
                          <button
                            onClick={() => handleDeleteProject(p.id)}
                            className="p-1.5 text-slate-500 hover:text-rose-400 bg-slate-950/20 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 rounded-lg transition-colors cursor-pointer"
                            title="Xóa dự án khỏi trình quản lý"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              /* TABLE LIST DIRECTORY VIEW (100% Miro vibe styling) */
              <div className="bg-[#111827]/30 border border-slate-900 rounded-2xl overflow-hidden shadow-2xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs select-none">
                    <thead>
                      <tr className="border-b border-slate-900 bg-[#0b0f19] text-slate-500 font-extrabold uppercase text-[10px] tracking-wider">
                        <th className="py-3 px-4 w-10"></th>
                        <th className="py-3 px-4 min-w-[280px]">Tên Dự Án Thiết Kế / Bản Vẽ Đang Cấu Thành</th>
                        <th className="py-3 px-4">KTS Chủ Trì</th>
                        <th className="py-3 px-4">Tiến Độ Bản Vẽ</th>
                        <th className="py-3 px-4">Chủ Đầu Tư / Địa Chỉ</th>
                        <th className="py-3 px-4">Xác Lập Ngày</th>
                        <th className="py-3 px-4 text-right w-36">Thao tác</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-900/40">
                      {sortedAndFiltered.map((p, idx) => {
                        const isStarred = favoriteProjectIds.includes(p.id);
                        return (
                          <tr 
                            key={p.id}
                            className="hover:bg-[#111827]/50 transition-colors group cursor-pointer"
                            onClick={() => {
                              setActiveProjectId(p.id);
                              const related = floorPlans.filter(fp => fp.projectId === p.id);
                              if (related.length > 0) {
                                setActiveFloorPlanId(related[0].id);
                              }
                              localStorage.setItem('last_active_project_id_v2', p.id);
                              setCurrentView('workspace');
                            }}
                          >
                            {/* Star toggler */}
                            <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                              <button
                                onClick={() => toggleFavoriteProject(p.id)}
                                className="text-slate-500 hover:text-amber-400 hover:scale-110 transition-transform cursor-pointer"
                                title={isStarred ? 'Hủy ghim yêu thích' : 'Ủy thác ghim lên đầu'}
                              >
                                <Star className={`w-4 h-4 ${isStarred ? 'fill-amber-400 text-amber-400' : 'text-slate-700 hover:text-slate-500'}`} />
                              </button>
                            </td>

                            {/* Title & Members detail */}
                            <td className="py-3.5 px-4">
                              <div className="flex flex-col">
                                <span className="font-bold text-slate-100 group-hover:text-indigo-400 transition-colors text-sm">
                                  {p.name}
                                </span>
                                <span className="text-[10px] text-slate-500 mt-1.5 flex items-center gap-1.5">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 block" />
                                  KTS. Võ Ngọc Quang và {idx + 1} thành viên trực tiếp chỉnh sửa hôm nay
                                </span>
                              </div>
                            </td>

                            {/* Lead KTS */}
                            <td className="py-3.5 px-4 text-slate-350 font-bold">
                              {p.leader}
                            </td>

                            {/* Progress bar info mapping */}
                            <td className="py-3.5 px-4">
                              <div className="flex flex-col gap-1 w-32">
                                <div className="flex justify-between items-center text-[10px] text-slate-450 font-bold">
                                  <span>Thiết kế</span>
                                  <span className="text-indigo-400 font-mono">{p.progress}%</span>
                                </div>
                                <div className="w-full bg-slate-950 h-1 rounded-full overflow-hidden">
                                  <div 
                                    className="h-1 rounded-full bg-gradient-to-r from-indigo-500 to-emerald-400" 
                                    style={{ width: `${p.progress}%` }} 
                                  />
                                </div>
                              </div>
                            </td>

                            {/* Client & Address Info */}
                            <td className="py-3.5 px-4 text-slate-300">
                              <div className="flex flex-col max-w-[220px]">
                                <span className="font-semibold text-slate-200">{p.client}</span>
                                <span className="text-[10px] text-slate-500 truncate mt-0.5" title={p.address}>{p.address}</span>
                              </div>
                            </td>

                            {/* Created time formatted */}
                            <td className="py-3.5 px-4 text-slate-400 font-mono">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5 text-slate-600" />
                                <span>{p.createdAt ? new Date(p.createdAt).toLocaleDateString('vi-VN') : '03/06/2026'}</span>
                              </div>
                            </td>

                            {/* Row Buttons and Actions */}
                            <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => {
                                    setActiveProjectId(p.id);
                                    const related = floorPlans.filter(fp => fp.projectId === p.id);
                                    if (related.length > 0) {
                                      setActiveFloorPlanId(related[0].id);
                                    }
                                    localStorage.setItem('last_active_project_id_v2', p.id);
                                    setCurrentView('workspace');
                                  }}
                                  className="h-7 px-3 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white rounded-lg font-black text-[10px] tracking-wide shadow-sm transition-all cursor-pointer flex items-center gap-0.5 uppercase"
                                >
                                  <span>Vào Board</span>
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => handleDeleteProject(p.id)}
                                  className="p-1 px-2 text-slate-600 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/15 rounded-lg cursor-pointer transition-colors"
                                  title="Xoá vĩnh viễn"
                                >
                                  Xoá
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </section>
        </div>

        {/* COMPREHENSIVE OVERLAY POPUP MODAL DIALOG (100% Client React, zero simulation) */}
        {showNewProjectModal && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-4 select-none">
            <div className="bg-[#111827] border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl relative">
              <h2 className="text-base font-black text-white flex items-center gap-2 mb-2">
                🏛️ Khởi tạo dự án thiết kế mới
              </h2>
              <p className="text-xs text-slate-400 mb-5">Hồ sơ dự án sẽ tự động sinh các mặt bản vẽ Sàn ốp lát, Trực trạng gạch khảo sát...</p>

              <form onSubmit={(e) => {
                e.preventDefault();
                if (!newProjectName.trim()) {
                  alert('Vui lòng nhập tên công trình dự án!');
                  return;
                }
                handleCreateProject(newProjectName, newProjectLeader, newProjectClient, newProjectAddress);
                setShowNewProjectModal(false);
              }} className="flex flex-col gap-4">
                
                {/* 1. Name */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-450">Tên dự án thiết kế <span className="text-rose-400">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="Ví dụ: Shophouse Sala Đại Quang Minh,..."
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    className="bg-slate-900 border border-slate-850 focus:border-indigo-500 px-3.5 py-2.5 rounded-xl text-xs text-white focus:outline-none transition-colors"
                  />
                </div>

                {/* 2. Leader KTS */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-450">KTS Chủ Trì Thiết Kế</label>
                  <input
                    type="text"
                    placeholder="Ví dụ: KTS. Võ Ngọc Quang"
                    value={newProjectLeader}
                    onChange={(e) => setNewProjectLeader(e.target.value)}
                    className="bg-slate-900 border border-slate-850 focus:border-indigo-500 px-3.5 py-2.5 rounded-xl text-xs text-white focus:outline-none transition-colors"
                  />
                </div>

                {/* 3. Client */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-450">Khách Hàng Chủ Đầu Tư</label>
                  <input
                    type="text"
                    placeholder="Ví dụ: Chị Vy Nguyễn, Anh Tuấn..."
                    value={newProjectClient}
                    onChange={(e) => setNewProjectClient(e.target.value)}
                    className="bg-slate-900 border border-slate-850 focus:border-indigo-500 px-3.5 py-2.5 rounded-xl text-xs text-white focus:outline-none transition-colors"
                  />
                </div>

                {/* 4. Address */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] uppercase font-bold text-slate-450">Địa Điểm Công Trình</label>
                  <textarea
                    rows={2}
                    placeholder="Ví dụ: Khu Sala, Mai Chí Thọ, Quận 2, TPHCM"
                    value={newProjectAddress}
                    onChange={(e) => setNewProjectAddress(e.target.value)}
                    className="bg-slate-900 border border-slate-850 focus:border-indigo-500 px-3.5 py-2.5 rounded-xl text-xs text-white focus:outline-none resize-none transition-colors"
                  />
                </div>

                {/* Submit & Close Buttons */}
                <div className="flex items-center justify-end gap-2.5 mt-4">
                  <button
                    type="button"
                    onClick={() => setShowNewProjectModal(false)}
                    className="px-4 py-2 bg-slate-900 border border-slate-850 hover:bg-slate-800 rounded-xl text-xs font-bold text-slate-400 transition-colors cursor-pointer"
                  >
                    Hủy bỏ
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-black rounded-xl text-xs shadow-md transition-all active:scale-95 cursor-pointer"
                  >
                    Khởi tạo Board
                  </button>
                </div>

              </form>
            </div>
          </div>
        )}

      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col font-sans text-slate-100 selection:bg-emerald-500/15 selection:text-emerald-300 relative overflow-x-hidden">
      
      {/* 1. BRAND PLATFORM HEADER (Vùng 1 - Tinh gọn tối đa) */}
      {isHeaderOpen && (
        <header className="bg-slate-950 border-b border-slate-900 py-2 px-3 md:px-5 shadow-lg flex items-center justify-between z-30 shrink-0 select-none">
          {/* Logo & Compact Project Switcher in one unit */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentView('dashboard')}
              className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 cursor-pointer font-bold transition-all mr-1"
              title="Quay lại Dashboard Thiết Kế"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-emerald-400" />
              <span>Dashboard</span>
            </button>

            <div className="flex items-center gap-1.5">
              <div className="p-1.5 bg-gradient-to-tr from-emerald-500 to-indigo-600 rounded-lg text-white shadow-inner flex items-center justify-center shrink-0">
                <Layout className="w-4 h-4" />
              </div>
              <h1 className="text-xs font-black tracking-tight text-white flex items-center leading-none">
                Moro Board
              </h1>
            </div>

            {/* Figma-like Project Dropdown Picker */}
            <div className="h-6 w-[1.5px] bg-slate-800 hidden sm:inline-block" />

            <div className="flex items-center gap-1.5">
              <select
                value={activeProjectId || ''}
                onChange={(e) => {
                  const nextProjId = e.target.value;
                  setActiveProjectId(nextProjId);
                  localStorage.setItem('last_active_project_id_v2', nextProjId);
                  const related = floorPlans.filter(p => p.projectId === nextProjId);
                  if (related.length > 0) {
                    setActiveFloorPlanId(related[0].id);
                  }
                }}
                className="bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-xl px-2 py-1 text-[11px] font-bold text-slate-200 focus:outline-none cursor-pointer transition-colors"
                title="Chọn dự án đang chạy"
              >
                {projects.map(p => (
                  <option key={p.id} value={p.id}>
                    🏢 {p.name.length > 25 ? `${p.name.substring(0, 25)}...` : p.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Overlapping Hoverable Team Avatars row */}
          <div className="hidden lg:flex items-center gap-3">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider flex items-center gap-1">
              <Users className="w-3.5 h-3.5 text-indigo-400" />
              Đa vai trò:
            </span>
            <div className="flex items-center -space-x-1.5 overflow-hidden transition-all">
              {userRolesList.map((profile) => {
                const isActive = activeUserRole.id === profile.id;
                const initials = profile.name === 'Mụi Ngô' ? 'MN' : profile.name === 'trung test' ? 'TT' : profile.name === 'KHÁCH HÀNG DUYỆT' ? 'KH' : profile.name.charAt(0).toUpperCase();
                return (
                  <button
                    key={profile.id}
                    onClick={() => {
                      setActiveUserRole(profile);
                      setCurrentColor(profile.color);
                    }}
                    className={`w-6 h-6 rounded-full text-[8.5px] font-black border text-white flex items-center justify-center shrink-0 shadow transition-all hover:scale-115 active:scale-90 cursor-pointer relative z-10 ${
                      isActive 
                        ? 'ring-2 ring-indigo-400 border-white font-black z-25 scale-110' 
                        : 'border-slate-800 opacity-60 hover:opacity-100'
                    }`}
                    style={{ backgroundColor: profile.color }}
                    title={`Chuyển vai: ${profile.name} (${profile.role})`}
                  >
                    {initials}
                  </button>
                );
              })}
            </div>
          </div>

          {/* System action buttons */}
          <div className="flex items-center gap-1.5">
            {activePlan && (
              <>
                {/* 1. Toggle Sidebars inside small icon group */}
                <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5 shadow-sm">
                  <button
                    onClick={() => {
                      const nextZenState = !isZenMode;
                      setIsZenMode(nextZenState);
                      if (nextZenState) {
                        setIsRightSidebarOpen(false);
                      } else {
                        setIsRightSidebarOpen(true);
                      }
                    }}
                    className={`p-1.5 rounded-lg transition-all cursor-pointer ${isZenMode ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'}`}
                    title="Bật/Tắt Chế độ Tập Trung (Vẽ Full màn)"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setIsRightSidebarOpen(!isRightSidebarOpen)}
                    className={`p-1.5 rounded-lg transition-all cursor-pointer ${isRightSidebarOpen ? 'bg-slate-800 text-indigo-400 font-bold' : 'text-slate-400 hover:text-white'}`}
                    title="Hiện/Ẩn Thanh Phải"
                  >
                    <FileText className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="h-4 w-[1px] bg-slate-800" />

                {/* Main tools */}
                <button
                  onClick={() => setShowReportPreview(!showReportPreview)}
                  className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold cursor-pointer transition-all ${
                    showReportPreview 
                      ? 'bg-gradient-to-r from-emerald-400 to-indigo-500 text-slate-950' 
                      : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                  title="In báo cáo chi tiết"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">{showReportPreview ? 'Bản vẽ' : 'Báo cáo'}</span>
                </button>

                <button
                  onClick={() => setShowDowmarkModal(true)}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-xl text-[11px] font-bold text-slate-300 cursor-pointer transition-colors"
                  title="Đồng bộ cơ sở dữ liệu"
                >
                  <Cloud className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="hidden md:inline">Đồng bộ</span>
                </button>

                <button
                  onClick={() => setShowLessonsModal(true)}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-[11px] font-black cursor-pointer shadow-md transition-all active:scale-95 duration-150"
                  title="Quản lý 10 dự án mẫu & lỗi thường gặp"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Mẫu lỗi</span>
                </button>

                <button
                  onClick={exportDataPackage}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-xl text-[11px] font-bold text-slate-350 cursor-pointer transition-colors"
                  title="Tải gói dữ liệu"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden lg:inline">Tải JSON</span>
                </button>

                <button
                  onClick={() => setShowShareModal(true)}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-[11px] font-black cursor-pointer shadow-md transition-all active:scale-95"
                  title="Chia sẻ dự án"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Chia sẻ</span>
                </button>
              </>
            )}
          </div>
        </header>
      )}

      {!isHeaderOpen && (
        <div className="absolute top-0 left-1/2 -translate-x-1/2 z-40 select-none">
          <button
            onClick={() => {
              setIsHeaderOpen(true);
            }}
            className="px-3.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-[9px] uppercase tracking-wider rounded-b-lg shadow-lg border-x border-b border-indigo-400 cursor-pointer flex items-center gap-1 transition-all"
            title="Hiện lại thanh menu"
          >
            <span>↕ Hiện Menu</span>
          </button>
        </div>
      )}
      {/* 2. MAIN LAYOUT DECK CONTAINER */}
      {showReportPreview && activePlan ? (
        /* =========================================================
           REPORT PREVIEW & PRINT SUITE VIEW
           ========================================================= */
        <div className="flex-1 bg-white text-slate-900 max-w-4xl w-full mx-auto p-6 md:p-10 flex flex-col gap-6" id="printable-report-area">
          <div className="flex items-center justify-between border-b pb-4 border-slate-300">
            <div>
              <h2 className="text-xl font-black text-slate-950 tracking-tight">BÁO CÁO KHẢO SÁT & WHITEBOARD COLLABORATION</h2>
              <p className="text-xs text-slate-500 mt-1">
                Tên dự án mặt bằng: <span className="font-bold text-slate-850">{activePlan.name}</span>
              </p>
              <p className="text-[10px] text-slate-400 font-mono mt-0.5">Ngày xuất báo cáo: {new Date().toLocaleString('vi-VN')}</p>
            </div>
            
            <div className="flex items-center gap-2 print:hidden shrink-0">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                In / Xuất PDF
              </button>
              <button
                onClick={() => setShowReportPreview(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
              >
                Thoát
              </button>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-3 gap-3.5">
            <div className="bg-slate-50 border rounded-xl p-3 shadow-sm">
              <span className="text-[9px] uppercase font-bold text-slate-400 block leading-none">Chấm lỗi camera</span>
              <p className="text-base font-black text-slate-900 mt-1">{projectMarkerNotes.length} ghim</p>
            </div>
            <div className="bg-slate-50 border rounded-xl p-3 shadow-sm">
              <span className="text-[9px] uppercase font-bold text-slate-400 block leading-none">Hình ảnh đính kèm</span>
              <p className="text-base font-black text-slate-900 mt-1">
                {projectMarkerNotes.filter(m => m.photoData).length} / {projectMarkerNotes.length} ảnh
              </p>
            </div>
            <div className="bg-slate-50 border rounded-xl p-3 shadow-sm">
              <span className="text-[9px] uppercase font-bold text-slate-400 block leading-none">Whiteboard markup</span>
              <p className="text-base font-black text-slate-900 mt-1">{projectAnnotations.length} hình vẽ</p>
            </div>
          </div>

          {/* Detailed Points List Loop */}
          <div className="flex flex-col gap-6 mt-2">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest border-b pb-2">Danh sách chi tiết các lỗi & phản hồi</h3>
            {projectMarkerNotes.length === 0 ? (
              <div className="bg-slate-50 border border-dashed rounded-xl p-8 text-center text-slate-500 text-xs italic">
                Chưa có điểm ghim khảo sát nào được tạo.
              </div>
            ) : (
              projectMarkerNotes.map((m, idx) => (
                <div key={m.id} className="bg-white border border-slate-250 rounded-2xl p-5 shadow-sm flex flex-col md:flex-row gap-5 relative page-break-inside-avoid">
                  <span className="absolute top-4 right-4 bg-slate-900 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold font-mono">
                    {idx + 1}
                  </span>

                  {/* Photo Section */}
                  <div className="w-full md:w-56 shrink-0 flex flex-col gap-2">
                    {m.photoData ? (
                      <img
                        src={m.photoData}
                        className="w-full h-36 object-cover rounded-xl border border-slate-200"
                        alt={m.title}
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-36 bg-slate-50 border border-dashed rounded-xl flex flex-col items-center justify-center text-center p-4">
                        <Camera className="w-6 h-6 text-slate-300 mb-1" />
                        <span className="text-[10px] text-slate-400 font-medium">Chưa chụp ảnh</span>
                      </div>
                    )}
                    <div className="text-[9px] text-slate-450 font-mono text-center leading-none mt-1">
                      Toạ độ ghim: X: {Math.round(m.x)}% - Y: {Math.round(m.y)}%
                    </div>
                  </div>

                  {/* Detail text */}
                  <div className="flex-1 flex flex-col gap-3 min-w-0">
                    <div>
                      <h4 className="font-bold text-slate-950 text-base">{m.title}</h4>
                      <div className="text-[10px] text-slate-400 mt-0.5">Thời gian khởi tạo: {new Date(m.createdAt).toLocaleDateString('vi-VN')}</div>
                    </div>

                    {m.transcription && (
                      <div className="bg-slate-50 p-2.5 rounded-xl border-l-[4px] border-l-emerald-500">
                        <span className="text-[9px] uppercase font-black text-emerald-600 block leading-none">Thuyết minh Việt hoá:</span>
                        <p className="text-xs text-slate-800 italic mt-1 leading-relaxed font-sans">
                          "{m.transcription}"
                        </p>
                      </div>
                    )}

                    {m.textNotes && (
                      <div>
                        <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Mô tả gõ bổ túc:</span>
                        <p className="text-xs text-slate-800 mt-0.5 leading-relaxed">{m.textNotes}</p>
                      </div>
                    )}

                    {/* Threaded discussion comments in the index card */}
                    {m.comments && m.comments.length > 0 && (
                      <div className="border-t border-slate-100 pt-2.5 mt-1.5">
                        <span className="text-[9px] uppercase font-black text-indigo-700 block mb-1">Thảo luận giải quyết lỗi ({m.comments.length}):</span>
                        <div className="flex flex-col gap-2">
                          {m.comments.map(c => (
                            <div key={c.id} className="text-[11px] bg-slate-50 border border-slate-150 p-2 rounded-xl">
                              <span className="font-bold text-slate-800">{c.userName} ({c.userRole}): </span>
                              <span className="text-slate-700 font-sans">{c.content}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        /* =========================================================
           MAIN INTERACTIVE DESIGN INTERFACE
           ========================================================= */
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
          
          {/* MAIN CENTER WORKSPACE AREA */}
          <main className="flex-1 p-4 bg-slate-900/10 flex flex-col gap-4 overflow-y-auto relative">
            
            {/* Upload notifications banner */}
            {uploadProgress && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-xs rounded-xl flex items-center gap-2 animate-pulse font-bold z-10">
                <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{uploadProgress}</span>
              </div>
            )}

            {/* Interactive blueprint graphic view canvas */}
            <div className="flex-1 min-h-[350px]">
              <FloorPlanViewer
                floorPlan={activePlan}
                floorPlans={projectFloorPlans}
                activeFloorPlanId={activeFloorPlanId}
                setActiveFloorPlanId={setActiveFloorPlanId}
                onUpdateFloorPlan={handleUpdateFloorPlan}
                markers={projectMarkerNotes}
                selectedMarkerId={selectedMarkerId}
                onSelectMarker={(id) => {
                  setSelectedMarkerId(id);
                  setSelectedAnnotationId(null);
                }}
                onAddMarker={handleAddMarker}
                onUploadFloorPlan={handleFloorPlanUpload}
                
                annotations={projectAnnotations}
                onAddAnnotation={handleAddAnnotation}
                onUpdateAnnotation={handleUpdateAnnotation}
                onDeleteAnnotation={handleDeleteAnnotation}
                selectedAnnotationId={selectedAnnotationId}
                onSelectAnnotation={(id) => {
                  setSelectedAnnotationId(id);
                  setSelectedMarkerId(null);
                }}
                
                activeWhiteboardTool={activeWhiteboardTool}
                setActiveWhiteboardTool={setActiveWhiteboardTool}
                activeUserRole={activeUserRole}
                userRolesList={userRolesList}
                currentColor={currentColor}
                setCurrentColor={setCurrentColor}
                onUndo={handleUndo}
                onRedo={handleRedo}
                canUndo={undoStack.length > 0}
                canRedo={redoStack.length > 0}
                activeProjectId={activeProjectId}
                onDeleteFloorPlan={handleDeleteFloorPlan}
                activeProject={projects.find(p => p.id === activeProjectId) || null}
                onUpdateMarker={handleUpdateMarker}
              />
            </div>
          </main>

          {/* ACTIVE RIGHT DETAIL COLLABORATION SIDEBAR */}
          {isRightSidebarOpen && (
            <aside className="relative w-full lg:w-[350px] xl:w-[380px] p-4 lg:pl-0 flex flex-col shrink-0">
              {/* Thin Vertical Collapse Button */}
              <div className="absolute left-[-10px] top-1/2 -translate-y-1/2 z-45 hidden lg:block">
                <button
                  onClick={() => setIsRightSidebarOpen(false)}
                  className="w-5 h-20 bg-slate-950 hover:bg-slate-900 text-indigo-400 border border-r-0 border-slate-800 rounded-l-2xl shadow-2xl font-black text-xs flex flex-col items-center justify-center gap-1 cursor-pointer hover:scale-105 active:scale-95 transition-all"
                  title="Thu gọn bảng phản hồi"
                >
                  <span>▶</span>
                  <span className="text-[7.5px] uppercase tracking-tighter text-indigo-400 font-extrabold block [writing-mode:vertical-lr] mt-1">Thu gọn</span>
                </button>
              </div>

              <MarkerDetailSidebar
                marker={selectedMarker}
                onUpdateMarker={handleUpdateMarker}
                onDeleteMarker={handleDeleteMarker}
                onTriggerCamera={() => setShowCameraModal(true)}
                onClose={() => {
                  setSelectedMarkerId(null);
                  setSelectedAnnotationId(null);
                  setIsRightSidebarOpen(false); // Automatically collapse to maximize Miro drawing workspace!
                }}
                
                selectedAnnotation={selectedAnnotation}
                onUpdateAnnotation={handleUpdateAnnotation}
                onDeleteAnnotation={handleDeleteAnnotation}
                
                activeUserRole={activeUserRole}
                userRolesList={userRolesList}
                onSetActiveUserRole={setActiveUserRole}

                markersList={markerNotes}
                onSelectMarker={(id) => {
                  setSelectedMarkerId(id);
                  setSelectedAnnotationId(null);
                  setIsRightSidebarOpen(true);
                }}
                onAddMarker={handleAddMarker}
              />
            </aside>
          )}

          {!isRightSidebarOpen && (
            <div className="absolute right-0 top-1/2 -translate-y-1/2 z-35 hidden lg:block">
              <button
                onClick={() => setIsRightSidebarOpen(true)}
                className="w-5 h-20 bg-slate-950 hover:bg-slate-900 text-indigo-400 border border-r-0 border-slate-800 rounded-l-2xl shadow-2xl font-black text-xs flex flex-col items-center justify-center gap-1 cursor-pointer hover:scale-105 active:scale-95"
                title="Hiện bảng phản hồi bên phải"
              >
                <span>◀</span>
                <span className="text-[7.5px] uppercase tracking-tighter text-indigo-400 font-extrabold block [writing-mode:vertical-lr] mt-1">Chi tiết</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Hidden camera snapshot trigger popup */}
      {showCameraModal && (
        <CameraModal
          onCapture={handleCapturePhoto}
          onClose={() => setShowCameraModal(false)}
        />
      )}

      {/* Dowmark Operations diagram modal popup */}
      <OpsMapModal
        isOpen={showDowmarkModal}
        onClose={() => setShowDowmarkModal(false)}
        onSyncReload={loadData}
      />

      {/* Share / Collaboration modal */}
      <ShareProjModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        activePlan={activePlan}
        markerNotes={projectMarkerNotes}
        annotations={projectAnnotations}
        onImportSuccess={handleImportSuccess}
      />

      {/* 10 Projects Management & Lessons Learned Reference Center */}
      <LessonsLearnedModal
        isOpen={showLessonsModal}
        onClose={() => setShowLessonsModal(false)}
        onImportMockBluePrint={handleImportMockBluePrint}
      />
    </div>
  );
}
